// Copyright, 2002 Oak Leaf Enterprises Solution Design, Inc.
// No part of this software or its associated documentation 
// may be stored in a retrieval system, copied, transmitted, 
// distributed, transcribed or reproduced in any other way or 
// disclosed to any third parties without the written permission 
// of Oak Leaf Enterprises Solution Design, Inc.

using System;

namespace OakLeaf.MM.Main.Business
{
	/// <summary>
	/// Business State Change event args class
	/// </summary>
	public class mmBusinessStateChangeEventArgs : EventArgs
	{
		/// <summary>
		/// Business object state property
		/// </summary>
		public mmBusinessState State
		{
			get { return this._state; }
			set { this._state = value; }
		}
		/// <summary>
		/// Business objects state field
		/// </summary>
		private mmBusinessState _state;

		/// <summary>
		/// Primary key value property
		/// </summary>
		public object PrimaryKeyValue
		{
			get { return this._primaryKeyValue; }
			set { this._primaryKeyValue = value; }
		}
		private object _primaryKeyValue = null;

		/// <summary>
		/// Primary key values property
		/// </summary>
		public object[] PrimaryKeyValues
		{
			get { return this._primaryKeyValues; }
			set { this._primaryKeyValues = value; }
		}
		private object[] _primaryKeyValues;
		
		/// <summary>
		/// Table Name property
		/// </summary>
		public string TableName
		{
			get { return this._tableName; }
			set { this._tableName = value; }
		}
		private string _tableName;
		
		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="bizState">Business object state</param>
		/// <param name="tableName">Table name</param>
		/// <param name="pkValue">PK value</param>
		/// <param name="pkValues">PK values</param>
		public mmBusinessStateChangeEventArgs(mmBusinessState bizState, string tableName, object pkValue, object[] pkValues)
		{
			this.State = bizState;
			this.TableName = tableName;
			this.PrimaryKeyValue = pkValue;
			this.PrimaryKeyValues = pkValues;
		}
	}
}
