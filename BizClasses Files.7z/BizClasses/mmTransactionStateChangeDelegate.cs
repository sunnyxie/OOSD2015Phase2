// Copyright, 2002 Oak Leaf Enterprises Solution Design, Inc.
// No part of this software or its associated documentation 
// may be stored in a retrieval system, copied, transmitted, 
// distributed, transcribed or reproduced in any other way or 
// disclosed to any third parties without the written permission 
// of Oak Leaf Enterprises Solution Design, Inc.

using System;

namespace OakLeaf.MM.Main.Business
{

	/// <summary>
	/// Business Transaction State Change delegate
	/// </summary>
    [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
    public delegate void mmTransactionStateChangeDelegate(mmBusinessObject bizObj, mmTransactionStateChangeEventArgs e);

}
