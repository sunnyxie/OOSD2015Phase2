// Copyright, 2004 Oak Leaf Enterprises Solution Design, Inc.
// No part of this software or its associated documentation 
// may be stored in a retrieval system, copied, transmitted, 
// distributed, transcribed or reproduced in any other way or 
// disclosed to any third parties without the written permission 
// of Oak Leaf Enterprises Solution Design, Inc.

using System;
using System.Collections;
using System.Collections.Specialized;

namespace OakLeaf.MM.Main.Business
{
	/// <summary>
	/// Summary description for mmBusinessRuleBase.
	/// </summary>
	public abstract class mmBusinessRuleBase : mmRuleManagerBase
	{
		/// <summary>
		/// Error Provider Broken Rules array
		/// </summary>
		protected ArrayList ErrorProviderBrokenRules = new ArrayList();
		/// <summary>
		/// Error Provider Warnings array
		/// </summary>
		protected ArrayList ErrorProviderWarnings = new ArrayList();
		/// <summary>
		/// Reference to associated business object
		/// </summary>
		protected ImmBusinessRuleHost HostObject;
		/// <summary>
		/// Broken rules collection
		/// </summary>
		protected StringCollection BrokenRules = new StringCollection();
		/// <summary>
		/// Warnings collection
		/// </summary>
		protected StringCollection Warnings = new StringCollection();
		/// <summary>
		/// Required fields collection
		/// </summary>
		protected StringCollection RequiredFields = new StringCollection();
		
		/// <summary>
		/// Broken rule count (read-only)
		/// </summary>
		public override int BrokenRuleCount
		{
			get	{ return this.BrokenRules.Count; }
		}

		/// <summary>
		/// Warning count
		/// </summary>
		public override int WarningCount
		{
			get	{ return this.Warnings.Count; }
		}

		/// <summary>
		/// The number of Error Provider broken rules
		/// </summary>
		public int ErrorProviderBrokenRuleCount
		{
			get { return this.ErrorProviderBrokenRules.Count; }
		}

		/// <summary>
		/// The number of Error Provider warnings
		/// </summary>
		public int ErrorProviderWarningCount
		{
			get { return this.ErrorProviderWarnings.Count; }
		}

		/// <summary>
		/// Constructor
		/// </summary>
		public mmBusinessRuleBase()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		
		/// <summary>
		/// Adds the specified broken rule to the broken rule collection if it's not already there
		/// </summary>
		/// <param name="brokenRule">Broken rule string</param>
		public virtual void AddBrokenRule(string brokenRule)
		{
			// Only add the broken rule if it's not already there
			if (!BrokenRules.Contains(brokenRule))
			{
				this.BrokenRules.Add(brokenRule);
				this.HostObject.OnBrokenRuleAdd(brokenRule);
			}
		}

		/// <summary>
		/// Adds an Error Provider broken rules argument to the array
		/// </summary>
		/// <param name="arg">Error provider argument</param>
		public abstract void AddErrorProviderBrokenRule(mmErrorProviderArgs arg);

		/// <summary>
		/// Adds error provider broken rules to the array for the
		/// current DataSet, table, and row
		/// </summary>
		/// <param name="columnName">Column name</param>
		/// <param name="errorText">Error text</param>
		public abstract void AddErrorProviderBrokenRule(string columnName, string errorText);

		/// <summary>
		/// Adds an Error Provider warning argument to the array
		/// </summary>
		/// <param name="arg">Error Provider argument</param>
		public abstract void AddErrorProviderWarning(mmErrorProviderArgs arg);

		/// <summary>
		/// Adds an Error Provider warning argument with the
		/// specified error member and error text to the array
		/// </summary>
		/// <param name="memberName">Error Member name</param>
		/// <param name="errorText">Error text</param>
		public abstract void AddErrorProviderWarning(string memberName, string errorText);

		/// <summary>
		/// Adds a required field to the Required Fields collection if it's not already there
		/// </summary>
		/// <param name="columnName">Column name</param>
		public virtual void AddRequiredField(string columnName)
		{
			// Only add the required field if it's not already there
			if (!RequiredFields.Contains(columnName))
			{
				this.RequiredFields.Add(columnName);
			}
		}

		/// <summary>
		/// Adds the specified warning to the warning collection if it's not already there
		/// </summary>
		/// <param name="warning">Warning string</param>
		public virtual void AddWarning(string warning)
		{
			// Only add the warning if it's not already there
			if (!Warnings.Contains(warning))
			{
				this.Warnings.Add(warning);
				this.HostObject.OnWarningAdd(warning);
			}
		}

		/// <summary>
		/// Clears both the broken rule and warning collections
		/// </summary>
		public override void ClearAll()
		{
			this.ClearAllRules();
			this.ClearAllWarnings();
		}

		/// <summary>
		/// Clears the broken rules collection
		/// </summary>
		public abstract void ClearAllRules();

		/// <summary>
		/// Clears the Warnings collection
		/// </summary>
		public abstract void ClearAllWarnings();

		/// <summary>
		/// Removes the specified broken rule from the collection
		/// </summary>
		/// <param name="brokenRule">Broken rule string to be cleared</param>
		public virtual void ClearRule(string brokenRule)
		{
			this.BrokenRules.Remove(brokenRule);
			this.HostObject.OnBrokenRuleClear(brokenRule);
		}

		/// <summary>
		/// Clears the specified warning from the collection
		/// </summary>
		/// <param name="warning">Warning string to be cleared</param>
		public virtual void ClearWarning(string warning)
		{
			this.Warnings.Remove(warning);
			this.HostObject.OnWarningClear(warning);
		}

		/// <summary>
		/// Copies all rules and warnings from the specified business rule object
		/// </summary>
		/// <param name="bizRule">Business Rule object</param>
		public virtual void CopyFromRuleObject(mmBusinessRule bizRule)
		{
			// Copy all the rules
			foreach(string rule in bizRule.BrokenRules)
			{
				this.AddBrokenRule(rule);
			}

			// Copy all the warnings
			foreach(string warning in bizRule.Warnings)
			{
				this.AddWarning(warning);
			}

			// Copy all Error Provider rules
			foreach(object epRule in bizRule.ErrorProviderBrokenRules)
			{
				this.AddErrorProviderBrokenRule((mmErrorProviderArgs)epRule);
			}

			// Copy all Error Provider warnings
			foreach(object epWarning in bizRule.ErrorProviderWarnings)
			{
				this.AddErrorProviderWarning((mmErrorProviderArgs)epWarning);
			}
		}

		/// <summary>
		/// Returns a string containing all broken rules. Each broken
		/// rule is separated by a new line character
		/// </summary>
		/// <returns></returns>
		public override string GetAllBrokenRules()
		{
			string BrokenRulesMsg = "";
			string ErrorText = "";

			foreach(string rule in this.BrokenRules)
			{
				if (mmAppBase.Localize)
				{
					ErrorText = mmAppBase.MessageMgr.GetMessage(rule);
				}
				else
				{
					ErrorText = rule;
				}
				BrokenRulesMsg += ErrorText + "\r\n\r\n";
			}
			foreach(mmErrorProviderArgs arg in this.ErrorProviderBrokenRules)
			{
				if (mmAppBase.Localize)
				{
					ErrorText = mmAppBase.MessageMgr.GetMessage(arg.ErrorText);
				}
				else
				{
					ErrorText = arg.ErrorText;
				}
				BrokenRulesMsg += ErrorText + "\r\n\r\n";
			}
			return BrokenRulesMsg;
		}

		/// <summary>
		/// Returns a string containing all warnings. Each warning
		/// is separated by a new line character
		/// </summary>
		/// <returns>String containing all warnings</returns>
		public override string GetAllWarnings()
		{
			string WarningsMsg = "";
			string WarningText = "";

			foreach (string warning in this.Warnings)
			{
				if (mmAppBase.Localize)
				{
					WarningText = mmAppBase.MessageMgr.GetMessage(warning);
				}
				else
				{
					WarningText = warning;
				}
				WarningsMsg += WarningText + "\r\n\r\n";
			}
			foreach(mmErrorProviderArgs arg in this.ErrorProviderWarnings)
			{
				if (mmAppBase.Localize)
				{
					WarningText = mmAppBase.MessageMgr.GetMessage(arg.ErrorText);
				}
				else
				{
					WarningText = arg.ErrorText;
				}

				WarningsMsg += WarningText + "\r\n\r\n";
			}
			return WarningsMsg;
		}

		/// <summary>
		/// Returns the nth broken rule specified by the index number
		/// </summary>
		/// <param name="index">Index number of broken rule to be returned</param>
		/// <returns>The nth broken rule</returns>
		public virtual string GetBrokenRule(int index)
		{
			return this.BrokenRules[index];
		}

		/// <summary>
		/// Returns the nth broken rule specified by the index number
		/// </summary>
		/// <param name="index">Index number of warning to be returned</param>
		/// <returns>The nth warning</returns>
		public virtual string GetWarning(int index)
		{
			return this.Warnings[index];
		}

		/// <summary>
		/// Returns the nth Error Provider broken rule by index number
		/// </summary>
		/// <param name="index">Index number</param>
		/// <returns>Error provider arg</returns>
		public virtual mmErrorProviderArgs GetErrorProviderRule(int index)
		{
			return (mmErrorProviderArgs)this.ErrorProviderBrokenRules[index];
		}

		/// <summary>
		/// Returns the nth Error Provider warning by index number
		/// </summary>
		/// <param name="index">Index number</param>
		/// <returns>Error provider args</returns>
		public virtual mmErrorProviderArgs GetErrorProviderWarning(int index)
		{
			return (mmErrorProviderArgs)this.ErrorProviderWarnings[index];
		}

		/// <summary>
		/// Returns a logical value indicating if the specified field is empty
		/// </summary>
		/// <param name="fieldValue">Field value</param>
		/// <returns>True if empty, otherwise false</returns>
		public virtual bool IsRequiredFieldEmpty(object fieldValue)
		{
			bool retval = false;
			if (fieldValue == DBNull.Value)
			{
				retval = true;
			}
			else
			{
				string strValue = fieldValue.ToString();
				if (mmString.Empty(strValue))
				{
					retval = true;
				}
			}
			return retval;
		}
	}
}
