using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.ComponentModel;

namespace OakLeaf.MM.Main.Business
{
	/// <summary>
	/// Summary description for mmBusinessEntity
	/// </summary>
	public abstract class mmBusinessEntity
	{
		/// <summary>
		/// Constructor
		/// </summary>
		public mmBusinessEntity()
		{

		}

		/// <summary>
		/// True if the entity has data values, otherwise false
		/// </summary>
		[Browsable(false), Bindable(false)]
        public bool HasValues
		{
			get { return this.Row != null; }
		}

		/// <summary>
		/// DataRow
		/// </summary>
		protected virtual DataRow Row
		{
			get { return _row; }
			set { _row = value; }
		}
		private DataRow _row;

		/// <summary>
		/// Sets the current DataRow
		/// </summary>
		/// <param name="dr">DataRow</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void SetDataRow(DataRow dr)
		{
			this.Row = dr;
		}
	}
}
