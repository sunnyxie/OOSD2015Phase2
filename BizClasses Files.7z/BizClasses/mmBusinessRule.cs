// Copyright, 2002 Oak Leaf Enterprises Solution Design, Inc.
// No part of this software or its associated documentation 
// may be stored in a retrieval system, copied, transmitted, 
// distributed, transcribed or reproduced in any other way or 
// disclosed to any third parties without the written permission 
// of Oak Leaf Enterprises Solution Design, Inc.

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Data;

namespace OakLeaf.MM.Main.Business
{
	/// <summary>
	/// Business Rule base class
	/// </summary>
	public class mmBusinessRule : mmBusinessRuleBase
	{
		/// <summary>
		/// Entity property display name 
		/// Used as temporary storage for all business rule validation methods
		/// </summary>
		public string EntityPropertyDisplayName
		{
			get { return _entityPropertyDisplayName; }
			set
			{
				_entityPropertyDisplayName = value;
				if (mmAppBase.Localize)
				{
					_entityPropertyDisplayName = mmAppBase.MessageMgr.GetMessage(_entityPropertyDisplayName);
				}
			}
		}
		private string _entityPropertyDisplayName;

		/// <summary>
		/// Required field message prefix
		/// </summary>
		protected string RequiredFieldMessagePrefix
		{
			get { return _requiredFieldMessagePrefix; }
			set
			{
				_requiredFieldMessagePrefix = value;
				if (mmAppBase.Localize)
				{
					_requiredFieldMessagePrefix = mmAppBase.MessageMgr.GetMessage(_requiredFieldMessagePrefix);
				}
			}
		}
		private string _requiredFieldMessagePrefix;

		/// <summary>
		/// Required field message suffix
		/// </summary>
		protected string RequiredFieldMessageSuffix
		{
			get 
			{
				if (_requiredFieldMessageSuffix == null)
				{
					_requiredFieldMessageSuffix =
						mmAppBase.Localize
						? mmAppBase.MessageMgr.GetMessage(" is required")
					: " is required";
				}
				return _requiredFieldMessageSuffix; 
			}
			set
			{
				_requiredFieldMessageSuffix = value;
				if (mmAppBase.Localize)
				{
					_requiredFieldMessageSuffix = mmAppBase.MessageMgr.GetMessage(_requiredFieldMessageSuffix);
				}
			}
		}
		private string _requiredFieldMessageSuffix;

		/// <summary>
		/// True if the rule object has broken rules, otherwise, false
		/// </summary>
		public bool HasBrokenRules
		{
			get { return this.ErrorProviderBrokenRuleCount + 
					this.BrokenRuleCount != 0; }
		}

		/// <summary>
		/// True if the rule object has warnings, otherwise, false
		/// </summary>
		public bool HasWarnings
		{
			get	{
				return this.ErrorProviderBrokenRuleCount +
				  this.ErrorProviderWarningCount != 0;	}
		}


		/// <summary>
		/// Specifies if broken rule and warning collections are cleared
		/// before running CheckRules
		/// </summary>
		public bool AutoClearRules = true;
		/// <summary>
		/// Current row number
		/// </summary>
		public int CurrentRow = 0;
		/// <summary>
		/// Current DataSet
		/// </summary>
		protected DataSet DataSet;
		/// <summary>
		/// Current Data Row
		/// </summary>
		public DataRow DataRow;
		/// <summary>
		/// Current Data View (if any)
		/// </summary>
		public DataView DataView;
		/// <summary>
		/// Current table name
		/// </summary>
		protected string TableName;

		/// <summary>
		/// Business Rule constructor. Registers specified host object
		/// </summary>
		/// <param name="hostObject">Host object. Must implemenht ImmBusinessRuleHost interface</param>
		public mmBusinessRule(ImmBusinessRuleHost hostObject)
		{
			HostObject = hostObject;
		}
		
		/// <summary>
		/// Adds an Error Provider broken rules argument to the array
		/// </summary>
		/// <param name="arg">Error provider argument</param>
		public override void AddErrorProviderBrokenRule(mmErrorProviderArgs arg)
		{
			this.ErrorProviderBrokenRules.Add(arg);
			
			if (arg.DataView != null)
			{
				// Add the error to the DataView column
				arg.DataView[arg.Row].Row.SetColumnError(arg.ColumnName, arg.ErrorText);
			}
			else if (arg.ErrorDataSet != null)
			{
				// Add the error to the DataSet column
				arg.ErrorDataSet.Tables[arg.TableName].Rows[arg.Row].SetColumnError(
					arg.ColumnName, arg.ErrorText);
			}

			this.HostObject.OnErrorProviderBrokenRuleAdd(arg);
		}

		/// <summary>
		/// Adds error provider broken rules to the array for the
		/// specified DataView, row, and column
		/// </summary>
		/// <param name="dv">DataView</param>
		/// <param name="row">Row</param>
		/// <param name="columnName">Column Name</param>
		/// <param name="errorText">Error text</param>
		public virtual void AddErrorProviderBrokenRule(DataView dv,
			int row, string columnName, string errorText)
		{
			// Instantiate a new error provider argument and add it to the list
			mmErrorProviderArgs arg = new mmErrorProviderArgs(dv,
				row, columnName, errorText, false);

			// Add to the Error Provider arguments array
			this.AddErrorProviderBrokenRule(arg);
		}

		/// <summary>
		/// Adds error provider broken rules to the array for the
		/// specified DataSet, table, row, and column
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="tableName">TableName</param>
		/// <param name="row">Row</param>
		/// <param name="columnName">Column name</param>
		/// <param name="errorText">Error Text</param>
		public virtual void AddErrorProviderBrokenRule(DataSet ds, string tableName,
			int row, string columnName, string errorText)
		{
			// Instantiate a new error provider argument and add it to the list
			mmErrorProviderArgs arg = new mmErrorProviderArgs(ds, tableName,
				row, columnName, errorText, false);

			// Add to the Error Provider arguments array
			this.AddErrorProviderBrokenRule(arg);
		}

		/// <summary>
		/// Adds error provider broken rules to the array for the
		/// current DataSet, specified table, and current row
		/// </summary>
		/// <param name="columnName">Column name</param>
		/// <param name="errorText">Error text</param>
		/// <param name="tableName">Table name</param>
		public virtual void AddErrorProviderBrokenRule(string columnName, string errorText,
			string tableName)
		{
			this.AddErrorProviderBrokenRule(this.DataSet, tableName, 
				this.CurrentRow, columnName, errorText);
		}

		/// <summary>
		/// Adds error provider broken rules to the array for the
		/// current DataSet, table, and row
		/// </summary>
		/// <param name="columnName">Column name</param>
		/// <param name="errorText">Error text</param>
		public override void AddErrorProviderBrokenRule(string columnName, string errorText)
		{
			if (this.DataView == null)
			{
				// The data is bound to a DataSet
				this.AddErrorProviderBrokenRule(this.DataSet, this.TableName, 
					this.CurrentRow, columnName, errorText);
			}
			else
			{
				// The data is bound to a DataView
				this.AddErrorProviderBrokenRule(this.DataView, 
					this.CurrentRow, columnName, errorText);
			}
		}

		/// <summary>
		/// Adds an Error Provider Warning to the list for the specified
		/// DataView, Row, Column
		/// </summary>
		/// <param name="dv">DataView</param>
		/// <param name="row">Row</param>
		/// <param name="columnName">Column</param>
		/// <param name="errorText">Error text</param>
		public virtual void AddErrorProviderWarning(DataView dv,
			int row, string columnName, string errorText)
		{
			// Instantiate a new error provider argument and add it to the list
			mmErrorProviderArgs arg = new mmErrorProviderArgs(dv,
				row, columnName, errorText, true);

			// Add to the Error Provider arguments array
			this.AddErrorProviderWarning(arg);
		}
		
		/// <summary>
		/// Adds error provider warning to the array
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="tableName">TableName</param>
		/// <param name="row">Row</param>
		/// <param name="columnName">Column name</param>
		/// <param name="errorText">Error Text</param>
		public virtual void AddErrorProviderWarning(DataSet ds, string tableName,
			int row, string columnName, string errorText)
		{
			// Instantiate a new error provider argument and add it to the list
			mmErrorProviderArgs arg = new mmErrorProviderArgs(ds, tableName,
				row, columnName, errorText, true);

			// Add to the Error Provider arguments array
			this.AddErrorProviderWarning(arg);
		}

		/// <summary>
		/// Adds error provider warnings to the array for the
		/// current DataSet, specified table, and current row
		/// </summary>
		/// <param name="columnName">Column name</param>
		/// <param name="errorText">Error text</param>
		/// <param name="tableName">Table Name</param>
		public virtual void AddErrorProviderWarning(string columnName, string errorText,
			string tableName)
		{
			this.AddErrorProviderWarning(this.DataSet, tableName,
				this.CurrentRow, columnName, errorText);
		}

		/// <summary>
		/// Adds error provider warnings to the array for the
		/// current DataSet, table, and row
		/// </summary>
		/// <param name="columnName">Column name</param>
		/// <param name="errorText">Error text</param>
		public override void AddErrorProviderWarning(string columnName, string errorText)
		{
			if (this.DataView == null)
			{
				// The data is bound to a DataSet
				this.AddErrorProviderWarning(this.DataSet, this.TableName,
					this.CurrentRow, columnName, errorText);
			}
			else
			{
				// The data is bound to a DataView
				this.AddErrorProviderWarning(this.DataView,
					this.CurrentRow, columnName, errorText);
			}
		}

		/// <summary>
		/// Adds an Error Provider warning argument to the array
		/// </summary>
		/// <param name="arg">Error Provider argument</param>
		public override void AddErrorProviderWarning(mmErrorProviderArgs arg)
		{
			this.ErrorProviderWarnings.Add(arg);

			if (arg.DataView != null)
			{
				// Add the error to the DataView column
				arg.DataView[arg.Row].Row.SetColumnError(arg.ColumnName, arg.ErrorText);
			}
			else
			{
				if (arg.ErrorDataSet != null)
				{
					// Add the warning to the DataSet column
					arg.ErrorDataSet.Tables[arg.TableName].Rows[arg.Row].SetColumnError(
						arg.ColumnName, arg.ErrorText);
				}
			}

			this.HostObject.OnErrorProviderWarningAdd(arg);
		}

		/// <summary>
		/// Checks all rows in the specified DataSet table for required fields
		/// This method stops checking after it finds the first row that contains empty
		/// required fields.
		/// </summary>
		/// <param name="ds">DataSet containing table to be checked</param>
		/// <param name="tableName">Table name to be checked</param>
		/// <param name="useErrorProvider">Specifies if Error Provider logic is used</param>
		/// <returns>Logical true if all required fields have been entered, otherwise false</returns>
		public virtual bool CheckRequiredFields(DataSet ds, string tableName, 
			bool useErrorProvider)
		{
			bool RetVal = true;

			if (this.RequiredFields.Count != 0)
			{
				if (this.DataRow != null)
				{
					return this.CheckRequiredFieldsInRow(ds, tableName, this.DataRow, this.CurrentRow, useErrorProvider);
				}
				else
				{
					int RowNum = 0;

					DataTable dt = ds.Tables[tableName];
					foreach (DataRow row in dt.Rows)
					{
						if (row.RowState != DataRowState.Deleted)
						{
							if (!this.CheckRequiredFieldsInRow(ds, tableName, row, RowNum, useErrorProvider))
							{
								RetVal = false;
								break;
							}
						}
						RowNum++;
					}
				}
			}
			return RetVal;
		}

		/// <summary>
		/// Checks the specified DataRow for required fields
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="tableName">Table Name</param>
		/// <param name="dr">DataRow</param>
		/// <param name="RowNum">Row number</param>
		/// <param name="useErrorProvider">"User Error provider" flag</param>
		/// <returns></returns>
		public virtual bool CheckRequiredFieldsInRow(DataSet ds, string tableName, DataRow dr, int RowNum, 
			bool useErrorProvider)
		{
			bool RetVal = true;
			if (useErrorProvider)
			{
				// Fill the ArrayList with empty required fields
				ArrayList EmptyRequiredFields = this.GetEmptyRequiredFieldsList(dr);

				string EnterValueMessage = 
					mmAppBase.Localize
					? mmAppBase.MessageMgr.GetMessage("You must enter a value for")
					: "You must enter a value for";

				// Add an error provider broken rule for each empty required field
				foreach(string column in EmptyRequiredFields)
				{
					if (this.DataView == null)
					{
						this.AddErrorProviderBrokenRule(ds, 
							tableName, 
							RowNum,
							column, 
							EnterValueMessage + " " + column);
					}
					else
					{
						this.AddErrorProviderBrokenRule(this.DataView,
							RowNum,
							column,
							EnterValueMessage + " " + column);
					}
				}

				if (RetVal)
				{
					RetVal = EmptyRequiredFields.Count == 0;
				}
			}
			else
			{
				// Get a string listing all required fields that are empty
				string EmptyRequiredFields = 
					this.GetEmptyRequiredFields(dr);

				// Add a broken rule if any required fields are empty
				if (EmptyRequiredFields != "")
				{
					if (mmAppBase.Localize)
					{
						this.AddBrokenRule(
							mmAppBase.MessageMgr.GetMessage("You must enter the following required fields") + 
							": " + EmptyRequiredFields + ".");
					}
					else
					{
						this.AddBrokenRule("You must enter the following required fields: " +
							EmptyRequiredFields + ".");
					}
					RetVal = false;
				}
			}
			return RetVal;
		}
		
		/// <summary>
		/// Calls the CheckRulesHook and CheckRequiredFields methods
		/// </summary>
		/// <param name="ds">DataSet containing table to be checked</param>
		/// <param name="tableName">Table Name to be checked</param>
		/// <param name="useErrorProvider">Specifies if Error Provider logic is used</param>
		/// <returns>mmCheckRulesResult value</returns>
		public virtual mmSaveDataResult CheckRules(DataSet ds, string tableName,
			bool useErrorProvider)
		{
			mmSaveDataResult Result = mmSaveDataResult.RulesPassed;

			// Save the specified DataSet and Table Name
			this.DataSet = ds;
			this.TableName = tableName;

			// Clear all broken rules and warnings
			if (this.AutoClearRules)
			{
				this.ClearAll();
			}

			// Check required fields
			if (this.CheckRequiredFields(ds, tableName, useErrorProvider))
			{

				// Call custom business object rules hook method
				this.CheckRulesHook(ds, tableName);

				// Check if any broken rules or warnings and set the
				// return value accordingly
				if (this.BrokenRuleCount > 0 || this.ErrorProviderBrokenRuleCount > 0)
				{
					Result = mmSaveDataResult.RulesBroken;
				}
				else
				{
					if (this.WarningCount > 0 || this.ErrorProviderWarningCount > 0)
					{
						Result = mmSaveDataResult.RuleWarnings;
					}
				}
			}
			else
			{
				Result = mmSaveDataResult.RulesBroken;
			}

			// Clear the DataView field. Used for displaying error-provider style broken rules
			this.DataView = null;

			return Result;
		}

		/// <summary>
		/// A hook method into which developers can place application-specific 
		/// code to check rules for the associated business object
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="tableName">Table Name</param>
		/// <returns>Logical true if no broken rules, otherwise, false</returns>
		public virtual bool CheckRulesHook(DataSet ds, string tableName)
		{
			return true;
		}

		/// <summary>
		/// Clears the broken rules collection
		/// </summary>
		public override void ClearAllRules()
		{
			mmErrorProviderArgs ep;

			this.BrokenRules.Clear();

			// Clear all error provider broken rules
			for (int i=0; i<ErrorProviderBrokenRules.Count; i++)
			{
				ep = (mmErrorProviderArgs)ErrorProviderBrokenRules[i];
				if (ep.DataView != null)
				{
					ep.DataView[ep.Row].Row.SetColumnError(ep.ColumnName, "");
				}
				else
				{
					if (ep.ErrorDataSet != null)
					{
						ep.ErrorDataSet.Tables[ep.TableName].Rows[ep.Row].SetColumnError(ep.ColumnName, "");
					}
				}
			}

			this.ErrorProviderBrokenRules.Clear();
		}

		/// <summary>
		/// Clears the Warnings collection
		/// </summary>
		public override void ClearAllWarnings()
		{
			mmErrorProviderArgs ep;

			this.Warnings.Clear();

			// Clear all Error Provider Warnings
			for (int i=0; i<ErrorProviderWarnings.Count; i++)
			{
				ep = (mmErrorProviderArgs)ErrorProviderWarnings[i];
				if (ep.DataView != null)
				{
					ep.DataView[ep.Row].Row.SetColumnError(ep.ColumnName, "");
				}
				else
				{
					if (ep.ErrorDataSet != null)
					{
						ep.ErrorDataSet.Tables[ep.TableName].Rows[ep.Row].SetColumnError(ep.ColumnName, "");
					}
				}
			}
			this.ErrorProviderWarnings.Clear();
		}

		/// <summary>
		/// Returns a list of all empty required fields found in the specified DataRow
		/// </summary>
		/// <param name="dr">DataRow</param>
		/// <returns>String containing comma-separated list of empty required fields</returns>
		public virtual string GetEmptyRequiredFields(DataRow dr)
		{
			string RequiredFields = "";

			// Loop through Required Fields collection to see if any are empty
			if (this.RequiredFields.Count != 0)
			{
				foreach (string column in this.RequiredFields)
				{
					if (dr.Table.Columns.Contains(column) && 
						dr[column] == DBNull.Value)
					{
						RequiredFields += column + ", ";
					}
				}
			}
			// Remove any trailing commas
			if (RequiredFields != "")
			{
				RequiredFields = RequiredFields.Substring(0, RequiredFields.Length - 2);
			}

			return RequiredFields;
		}

		/// <summary>
		/// Returns a list of all empty required fields found in the specified DataRow
		/// </summary>
		/// <param name="dr">DataRow</param>
		/// <returns>ArrayList containg empty required fields</returns>
		public virtual ArrayList GetEmptyRequiredFieldsList(DataRow dr)
		{
			ArrayList RequiredFields = new ArrayList();

			// Loop through Required fields collection to see if any are empty
			if (this.RequiredFields.Count != 0)
			{
				foreach (string column in this.RequiredFields)
				{
					if (dr.Table.Columns.Contains(column) &&
						this.IsRequiredFieldEmpty(dr[column]))
					{
						RequiredFields.Add(column);
					}
				}
			}
			return RequiredFields;
		}

		/// <summary>
		/// Checks if the specified column of the specified DataRow is empty
		/// </summary>
		/// <param name="dr">DataRow</param>
		/// <param name="columnName">Data column name</param>
		/// <returns>True if empty of if DataRow is null</returns>
		public bool IsColumnEmpty(DataRow dr, string columnName)
		{
			bool Result = false;
			if (DataRow != null)
			{
				DataRow.IsNull(columnName);
			}
			return Result;
		}

		/// <summary>
		/// Checks if the specifed column of the current DataRow is empty.
		/// </summary>
		/// <param name="columnName">Column name</param>
		/// <returns>True if empty or if current DataRow is null</returns>
		public bool IsColumnEmpty(string columnName)
		{
			bool Result = false;
			if (this.DataRow != null)
			{
				Result = DataRow.IsNull(columnName);
			}
			return Result;
		}

		/// <summary>
		/// Adds a column name to the RequiredFields collection for each
		/// column in the specified table that has AllowDBNull = false
		/// </summary>
		/// <param name="dt">DataTable</param>
		public virtual void SetRequiredFieldsFromTableColumns(DataTable dt)
		{
			foreach (DataColumn column in dt.Columns)
			{
				if (!column.AllowDBNull && !column.AutoIncrement)
				{
					// If this column isn't already in the RequiredFields collection
					this.AddRequiredField(column.ColumnName);
				}
			}
		}

		/// <summary>
		/// Adds a column name to the RequiredFields collection for each column
		/// in the specified DataSet and table that has AllowDBNull = false
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="tableName">Table Name</param>
		public virtual void SetRequiredFieldsFromTableColumns(DataSet ds, string tableName)
		{
			this.SetRequiredFieldsFromTableColumns(ds.Tables[tableName]);
		}
	}
}
