// Copyright, 2004 Oak Leaf Enterprises Solution Design, Inc.
// No part of this software or its associated documentation 
// may be stored in a retrieval system, copied, transmitted, 
// distributed, transcribed or reproduced in any other way or 
// disclosed to any third parties without the written permission 
// of Oak Leaf Enterprises Solution Design, Inc.

using System;
using System.Data;

namespace OakLeaf.MM.Main.Business
{
	/// <summary>
	/// ErrorProviderArgs class
	/// </summary>
	public struct mmErrorProviderArgs
	{
		/// <summary>
		/// Error business object
		/// </summary>
		public mmBaseBusinessObject BusinessObject;
		/// <summary>
		/// Error DataSet
		/// </summary>
		public DataSet ErrorDataSet;
		/// <summary>
		/// Table Name
		/// </summary>
		public string TableName;
		/// <summary>
		/// DataView
		/// </summary>
		public DataView DataView;
		/// <summary>
		/// DataRow
		/// </summary>
		public int Row;
		/// <summary>
		/// Column Name
		/// </summary>
		public string ColumnName;
		/// <summary>
		/// Error Text
		/// </summary>
		public string ErrorText;
		/// <summary>
		/// Indicates if an error (false) or a warning (true)
		/// </summary>
		public bool Warning;

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="tableName">Table Name</param>
		/// <param name="row">Row</param>
		/// <param name="columnName">Column Name</param>
		/// <param name="errorText">Error text</param>
		/// <param name="warning">Indicates if it's a warning (true) or error (false)</param>
		public mmErrorProviderArgs(DataSet ds, string tableName, 
			int row, string columnName, string errorText, bool warning)
		{
			this.BusinessObject = null;
			this.ErrorDataSet = ds;
			this.TableName = tableName;
			this.DataView = null;
			this.Row = row;
			this.ColumnName = columnName;
			this.ErrorText = errorText;
			this.Warning = warning;
		}

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="dv">DataView</param>
		/// <param name="row">Row</param>
		/// <param name="columnName">Column name</param>
		/// <param name="errorText">Error text</param>
		/// <param name="warning">Indicates if it's a warning (true) or error (false)</param>
		public mmErrorProviderArgs(DataView dv,
			int row, string columnName, string errorText, bool warning)
		{
			this.BusinessObject = null;
			this.ErrorDataSet = dv.Table.DataSet;
			this.TableName = dv.Table.TableName;
			this.DataView = dv;
			this.Row = row;
			this.ColumnName = columnName;
			this.ErrorText = errorText;
			this.Warning = warning;
		}

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="bizObj">Error business object</param>
		/// <param name="memberName">Error Member name</param>
		/// <param name="errorText">Error text</param>
		/// <param name="warning">Indicates if it's a warning (true) or error (false)</param>
		public mmErrorProviderArgs(mmBaseBusinessObject bizObj,
			string memberName, string errorText, bool warning)
		{
			this.BusinessObject = bizObj;
			this.ErrorDataSet =  null;
			this.TableName = null;
			this.DataView = null;
			this.Row = -1;
			this.ColumnName = memberName;
			this.ErrorText = errorText;
			this.Warning = warning;
		}
	}
}
