// Copyright, 2006 Oak Leaf Enterprises Solution Design, Inc.
// No part of this software or its associated documentation 
// may be stored in a retrieval system, copied, transmitted, 
// distributed, transcribed or reproduced in any other way or 
// disclosed to any third parties without the written permission 
// of Oak Leaf Enterprises Solution Design, Inc.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Runtime.Serialization;
using System.Threading;

using OakLeaf.MM.Main.Collections;
using OakLeaf.MM.Main.Data;
using OakLeaf.MM.Main.Exceptions;

namespace OakLeaf.MM.Main.Business
{
	/// <summary>
	/// mmBusinessObjectGeneric
	/// </summary>
	public class mmBusinessObjectGeneric<EntityType> : mmBusinessObject
		where EntityType : mmBusinessEntity, new()
	{
		/// <summary>
		/// Entity
		/// </summary>
		public virtual EntityType Entity
		{
			get { return _entity; }
			set { _entity = value; }
		}
		private EntityType _entity;

		/// <summary>
		/// Entity List
		/// </summary>
		public virtual mmBindingList<EntityType> EntityList
		{
			get { return _entityList; }
			set { _entityList = value; }
		}
		private mmBindingList<EntityType> _entityList;

		/// <summary>
		/// Constructor
		/// </summary>
		public mmBusinessObjectGeneric()
		{

		}

		/// <summary>
		/// Factory method that creates an Entity object
		/// </summary>
		/// <returns></returns>
		public virtual EntityType CreateEntityObject()
		{
			return new EntityType();
		}

		/// <summary>
		/// Creates an Entity List from the default DataSet/DataTable
		/// </summary>
		/// <returns></returns>
		public virtual mmBindingList<EntityType> CreateEntityList()
		{
			this.EntityList = this.CreateEntityList<EntityType>();
			return this.EntityList;
		}

		/// <summary>
		/// Retrieves all entities using the default SELECT stored procedure
		/// if DefaultCommandType = CommandType.StoredProcedure and the
		/// business object has an associated custom data access class.
		/// If DefaultCommandType = CommandType.Text a dynamic SQL SELECT
		/// statement is generated from the default PhysicalDbcObjectName
		/// </summary>
		/// <returns></returns>
		public virtual mmBindingList<EntityType> GetAllEntities()
		{
			this.GetAllData();
			return this.CreateEntityList();
		}

		/// <summary>
		/// (1) Returns a new Business Entity of the default EntityType containing the results of the command string 
		/// (based on the specified command type) w/ parameters executed against the specified database.
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="databaseKey">Database</param>
		/// <param name="cmdType">CommandType</param>
		/// <param name="dataParams">Command parameters</param>
		/// <returns>Entity object</returns>
		protected virtual EntityType GetEntity(string command, string databaseKey,
			CommandType cmdType, params IDbDataParameter[] dataParams)
		{
			// Create a DataSet
			DataSet ds = this.CreateDataSet();

			// Fill the DataTable in the DataSet
			this.FillDataSet(ds, command, this.TableName, databaseKey, cmdType, dataParams);

			// Create the entity object
			EntityType Entity = this.CreateEntityObject();

			if (this.DataRow != null)
			{
				Entity.SetDataRow(this.DataRow);
			}
			return Entity;
		}

		/// <summary>
		/// (2) Returns a new Business Entity of the default EntityType containing the results of the command string 
		/// (based on the specified command type) w/ parameters executed against the default database.
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="cmdType">CommandType</param>
		/// <param name="dataParams">Command parameters</param>
		/// <returns>Entity object</returns>
		protected virtual EntityType GetEntity(string command, CommandType cmdType, params IDbDataParameter[] dataParams) 
		{
			return this.GetEntity(command, this.DatabaseKey, cmdType, dataParams);
		}

		/// <summary>
		/// (3) Returns a new Business Entity of the default EntityType containing the results of the command string 
		/// (based on the DefaultCommandType) w/ parameters executed against the specified database.
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="databaseKey">Database key</param>
		/// <param name="dataParams">Command Parameters</param>
		/// <returns>Entity object</returns>
		protected virtual EntityType GetEntity(string command, string databaseKey, params IDbDataParameter[] dataParams) 
		{
			return this.GetEntity(command, databaseKey, this.DefaultCommandType, dataParams);
		}

		/// <summary>
		/// (4) Returns a new Business Entity of the default EntityType containing the results of the command string 
		/// (based on the DefaultCommandType) w/ parameters executed against the default database.
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="dataParams">Command parameters</param>
		/// <returns>Entity object</returns>
		protected virtual EntityType GetEntity(string command, params IDbDataParameter[] dataParams) 
		{
			return this.GetEntity(command, this.DatabaseKey, dataParams);
		}


		/// <summary>
		/// (5) Returns a new Business Entity of the default EntityType containing the results of the command string 
		/// (based on the DefaultCommandType) executed against the specified database.
		/// </summary>
		/// <param name="command">Command string to be executed</param>
		/// <param name="databaseKey">Database key</param>
		/// <returns>Entity object</returns>
		protected virtual EntityType GetEntity(string command, string databaseKey)
		{
			return this.GetEntity(command, databaseKey, (IDbDataParameter[])null);
		}

		/// <summary>
		/// (6) Returns a new Business Entity of the default EntityType containing the results 
		/// of the command string (based on the DefaultCommandType) executed against the default database
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <returns>Entity object</returns>
		protected virtual EntityType GetEntity(string command)
		{
			return this.GetEntity(command, this.DatabaseKey);
		}

		/// <summary>
		/// (7) Returns a new Business Entity of the default EntityType containing the results 
		/// of the command string (based on command type) executed against the specified database. 
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="databaseKey">Database key</param>
		/// <param name="cmdType">CommandType</param>
		/// <returns>Entity object</returns>
		protected virtual EntityType GetEntity(string command, string databaseKey, CommandType cmdType)
		{
			return this.GetEntity(command, databaseKey, cmdType, (IDbDataParameter[])null);
		}

		/// <summary>
		/// (8) Returns a new Business Entity of the default EntityType containing the results 
		/// of the command string (based on command type) executed against the default database. 
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="cmdType">CommandType</param>
		/// <returns>Entity object</returns>
		protected virtual EntityType GetEntity(string command, CommandType cmdType)
		{
			return this.GetEntity(command, this.DatabaseKey, cmdType);
		}

		/// <summary>
		/// (1) Returns a list of Business Entity objects of the default EntityType
		/// containing the results of the command (based on the specified command type) 
		/// w/ parameters executed against the specified database
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="databaseKey">Database</param>
		/// <param name="cmdType">CommandType</param>
		/// <param name="dataParams">Command parameters</param>
		/// <returns>Entity List containing the result set</returns>
		protected virtual mmBindingList<EntityType> GetEntityList(string command, string databaseKey,	
			CommandType cmdType, params IDbDataParameter[] dataParams) 
		{
			// Create a DataSet
			DataSet ds = this.CreateDataSet();

			// Fill the DataSet
			this.FillDataSet(ds, command, this.TableName, databaseKey, cmdType, dataParams);

			this.EntityList = this.CreateEntityList<EntityType>(ds.Tables[this.TableName]);

			return this.EntityList;
		}

		/// <summary>
		/// (2) Returns list of Business Entity objects of the default EntityType
		/// containing the results of the command (based on the specified command type) 
		/// w/ parameters executed against the default database
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="cmdType">CommandType</param>
		/// <param name="dataParams">Command parameters</param>
		/// <returns>Entity List containing the result set</returns>
		protected virtual mmBindingList<EntityType> GetEntityList(string command, CommandType cmdType,
			params IDbDataParameter[] dataParams)
		{
			return this.GetEntityList(command, this.DatabaseKey, cmdType, dataParams);
		}

		/// <summary>
		/// (3) Returns a list of Business Entity objects of the default EntityType
		/// containing the results of the command (based on the DefaultCommandType) 
		/// w/ parameters executed against the specified database
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="databaseKey">Database key</param>
		/// <param name="dataParams">Command Parameters</param>
		/// <returns>Entity List containing result set</returns>
		protected virtual mmBindingList<EntityType> GetEntityList(string command, string databaseKey,
			params IDbDataParameter[] dataParams)
		{
			return this.GetEntityList(command, databaseKey, this.DefaultCommandType, dataParams);
		}

		/// <summary>
		/// (4) Returns a list of Business Entity objects of the default EntityType
		/// containing the results of the command string (based on the DefaultCommandType)
		/// w/ parameters executed against the default database
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="dataParams">Command parameters</param>
		/// <returns>Entity List containing result set</returns>
		protected virtual mmBindingList<EntityType> GetEntityList(string command, params IDbDataParameter[] dataParams) 
		{
			return this.GetEntityList(command, this.DatabaseKey, dataParams);
		}

		/// <summary>
		/// (5) Returns a list of Business Entity objects of the default EntityType
		/// containing the results of the command string (based on DefaultCommandType)
		/// executed against the specified database.
		/// </summary>
		/// <param name="command">Command string to be executed</param>
		/// <param name="databaseKey">Database key</param>
		/// <returns>Entity List containing result set</returns>
		protected virtual mmBindingList<EntityType> GetEntityList(string command, string databaseKey)
		{
			return this.GetEntityList(command, databaseKey, (IDbDataParameter[])null);
		}

		/// <summary>
		/// (6) Returns a list of Business Entity objects of the default EntityType 
		/// containing the results of the command string (based on the DefaultCommandType) 
		/// executed against the default database
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <returns>Entity List containing result set</returns>
		protected virtual mmBindingList<EntityType> GetEntityList(string command)
		{
			return this.GetEntityList(command, this.DatabaseKey);
		}

		/// <summary>
		/// (7) Returns a list of Business Entity objects of the default EntityType
		/// containing the results of the command string (based on the specified command type) 
		/// executed against the specified database. 
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="databaseKey">Database key</param>
		/// <param name="cmdType">CommandType</param>
		/// <returns>DataSet containing result</returns>
		protected virtual mmBindingList<EntityType> GetEntityList(string command, string databaseKey, CommandType cmdType)
		{
			return this.GetEntityList(command, databaseKey, cmdType, (IDbDataParameter[])null);
		}

		/// <summary>
		/// (8) Returns a list of Business Entity objects of the default EntityType
		/// containing the results of the command string (based on the specified command type) 
		/// executed against the default database. 
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="cmdType">CommandType</param>
		/// <returns>Entity List containing result set</returns>
		protected virtual mmBindingList<EntityType> GetEntityList(string command, CommandType cmdType)
		{
			return this.GetEntityList(command, this.DatabaseKey, cmdType);
		}


		/// <summary>
		/// If an EntityList exists, adds a new Entity
		/// </summary>
		/// <param name="ds"></param>
		/// <param name="tableName"></param>
		/// <param name="defaultValues"></param>
		/// <returns></returns>
		public override DataRow NewRow(System.Data.DataSet ds, string tableName, object defaultValues)
		{
			DataRow Row = base.NewRow(ds, tableName, defaultValues);

			if (tableName == this.TableName)
			{
				if (EntityList != null)
				{
					EntityType EntityObject = this.CreateEntityObject();
					EntityObject.SetDataRow(Row);
					this.EntityList.Add(EntityObject);
				}
			}

			return Row;
		}

		/// <summary>
		/// Creates a new entity object populated with the specified default values
		/// </summary>
		/// <param name="defaultValues">Default values object</param>
		/// <returns>New entity object</returns>
		public virtual EntityType NewEntity(object defaultValues)
		{
			DataRow Row = this.NewRow(defaultValues);
			EntityType EntityObject = this.CreateEntityObject();
			EntityObject.SetDataRow(Row);
			if (EntityList != null)
			{
				this.EntityList.Add(EntityObject);
			}
			return EntityObject;
		}

		/// <summary>
		/// Creates a new Entity Object
		/// </summary>
		/// <returns></returns>
		public virtual EntityType NewEntity()
		{
			return this.NewEntity(null);
		}

		/// <summary>
		/// Persists the business object's Entity List
		/// </summary>
		/// <returns>mmSaveDataResult value</returns>
		public virtual mmSaveDataResult SaveEntityList()
		{
			// This method is a wrapper for SaveDataSet() to help avoid
			// confusion for developers only working with entities.
			// In the future it will have the option to work without
			// an associated DataSet
			return this.SaveDataSet();
		}

		/// <summary>
		/// Persists the business object's Entity
		/// </summary>
		/// <returns>mmSaveDataResult value</returns>
		public virtual mmSaveDataResult SaveEntity()
		{
			// This method is a wrapper for SaveDataSet() to help avoid
			// confusion for developers only working with entities.
			// In the future it will have the option to work without
			// an associated DataSet
			return this.SaveDataSet();
		}

	}
}
