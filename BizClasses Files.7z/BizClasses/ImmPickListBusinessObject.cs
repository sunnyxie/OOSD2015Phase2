// Copyright, 2004 Oak Leaf Enterprises Solution Design, Inc.
// No part of this software or its associated documentation 
// may be stored in a retrieval system, copied, transmitted, 
// distributed, transcribed or reproduced in any other way or 
// disclosed to any third parties without the written permission 
// of Oak Leaf Enterprises Solution Design, Inc.

using System;
using System.Data;
using OakLeaf.MM.Main.Data;

namespace OakLeaf.MM.Main.Business
{
	/// <summary>
	/// Summary description for ImmPickListBusinessObject.
	/// </summary>
	public interface ImmPickListBusinessObject
	{
		/// <summary>
		/// DatabaseKey property
		/// </summary>
		string DatabaseKey
		{
			get;
			set;
		}

		/// <summary>
		/// Returns an instance of a data access object for the
		/// business object's default database key
		/// </summary>
		/// <returns>Data access object</returns>
		mmDataAccessBase GetDataAccessObject();

		/// <summary>
		/// Retrieves a DataSet containing a picklist retrieved using the specified command and
		/// optional parameters
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="cmdType">Command type</param>
		/// <param name="parameters">Optional parameters</param>
		/// <returns>Picklist DataSet</returns>
		DataSet GetPickList(string command, CommandType cmdType, IDbDataParameter[] parameters);

		/// <summary>
		/// Returns a DataSet containing a result set based on the
		/// picklist criteria
		/// </summary>
		/// <param name="command">Command to be executed </param>
		/// <param name="cmdType">Command type</param>
		/// <param name="whereClause">Where clause</param>
		/// <param name="parameters">Optional parameters</param>
		/// <returns>Picklist DataSet</returns>
		DataSet GetPickList(string command, CommandType cmdType, string whereClause,
			IDbDataParameter[] parameters);

		/// <summary>
		/// Sets the business object's DatabaseKey property to the specified value. 
		/// If databaseKey is empty, tries to get the key from the config file
		/// </summary>
		/// <param name="databaseKey">Database key</param>
		void SetDatabaseKey(string databaseKey);
	}
}
