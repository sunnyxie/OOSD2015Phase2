// Copyright, 2002 Oak Leaf Enterprises Solution Design, Inc.
// No part of this software or its associated documentation 
// may be stored in a retrieval system, copied, transmitted, 
// distributed, transcribed or reproduced in any other way or 
// disclosed to any third parties without the written permission 
// of Oak Leaf Enterprises Solution Design, Inc.
using System;

namespace OakLeaf.MM.Main.Business
{
	/// <summary>
	/// Business State enumeration
	/// </summary>
	public enum mmBusinessState
	{
		/// <summary>
		/// Adding a new row
		/// </summary>
		Adding = 1,
		/// <summary>
		/// A new row was added
		/// </summary>
		Added = 2,
		/// <summary>
		/// Canceling pending changes
		/// </summary>
		Canceling = 3,
		/// <summary>
		/// Pending changes canceled
		/// </summary>
		Canceled = 4,
		/// <summary>
		/// Deleting the current row
		/// </summary>
		Deleting = 5,
		/// <summary>
		/// The current row was deleted
		/// </summary>
		Deleted = 6,
		/// <summary>
		/// Navigating to a different row
		/// </summary>
		Navigating = 7,
		/// <summary>
		/// Navigated to a different row
		/// </summary>
		Navigated = 8,
		/// <summary>
		/// Retrieving new data
		/// </summary>
		Retrieving = 9,
		/// <summary>
		/// New data was retrieved
		/// </summary>
		Retrieved = 10,
		/// <summary>
		/// Saving before checking business rules
		/// </summary>
		PreSaving = 11,
		/// <summary>
		/// Saving after checking business rules
		/// </summary>
		Saving = 12,
		/// <summary>
		/// Data was saved
		/// </summary>
		Saved = 13,
		/// <summary>
		/// Bind
		/// </summary>
		Bind = 14,
		/// <summary>
		/// Broken Rules or warnings
		/// </summary>
		BrokenRulesWarnings = 15,
		/// <summary>
		/// Updating the object with current values from the data source
		/// </summary>
		ReSyncing = 16,
		/// <summary>
		/// Updated the object with current values from the data source
		/// </summary>
		ReSynced = 17,
        /// <summary>
		/// Updating the value of the primary key 
		/// </summary>
		UpdatingPKValue = 18,
		/// <summary>
		/// Updated the value of the primary key
		/// </summary>
		UpdatedPKValue = 19
	}
}
