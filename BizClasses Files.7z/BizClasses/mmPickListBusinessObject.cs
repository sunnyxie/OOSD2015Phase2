// Copyright, 2004 Oak Leaf Enterprises Solution Design, Inc.
// No part of this software or its associated documentation 
// may be stored in a retrieval system, copied, transmitted, 
// distributed, transcribed or reproduced in any other way or 
// disclosed to any third parties without the written permission 
// of Oak Leaf Enterprises Solution Design, Inc.

using System;
using System.Collections;
using System.Data;

using OakLeaf.MM.Main.Business;
using OakLeaf.MM.Main.Data;

namespace OakLeaf.MM.Main.Business
{
	/// <summary>
	/// Summary description for gcPickListBusinessObject.
	/// </summary>
	public class mmPickListBusinessObject : ILBusinessObject, ImmPickListBusinessObject
	{
		/// <summary>
		/// Constructor
		/// </summary>
		public mmPickListBusinessObject()
		{
			this.TableName = "PickList";
		}

		#region ImmPickListBusinessObject Members

		/// <summary>
		/// Returns a DataSet containing a result set based on the
		/// picklist criteria
		/// </summary>
		/// <param name="command">Command to be executed </param>
		/// <param name="cmdType">Command type</param>
		/// <param name="parameters">Optional parameters</param>
		/// <returns>Picklist DataSet</returns>
		public virtual DataSet GetPickList(string command, CommandType cmdType, IDbDataParameter[] parameters)
		{
			DataSet dsPickList = null;
			mmDataAccessBase dao = this.GetDataAccessObject();

			if (parameters != null)
			{
//				IDbDataParameter[] Parameters = new IDbDataParameter[parameters.Length];
//				for(int i=0; i<parameters.Length; i++)
//				{
//					Parameters[i] = dao.CreateParameter("@param"+i.ToString(), parameters[i]);
//				}
				dsPickList = this.GetDataSet(command, cmdType, parameters);
			}
			else
			{
				dsPickList = this.GetDataSet(command, cmdType);
			}
			return dsPickList;
		}

		/// <summary>
		/// Returns a DataSet containing a result set based on the
		/// picklist criteria
		/// </summary>
		/// <param name="command">Command to be executed </param>
		/// <param name="cmdType">Command type</param>
		/// <param name="whereClause">Where clause</param>
		/// <param name="parameters">Optional parameters</param>
		/// <returns>Picklist DataSet</returns>
		public virtual DataSet GetPickList(string command, CommandType cmdType, string whereClause,
			IDbDataParameter[] parameters)
		{
			DataSet dsPickList =  null;

			switch (cmdType)
			{
				case CommandType.StoredProcedure:
					dsPickList = this.GetPickList(command, cmdType, parameters);
					break;
				case CommandType.Text:
					dsPickList = this.GetPickList(command + " " + whereClause, cmdType, parameters);
					break;
			}
			return dsPickList;
		}

		/// <summary>
		/// Sets the business object's DatabaseKey property to the specified value. 
		/// If databaseKey is empty, tries to get the key from the config file
		/// </summary>
		/// <param name="databaseKey">Database key</param>
		public void SetDatabaseKey(string databaseKey)
		{
			// Set the database key if specified
			if (mmString.Empty(databaseKey))
			{
				if (mmString.Empty(this.DatabaseKey))
				{
					ArrayList DatabaseNames = mmAppBase.DatabaseMgr.GetUniqueDatabaseNames();
					if (DatabaseNames.Count == 0)
					{
						throw new Exception("No database information specified in the application configuration file");
					}
					else if (DatabaseNames.Count > 1)
					{
						throw new Exception("You must specify a DatabaseKey on the Picker control");
					}
					this.DatabaseKey = DatabaseNames[0].ToString();
				}
			}
			else
			{
				this.DatabaseKey = databaseKey;
			}
		}

		#endregion
	}
}
