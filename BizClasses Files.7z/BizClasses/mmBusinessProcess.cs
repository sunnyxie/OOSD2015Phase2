// Copyright, 2002 Oak Leaf Enterprises Solution Design, Inc.
// No part of this software or its associated documentation 
// may be stored in a retrieval system, copied, transmitted, 
// distributed, transcribed or reproduced in any other way or 
// disclosed to any third parties without the written permission 
// of Oak Leaf Enterprises Solution Design, Inc.

using System;
using System.Data;

using OakLeaf.MM.Main;
using OakLeaf.MM.Main.Collections;
using System.Collections.Generic;

namespace OakLeaf.MM.Main.Business
{
	/// <summary>
	/// Business process base class. Coordinates a sequence of 
	/// message calls to two or more business objects
	/// </summary>
	public abstract class mmBusinessProcess : MarshalByRefObject, ImmBusinessRuleHost
	{
		/// <summary>
		/// Collection of Participating objects
		/// </summary>
		public mmReferenceCollection ParticipatingObjectCollection = new mmReferenceCollection();

		/// <summary>
		/// Specifies if business object broken rules should be added
		/// to the business process object's broken rule collection
		/// </summary>
		protected bool AddBrokenRulesToProcess = true;

		/// <summary>
		/// Business Rule object
		/// </summary>
		protected mmBusinessRule BusinessRuleObj
		{
			get
			{
				// If it hasn't been created yet, create it
				if (this._businessRuleObj == null)
				{
					this._businessRuleObj = this.CreateBusinessRuleObject();
				}
				return this._businessRuleObj;
			}

			set { this._businessRuleObj = value; }
		}
		private mmBusinessRule _businessRuleObj;

		/// <summary>
		/// Reference to business rule object
		/// </summary>
		public mmBusinessRule Rules
		{
			get { return this.BusinessRuleObj; }
			set { this.BusinessRuleObj = value; }
		}

		/// <summary>
		/// BusinessProcess constructor
		/// </summary>
		public mmBusinessProcess()
		{
			DefineParticipatingObjects();
		}

		/// <summary>
		/// BusinessProcess constructor
		/// </summary>
		/// <param name="defineEntities"></param>
		public mmBusinessProcess(bool defineEntities)
		{
			if (defineEntities)
				this.DefineParticipatingObjects();
		}

		/// <summary>
		/// Provides a hook into which code can be placed to define the 
		/// entities that are participating in the business event
		/// </summary>
		protected virtual void DefineParticipatingObjects()
		{
		}

		/// <summary>
		/// Creates an associated business rule object
		/// </summary>
		protected virtual mmBusinessRule CreateBusinessRuleObject()
		{
			// Note: this can be overridden in derived classes
			return mmAppBase.Factory.CreateBusinessRule(this);
		}

		/// <summary>
		/// An empty, virtual method that, in derived classes, can contain
		/// instance-specific code that calls various methods on the
		/// participating business objects
		/// </summary>
		/// <returns>mmSaveDataResult</returns>
		public virtual mmSaveDataResult ExecuteEvent()
		{
			return mmSaveDataResult.RulesPassed;
		}

		/// <summary>
		/// Returns a reference to the business rule object
		/// </summary>
		/// <returns>Business rule object</returns>
		public virtual mmBusinessRule GetBusinessRuleObject()
		{
			return this.BusinessRuleObj;
		}

		/// <summary>
		/// Returns a reference collection containing all business objects
		/// that participate in the event
		/// </summary>
		/// <returns>Reference collection</returns>
		public virtual mmReferenceCollection GetParticipatingObjects()
		{
			return this.ParticipatingObjectCollection;
		}

		/// <summary>
		/// Gets the current DataSet returned from the business object
		/// </summary>
		/// <returns>Current DataSet</returns>
		public virtual DataSet GetCurrentDataSet()
		{
			return this._currentDataSet;
		}
		private DataSet _currentDataSet = null;

		/// <summary>
		/// Provides a hook into which code can be placed to be executed
		/// when a broken rule is added to the associated rules object
		/// </summary>
		/// <param name="brokenRule">Broken rule string</param>
		public virtual void OnBrokenRuleAdd(string brokenRule)
		{
		}
		/// <summary>
		/// Provides a hook into which code can be placed to be executed when
		/// a broken rule is cleared from the associated rules object
		/// </summary>
		/// <param name="brokenRule">Broken rule string</param>		
		public virtual void OnBrokenRuleClear(string brokenRule)
		{
		}
		/// <summary>
		/// Provides a hook into which code can be placed to be executed when
		/// a warning is added to the associated rules object
		/// </summary>
		/// <param name="warning">Warning string</param>
		public virtual void OnWarningAdd(string warning)
		{
		}
		/// <summary>
		/// Provides a hook into which code can be placed to be executed when
		/// a warning is cleared from the associated rules object
		/// </summary>
		/// <param name="warning">Warning string</param>
		public virtual void OnWarningClear(string warning)
		{
		}

		/// <summary>
		/// Provides a hook into which code can be placed to be executed when
		/// an ErrorProvider broken rule is added
		/// </summary>
		/// <param name="arg">Error Provider argument</param>
		public virtual void OnErrorProviderBrokenRuleAdd(mmErrorProviderArgs arg)
		{
		}
		/// <summary>
		/// Provides a hook into which code can be placed to be executed when
		/// an ErrorProvider warning is added
		/// </summary>
		/// <param name="arg">Error Provider argument</param>	
		public virtual void OnErrorProviderWarningAdd(mmErrorProviderArgs arg)
		{
		}

		/// <summary>
		/// Registers the business process object as a listener for 
		/// the specified business object's events
		/// </summary>
		/// <param name="businessObject">Business object</param>
		public virtual mmBusinessObject RegisterBizObj(mmBusinessObject businessObject)
		{
			businessObject.StateChange +=
				new mmBusinessStateChangeDelegate(this.StateChangeHandler);
			return businessObject;
		}

		/// <summary>
		/// Business State Change event handler. This handler allows a 
		/// business object to handle events raised by other business objects
		/// </summary>
		/// <param name="bizObj">Business object event source</param>
		/// <param name="e">mmBusinessStateChangeEventArgs</param>
		public virtual void StateChangeHandler(mmBaseBusinessObject bizObj, mmBusinessStateChangeEventArgs e)
		{
			if (e.State == mmBusinessState.BrokenRulesWarnings)
			{
				if (this.AddBrokenRulesToProcess)
				{
					mmErrorProviderArgs args = (mmErrorProviderArgs)e.PrimaryKeyValue;
					if (args.Warning)
					{
						this.BusinessRuleObj.AddErrorProviderWarning(args);
					}
					else
					{
						this.BusinessRuleObj.AddErrorProviderBrokenRule(args);
					}
				}
			}
		}
	}

}
