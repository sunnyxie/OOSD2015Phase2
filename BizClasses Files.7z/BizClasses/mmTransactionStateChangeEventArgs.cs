// Copyright, 2002 Oak Leaf Enterprises Solution Design, Inc.
// No part of this software or its associated documentation 
// may be stored in a retrieval system, copied, transmitted, 
// distributed, transcribed or reproduced in any other way or 
// disclosed to any third parties without the written permission 
// of Oak Leaf Enterprises Solution Design, Inc.

using System;
using System.Data;

namespace OakLeaf.MM.Main.Business
{
	/// <summary>
	/// Transaction state change event arg class
	/// </summary>
	public class mmTransactionStateChangeEventArgs : EventArgs
	{
		private mmTransactionState _state;
		/// <summary>
		/// State property
		/// </summary>
		public mmTransactionState State
		{
			get { return this._state; }
			set { this._state = value; }
		}

		private string _databaseKey;
		/// <summary>
		/// Database Key property
		/// </summary>
		public string DatabaseKey
		{
			get { return this._databaseKey; }
			set { this._databaseKey = value; }
		}
		
		private IDbConnection _connection;
		/// <summary>
		/// Connection property
		/// </summary>
		public IDbConnection Connection
		{
			get { return this._connection; }
			set { this._connection = value; }
		}

		private IDbTransaction _transaction;
		/// <summary>
		/// Transaction property
		/// </summary>
		public IDbTransaction Transaction
		{
			get { return this._transaction; }
			set { this._transaction = value; }
		}

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="trxState">Transaction state</param>
		/// <param name="databaseKey">Database key</param>
		/// <param name="conn">Connection</param>
		/// <param name="trx">Transaction object</param>
		public mmTransactionStateChangeEventArgs(mmTransactionState trxState,
			string databaseKey, IDbConnection conn, IDbTransaction trx)
		{
			this.State = trxState;
			this.DatabaseKey = databaseKey;
			this.Connection = conn;
			this.Transaction = trx;
		}
	}
}
