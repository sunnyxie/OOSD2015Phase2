// Copyright, 2002 Oak Leaf Enterprises Solution Design, Inc.
// No part of this software or its associated documentation 
// may be stored in a retrieval system, copied, transmitted, 
// distributed, transcribed or reproduced in any other way or 
// disclosed to any third parties without the written permission 
// of Oak Leaf Enterprises Solution Design, Inc.

using System;
using System.Data;

namespace OakLeaf.MM.Main.Business
{
	/// <summary>
	/// Business Object Memento
	/// </summary>
	[Serializable()]
	public class mmBusinessMemento
	{
		internal bool AddBrokenRulesToParent;

		internal bool AutoCancelOnCancelParent;

		internal bool AutoCheckRules;

		internal bool AutoDeleteOnParentDeleted;

		internal bool AutoEmptyOnParentAdded;

		internal bool AutoEndEdit;

		internal bool AutoIncrementCustom;

		internal int AutoIncrementSeed;

		internal int AutoIncrementStep;

		internal bool AutoNewOnParentAdded;

		internal bool AutoRaiseStateChangeEvents;

		internal bool AutoSaveOnParentSaved;

		internal bool AutoUseTransactions;

		internal bool CacheDataAccessObjects;

		internal bool ClearOnFillDataSet;

		internal string ConcurrencySelectStatement;

		internal string CurrentTableName;

		internal string DataAccessClass;

		internal string DatabaseKey;

		internal CommandType DefaultCommandType;

		internal object DefaultValues;

		internal string DescriptionField;

		internal string[] DescriptionFields;

		internal string ForeignParentKeyField;

		internal bool ImmediateDelete;

		internal bool ParameterTranslation;

		internal string ParentBizObjTable;

		internal object ParentKeyValue;

		internal object[] ParentKeyValues;

		internal mmBusinessState ParentState;

		internal string PhysicalDbcObjectName;

		internal string PrimaryKey;

		internal string[] PrimaryKeys;

		internal bool RetrieveAutoIncrementPK;

		internal bool SetRequiredFieldsFromDataSet;

		internal mmBusinessState State;

		internal string TableName;

		internal string UpdateSelectStatement;

		internal bool UseErrorProvider;
	}

}
