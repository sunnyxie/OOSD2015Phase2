// Copyright, 2002 Oak Leaf Enterprises Solution Design, Inc.
// No part of this software or its associated documentation 
// may be stored in a retrieval system, copied, transmitted, 
// distributed, transcribed or reproduced in any other way or 
// disclosed to any third parties without the written permission 
// of Oak Leaf Enterprises Solution Design, Inc.

//#define OracleClient

using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Runtime.Serialization;
using System.Threading;

using OakLeaf.MM.Main.Collections;
using OakLeaf.MM.Main.Data;
using OakLeaf.MM.Main.Exceptions;

namespace OakLeaf.MM.Main.Business
{
	/// <summary>
	/// Business Object base class	
	/// </summary>
	[Serializable]
	public class mmBusinessObject : mmAbstractBusinessObject, ImmBusinessRuleHost
	{

		#if EvaluationCopy
			private static int SWCounter = 0; 
		#endif

		/// <summary>
		/// Insert Command
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public string InsertCommand
		{
			get { return _insertCommand; }
			set { _insertCommand = value; }
		}
		private string _insertCommand;

		/// <summary>
		/// Update Command
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public string UpdateCommand
		{
			get { return _updateCommand; }
			set { _updateCommand = value; }
		}
		private string _updateCommand;

		/// <summary>
		/// Delete Command
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public string DeleteCommand
		{
			get { return _deleteCommand; }
			set { _deleteCommand = value; }
		}
		private string _deleteCommand;

		/// <summary>
		/// Default sort order for GetAllData() method
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public string DefaultSortOrder
		{
			get { return _defaultSortOrder; }
			set { _defaultSortOrder = value; }
		}
		private string _defaultSortOrder;

		/// <summary>
		/// Number of rows updated on save
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public int RowsUpdatedOnSave
		{
			get { return _rowsUpdatedOnSave; }
			set { _rowsUpdatedOnSave = value; }
		}
		private int _rowsUpdatedOnSave = -1;

		/// <summary>
		/// Auto Increment Column
		/// </summary>
		protected const string AUTOINCREMENTCOLUMN = "AutoIncrementColumn";
		/// <summary>
		/// Next Increment Value
		/// </summary>
		protected const string NEXTINCREMENTVALUE = "NextIncrementValue";

		/// <summary>
		/// Specifies if broken rules are automatically added to the parent business object
		/// </summary>
		[Description("Specifies if broken rules are automatically added to the parent business object."),
		Category("Rules"), 
		DefaultValue(true)]
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool AddBrokenRulesToParent
		{
			get { return _addBrokenRulesToParent; }
			set { _addBrokenRulesToParent = value; }
		}
		private bool _addBrokenRulesToParent = true;

		/// <summary>
		/// Specifies if the business object automatically issues an
		/// EndEdit on all rows with pending changes when saving a DataSet
		/// </summary>
		[Description("Specifies if the business object automatically issues " + 
			 "an EndEdit on all rows with pending changes when saving a DataSet."),
		Category("Data"), 
		DefaultValue(false)]
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool AutoEndEdit
		{
			get { return this._autoEndEdit; }
			set { this._autoEndEdit = value; }
		}
		private bool _autoEndEdit = false;

		
		/// <summary>
		/// Specifies if the business object provides custom autoincrement column values
		/// </summary>
		protected virtual bool AutoIncrementCustom
		{
			get { return _autoIncrementCustom; }
			set { _autoIncrementCustom = value; }
		}
		private bool _autoIncrementCustom = false;

		/// <summary>
		/// If AutoIncrementCustom is true, specifies the starting value of autoincrement columns
		/// </summary>
		protected virtual int AutoIncrementSeed
		{
			get { return _autoIncrementSeed; }
			set { _autoIncrementSeed = value; }
		}
		private int _autoIncrementSeed = -1;

		/// <summary>
		/// If AutoIncrementCustom is true, specifies the increment of autoincrement columns
		/// </summary>
		[Description("If AutoIncrementCustom is true, specifies the starting value of autoincrement columns."),
		Category("Data"), 
		DefaultValue(-1)]
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual int AutoIncrementStep
		{
			get { return _autoIncrementStep; }
			set { _autoIncrementStep = value; }
		}
		private int _autoIncrementStep = -1;

		/// <summary>
		/// Specifies if Transactions should automatically be used when saving data
		/// </summary>
		[Description("Specifies if Transactions should automatically be used when saving data."),
		Category("Data"), 
		DefaultValue(true)]
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool AutoUseTransactions
		{
			get { return _autoUseTransactions; }
			set { _autoUseTransactions = value; }
		}
		private bool _autoUseTransactions = true;

		/// <summary>
		/// Specifies if this object's Cancel method is automatically called when
		/// its parent business object raises the Canceled state change event.
		/// </summary>
        [Description("Specifies if this object's Cancel method is automatically called " +
			 "when its parent business object raises the Canceled state change event."),
		Category("Data"), 
		DefaultValue(false)]
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool AutoCancelOnParentCancel
		{
			get { return _autoCancelOnParentCanceled; }
			set { _autoCancelOnParentCanceled = value; }
		}
		private bool _autoCancelOnParentCanceled;

		/// <summary>
		/// Specifies if this object's Delete method is automatically called when
		/// its parent business object raises the Deleted state change event.
		/// </summary>
		[Description("Specifies if this object's Delete method is automatically called " +
			 "when its parent business object raises the Deleted state change event."),
		Category("Data"), 
		DefaultValue(false)]
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool AutoDeleteOnParentDeleted
		{
			get { return _autoDeleteOnParentDeleted; }
			set { _autoDeleteOnParentDeleted = value; }
		}
		private bool _autoDeleteOnParentDeleted;

		/// <summary>
		/// Specifies if this object's NewRow method is automatically called when
		/// its parent business object raises the Added state change event.
		/// </summary>
		[Description("Specifies if this object's New method is automatically called " +
			 "when its parent business object raises the Added state change event."),
		Category("Data"), 
		DefaultValue(false)]
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool AutoNewOnParentAdded
		{
			get { return _autoNewOnParentAdded; }
			set { _autoNewOnParentAdded = value; }
		}
		private bool _autoNewOnParentAdded;


		/// <summary>
		/// Specifies if the business object should automatically raise StateChange events
		/// </summary>
		[Description("Specifies if the business object should automatically raise StateChange events"),
		Category("Data"),
		DefaultValue(true)]
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public bool AutoRaiseStateChangeEvents
		{
			get { return _autoRaiseStateChangeEvents; }
			set { _autoRaiseStateChangeEvents = value; }
		}
		private bool _autoRaiseStateChangeEvents = true;

		
		/// <summary>
		/// Specifies if this object's Save method is automatically called when
		/// its parent business object raises the Saved state change event
		/// </summary>
		[Description("Specifies if this object's Save method is automatically called " +
			 "when its parent business object raises the Saved state change event."),
		Category("Data"), 
		DefaultValue(false)]
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool AutoSaveOnParentSaved
		{
			get { return _autoSaveOnParentSaved; }
			set { _autoSaveOnParentSaved = value; }
		}
		private bool _autoSaveOnParentSaved;

		/// <summary>
		/// Specifies if this object's GetEmptyDataSet method is automatically called when
		/// its parent business object raises the Added state change event.
		/// </summary>
		[Description("Specifies if business rules are automatically checked when saving data."),
		Category("Rules"), 
		DefaultValue(false)]
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool AutoEmptyOnParentAdded
		{
			get { return this._autoEmptyOnParentAdded; }
			set { this._autoEmptyOnParentAdded = value; }
		}		
		private bool _autoEmptyOnParentAdded = false;

		/// <summary>
		/// Stores a reference to the associated business rule object
		/// </summary>
		protected virtual mmBusinessRule BusinessRuleObj
		{
			get 
			{
				// If the business rule object hasn't been created, create it
				if (this._businessRuleObj == null)
				{
					this._businessRuleObj = this.CreateBusinessRuleObject();
				}
				return this._businessRuleObj;
			}
			set { this._businessRuleObj = value; }
		}
		private mmBusinessRule _businessRuleObj = null;

		/// <summary>
		/// Specifies if data access objects should be cached
		/// </summary>
		[Description("Specifies if data access objects should be cached"),
		Category("Data"), 
		DefaultValue(true)]
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public bool CacheDataAccessObjects
		{
			get { return this._cacheDataAccessObjects; }
			set { this._cacheDataAccessObjects = value; }
		}
		private bool _cacheDataAccessObjects = true;

		/// <summary>
		/// Specifies if DataTables are cleared before being filled
		/// </summary>
		[Description("Specifies if DataTables are cleared before being filled."),
		Category("Data"), 
		DefaultValue(true)]
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public bool ClearOnFillDataSet
		{
			get { return this._clearOnFillDataSet; }
			set { this._clearOnFillDataSet = value; }
		}
		private bool _clearOnFillDataSet = true;

		/// <summary>
		/// Default command type
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public CommandType DefaultCommandType
		{
			get { return _defaultCommandType; }
			set { _defaultCommandType = value; }
		}
		private CommandType _defaultCommandType = CommandType.Text;

		/// <summary>
		/// Concurrency conflict DataSet
		/// </summary>
		protected DataSet ConflictDataSet = null;

		/// <summary>
		/// Contains concurrency exception messages
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public mmConcurrencyExceptionMessage ConcurrencyExceptionMsg;

		/// <summary>
		/// Concurrency select statement used to retrieve a single record by PK when
		/// resolving concurrency problems
		/// </summary>
		[Description("Concurrency select statement used to retrieve a single record " +
			 "by PK when resolving concurrency problems"), 
		Category("Data"), 
		DefaultValue("")]
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual string ConcurrencySelectStatement
		{
			get { return this._concurrencySelectStatement; }
			set { this._concurrencySelectStatement = value; }
		}
		private string _concurrencySelectStatement = "";

		/// <summary>
		/// Table name associated with the current DataSet
		/// </summary>
		[Description("Table name associated with the current DataSet."), 
		Category("Data"), 
		DefaultValue("")]
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual string CurrentTableName
		{
			get 
			{
				if (mmString.Empty(this._currentTableName))
				{
					return this.TableName;
				}
				return this._currentTableName; 
			}
			set { this._currentTableName = value; }
		}
		private string _currentTableName = "";

		/// <summary>
		/// Database key property
		/// </summary>
		[Description("Database key"), 
		Category("Data"), 
		DefaultValue("")]
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual string DatabaseKey
		{
			get { return this._databaseKey; }
			set { this._databaseKey = value; }
		}
		private string _databaseKey = "";

		/// <summary>
		/// DataRow field that stores the first DataRow of all data returned
		/// by busines object data retrieval methods
		/// </summary>
		[NonSerialized()] 
		public DataRow DataRow;

		/// <summary>
		/// Field that stores the Default Values object passed in the NewRow method
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public object DefaultValues
		{
			get { return this._defaultValues; }
			set { this._defaultValues = value; }
		}
		private object _defaultValues;

		/// <summary>
		/// Specifies whether the last exception was handled
		/// </summary>
		protected bool ExceptionHandled;

		/// <summary>
		/// Foreign key field that stores the parent business object's
		/// primary key value. If this value is specified, when a child
		/// object is saved, it automatically fills in the specified
		/// field with the parent's primary key value
		/// </summary>
		[Description("Foreign key field that stores the parent business object's " +
			 "primary key value. If this value is specified, when a child " +
			 "object is saved, it automatically fills in the specified " +
			 "field with the parent's primary key value"), 
		Category("Data"), 
		DefaultValue("")]
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        protected string ForeignParentKeyField
		{
			get { return this._foreignParentKeyField; }
			set { this._foreignParentKeyField = value; }
		}
		private string _foreignParentKeyField;

		/// <summary>
		/// Current DataSet
		/// </summary>
		public DataSet DataSet
		{
			get { return this.GetCurrentDataSet(); }
			set { this.SetCurrentDataSet(value); }
		}

		/// <summary>
		/// Gets the current DataSet returned from the business object
		/// </summary>
		/// <returns>Current DataSet</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual DataSet GetCurrentDataSet()
		{
			return this._currentDataSet;
		}
		private DataSet _currentDataSet;

		/// <summary>
		/// Specifies if deleted rows are immediately deleted from the database
		/// </summary>
		[Description("Specifies if deleted rows are immediately deleted from the database."), 
		Category("Data"), 
		DefaultValue(true)]
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public bool ImmediateDelete
		{
			get { return this._immediateDelete; }
			set { this._immediateDelete = value; }
		}
		private bool _immediateDelete = true;

		/// <summary>
		/// Stores a reference to the associated parent object (if any)
		/// </summary>
		public mmBusinessObject ParentBizObj = null;

		/// <summary>
		/// Contains the parent business object's primary key value the last time
		/// a parent event was handled
		/// </summary>
		protected virtual object ParentKeyValue
		{
			get { return this._parentKeyValue; }
			set { this._parentKeyValue = value; }
		}
		private object _parentKeyValue;

		/// <summary>
		/// Contains the parent business object's primary key values the last time 
		/// a parent event was handled
		/// </summary>
		protected virtual object[] ParentKeyValues
		{
			get { return this._parentKeyValues; }
			set { this._parentKeyValues = value; }
		}
		private object[] _parentKeyValues;

		/// <summary>
		/// Contains the parent business object's state the last time
		/// a parent event was handled
		/// </summary>
		protected mmBusinessState ParentState
		{
			get { return this._parentState; }
			set { this._parentState = value; }
		}
		private mmBusinessState _parentState;

		/// <summary>
		/// Specifies if the data access object should check for non-conformant
		/// parameters and adjust them for the specific .NET Data Provider
		/// </summary>
		[Description("Specifies if the data access object should check for non-conformant " +
			 "parameters and adjust them for the specific .NET Data Provider."), 
		Category("Data"), 
		DefaultValue(true)]
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool ParameterTranslation
		{
			get { return this._parameterTranslation; }
			set 
			{ 
				this._parameterTranslation = value;
				// Set the Parameter Translation value for all data access objects
				foreach (object access in this.DataAccessCollection)
				{
					mmDataAccessBase dao = (mmDataAccessBase)access;
					dao.ParameterTranslation = value;
				}
			}
		}
		private bool _parameterTranslation = true;

		/// <summary>
		/// Privatizes the public, inherited PersistenceKey property
		/// </summary>
		private new string PersistenceKey
		{
			get { return base.PersistenceKey; }
			set	{ base.PersistenceKey = value; }
		}

		/// <summary>
		/// Primary key field associated with the table specified in the TableName property
		/// </summary>
		[Description("Primary key field associated with the table specified in the TableName property."), 
		Category("Data"), 
		DefaultValue("")]
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public override string PrimaryKey
		{
			get 
			{ 
				if (mmAppBase.State == mmApplicationState.Running)
				{
					// If a primary key has not been specified, derive it 
					// dynamically from the current DataSet
					if (this._primaryKey == null && this.PrimaryKeys == null)
					{
						DataSet ds = this.GetCurrentDataSet();
						if (ds != null)
						{
							DataColumn[] ColumnArray = ds.Tables[this.CurrentTableName].PrimaryKey;
							if (ColumnArray.Length > 0)
							{
								this._primaryKey = ColumnArray[0].ToString();
							}
						}
					}
				}
				return this._primaryKey; 
			}
			set	{ this._primaryKey = value;	}
		}
		private string _primaryKey = null;

		/// <summary>
		/// Child business object collection
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public mmReferenceCollection RefBizObj = new mmReferenceCollection();

		/// <summary>
		/// Remote data access class	
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public string RemoteDataAccessClass
		{
			get { return _remoteDataAccessClass; }
			set { _remoteDataAccessClass = value; }
		}
		private string _remoteDataAccessClass;

		/// <summary>
		/// Specifies if auto-increment values should be automatically
		/// retrieved after inserting a new record.
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool RetrieveAutoIncrementPK
		{
			get { return this._retrieveAutoIncrementPK; }
			set { this._retrieveAutoIncrementPK = value; }
		}
		private bool _retrieveAutoIncrementPK = false;

		/// <summary>
		/// The row number currently being saved. This field is only
		/// set by the overload of SaveDataSet that accepts a row number!
		/// </summary>
		protected int RowNum = 0;

		/// <summary>
		/// Specifies if Rules have already been checked by a parent business object
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public bool RulesCheckedByParent;
		
		/// <summary>
		/// Specifies if the Business Rule object's required fields 
		/// should be set from the current data set
		/// </summary>
		[Description("Specifies if the Business Rule object's required fields " +
			 "should be set from the current data set."), 
		Category("Data"), 
		DefaultValue(false)]
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool SetRequiredFieldsFromDataSet
		{
			get { return this._setRequiredFieldsFromDataSet; }
			set { this._setRequiredFieldsFromDataSet = value; }
		}
		private bool _setRequiredFieldsFromDataSet = false;
		
		/// <summary>
		/// Business object state
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual mmBusinessState State
		{
			get { return this._state; }
			set { this._state = value; }
		}
		private mmBusinessState _state;

		/// <summary>
		/// The physical database object name associated with this business object
		/// May be a table, view, or stored procedure
		/// If not specified, returns the value stored in the TableName property
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual string PhysicalDbcObjectName
		{
			get 
			{
				if (!mmString.Empty(this._physicalDbcObjectName))
				{
					return _physicalDbcObjectName;
				}
				else
				{
					return this.TableName;
				}
			}
			set { _physicalDbcObjectName = value; }
		}
		private string _physicalDbcObjectName;

		/// <summary>
		/// Primary table name associated with the business object
		/// </summary>
		[Description("Primary table name associated with the business object."), 
		Category("Data"), 
		DefaultValue("")]
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual string TableName
		{
			get { return this._tableName; }
			set { this._tableName = value; }
		}
		private string _tableName = "";

		/// <summary>
		/// Update select statement used to generate insert, update, and delete command objects.
		/// </summary>
		[Description("Update select statement used to generate insert, update, and delete command objects."), 
		Category("Data"), 
		DefaultValue("")]
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual string UpdateSelectStatement
		{
			get { return this._updateSelectStatement; }
			set { this._updateSelectStatement = value; }
		}
		private string _updateSelectStatement = "";


		/// <summary>
		/// Saves the specified DataSet and Table Name as the current DataSet and Table Name
		/// </summary>
		/// <param name="ds">DataSet to be saved</param>
		/// <param name="tableName">Table Name</param>
		/// <param name="setRequiredFields">Specifies if Set Required Field logic should be executed</param>
		/// <param name="raiseEvents">Specifies if StateChange events are raised</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void SetCurrentDataSet(DataSet ds, string tableName, bool setRequiredFields, 
			bool raiseEvents)
		{
			string[] DataTables = null;
			if (raiseEvents)
			{
				// Get the specified DataTable or ALL DataTables
				DataTables = this.GetDataTables(ds, tableName, this.DatabaseKey);

				foreach (string table in DataTables)
				{
					// Raise the Retrieving state change event
					this.CallStateChange(mmBusinessState.Retrieving, table);
				}
			}

			this._currentDataSet = ds;
			this.CurrentTableName = tableName;
			if (setRequiredFields && this.SetRequiredFieldsFromDataSet)
			{
				this.BusinessRuleObj.SetRequiredFieldsFromTableColumns(ds, tableName);
			}

			if (raiseEvents)
			{
				// Get the specified DataTable or ALL DataTables
				DataTables = this.GetDataTables(ds, tableName, this.DatabaseKey);

				foreach (string table in DataTables)
				{
					// Call the Post-Get Data Hook
					this.HookPostGetData();

					// Raise the Retrieved state change event
					this.CallStateChange(mmBusinessState.Retrieved, table);
				}
			}

			// Set the current DataRow
			if (tableName == this.TableName)
			{
				this.StoreDataRow(ds);
			}
			this.RowNum = 0;
		}


		/// <summary>
		/// Saves the specified DataSet and Table Name as the current DataSet and Table Name
		/// </summary>
		/// <param name="ds">DataSet to be saved</param>
		/// <param name="tableName">Table Name</param>
		/// <param name="setRequiredFields">Specifies if Set Required Field logic should be executed</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void SetCurrentDataSet(DataSet ds, string tableName, bool setRequiredFields)
		{
			this.SetCurrentDataSet(ds, tableName, setRequiredFields, true);
		}

		/// <summary>
		/// Saves the specified DataSet and Table Name as the
		/// "current" DataSet and TableName
		/// </summary>
		/// <param name="ds"></param>
		/// <param name="tableName"></param>
		/// <returns></returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void SetCurrentDataSet(DataSet ds, string tableName)
		{
			this.SetCurrentDataSet(ds, tableName, true);
		}

		/// <summary>
		/// Saves the specified DataSet as the "Current" DataSet,
		/// deriving the table name from the TableName property
		/// </summary>
		/// <param name="ds">DataSet</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void SetCurrentDataSet(DataSet ds)
		{
			if (ds == null)
				this._currentDataSet = null;
			else
                this.SetCurrentDataSet(ds, ds.Tables[0].TableName);
		}

		/// <summary>
		/// This method allows you to manually specify data access settings,
		/// and creates a data access object based on these settings.
		/// If you specify a null DataAccessClass, this method assumes
		/// a SQL Server data access class
		/// </summary>
		/// <param name="databaseSetKey">DatabaseSet Key</param>
		/// <param name="databaseKey">Database Key</param>
		/// <param name="connectionString">Connection string</param>
		/// <param name="dataAccessClass">DataAccessClass</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void SetDataAccessObject(string databaseSetKey,
			string databaseKey,
			string connectionString,
			string dataAccessClass)
		{
			// If not specified, default to SQL Server access
			if (mmString.Empty(dataAccessClass))
			{
				dataAccessClass = "DataAccessSql";
			}

			// If no database key has been specified, specify it!
			this.DatabaseKey = databaseKey;

			// Create a data access object of the specified type
			mmDataAccessBase dao =
                (mmDataAccessBase)this.DataAccessCollection.Add(
				  this.CreateDataAccessObject(dataAccessClass.ToLower()));

			// Save the database key passed to this method in the dao's DatabaseKey 
			// property, save the database set key (if any)to the dao's DatabaseSetKey 
			// property, and store the associated connection string.
			dao.DatabaseKey = databaseKey;
			// Add a backslash because this is the way it's retrieved from the database mgr
			dao.DatabaseSetKey = (mmString.Empty(databaseSetKey))
				? databaseSetKey
				: databaseSetKey + @"\";
			dao.ConnectionString = connectionString;
		}

		/// <summary>
		/// This method allows you to manually specify a data access object
		/// </summary>
		/// <param name="dataAccessObject">Data access object</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void SetDataAccessObject(mmDataAccessBase dataAccessObject)
		{
			dataAccessObject.ParameterTranslation = this.ParameterTranslation;
			if (mmString.Empty(this.DatabaseKey))
			{
				this.DatabaseKey = dataAccessObject.DatabaseKey;
			}
			this.DataAccessCollection.Add(dataAccessObject);
		}

		/// <summary>
		/// Specifies the default data access class used by the business object
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        protected virtual string DataAccessClass
		{
			get
			{ return this._dataAccessClass; }
			set
			{ this._dataAccessClass = value; }
		}
		private string _dataAccessClass = null;

		/// <summary>
		/// Stores a reference to the associated data access object
		/// </summary>
		protected mmReferenceCollection DataAccessCollection = new mmReferenceCollection();

		/// <summary>
		/// Specifies a table within the parent business object that 
		/// triggers events in this business object. If not specified,
		/// all tables in the parent business object fire events in
		/// this business object.
		/// </summary>
		[Description("Specifies a table within the parent business object that " +
			"triggers events in this business object. If not specified, " +
			"all tables in the parent business object fire events in " +
			"this business object."), 
		Category("Behavior"), 
		DefaultValue("")]
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public string ParentBizObjTable
		{
			get { return _parentBizObjTable; }
			set { _parentBizObjTable = value; }
		}
		private string _parentBizObjTable = "";

		/// <summary>
		/// Specifies if error provider-style broken rules should be used
		/// when automatically adding broken rules to the rule object
		/// </summary>
		[Description("Specifies if error provider-style broken rules should be used " +
			 "when automatically adding broken rules to the rule object"), 
		Category("Behavior"), 
		DefaultValue(true)]
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public bool UseErrorProvider
		{
			get { return this._useErrorProvider; }
			set { this._useErrorProvider = value; }
		}
		private bool _useErrorProvider = true;

		/// <summary>
		/// Business Object Constructor. Instantiates related objects
		/// </summary>
		public mmBusinessObject()
		{
			#if EvaluationCopy
				Interlocked.Increment(ref mmBusinessObject.SWCounter);
				if (mmBusinessObject.SWCounter > 50) 
				{
					mmBusinessObject.SWCounter = 0;
					throw(new Exception("MM .NET Evaluation Notification.\r\n" + 
						"This exception is thrown only in the evaluation version."));
				}
			#endif
			if (mmAppBase.State == mmApplicationState.Running)
			{
				CreateBusinessRuleObject();
			}
		}

		/// <summary>
		/// Builds a concurrency exception message based on the specified exception
		/// </summary>
		/// <param name="e">DBConcurrencyException object</param>
		protected virtual mmConcurrencyExceptionMessage
			BuildConcurrencyExceptionMsg(DBConcurrencyException e)
		{
			// Instantiate a concurrency exception message object
			mmConcurrencyExceptionMessage exMsg = 
				mmAppBase.Factory.CreateConcurrencyExceptionMsg();

			// Include the table name in the preface message
			exMsg.PrefaceMessage +=
				e.Row.Table.TableName + " " + 
				(mmAppBase.Localize
				? mmAppBase.MessageMgr.GetMessage("Data") 
				: "Data") + 
				".\n\n";

			// Get the DataSet containing the row we're trying to save
			DataSet ds = e.Row.Table.DataSet;

			// Get a DataSet containing the conflict error row from the DBC
			this.ConflictDataSet = this.GetConflictData(e.Row);

			// If a record exists, it means there's an update conflict
			if (this.ConflictDataSet.Tables[e.Row.Table.TableName].Rows.Count > 0)
			{
				bool ChangesFound = false;
				string Current;
				string Proposed;

				// Set the concurrency exception type to "Multiple Update"
				exMsg.ExceptionType = mmConcurrencyExceptionType.MultipleUpdateConflict;

				// Get the Data Row from the conflict DataSet
				DataRow drRowInDbc = 
					this.ConflictDataSet.Tables[e.Row.Table.TableName].Rows[0];

				// Loop through the column values
				for (int i=0; i < e.Row.ItemArray.Length; i++)
				{
					Current = drRowInDbc[i, DataRowVersion.Current].ToString();
					Proposed = e.Row[i, DataRowVersion.Current].ToString();
					if (Current != Proposed)
					{
						exMsg.OriginalDataMessage += e.Row[i, DataRowVersion.Original] + "\n";
						exMsg.CurrentDataInDbcMessage += Current + "\n";
						exMsg.ProposedDataMessage += Proposed + "\n";
						ChangesFound = true;
					}
				}

				if (ChangesFound)
				{
					// Set the exception message
					exMsg.CompleteMessage = exMsg.PrefaceMessage + "\n" +
						exMsg.CurrentDataInDbcMessage + "\n" +
						exMsg.ProposedDataMessage + "\n" +
						exMsg.PromptMessage;
				}
				else
				{
					// Set the exception message. You still get an exception if the user
					// has changed the value to the same value as another user!
					exMsg.CompleteMessage = exMsg.PrefaceMessage + "\n" +
						exMsg.PromptMessage;
				}
				return exMsg;
			}
			else
			{
				// Set the Exception type to "Update on Delete"
				exMsg.ExceptionType = mmConcurrencyExceptionType.UpdateOnDeleteConflict;

				// The original data row was deleted. Set the exception message
				exMsg.CompleteMessage = "The original record was deleted. " +
					"Do you want to save the current data?";

				return exMsg;
			}
		}

		/// <summary>
		/// Resets the "next" autoincrement value
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="tableName">Table Name</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void ResetAutoIncrement(DataSet ds, string tableName)
		{
			if (ds.Tables[tableName].ExtendedProperties.Contains(AUTOINCREMENTCOLUMN))
			{
				string ColumnName = 
					ds.Tables[tableName].ExtendedProperties[AUTOINCREMENTCOLUMN].ToString();
				ds.Tables[tableName].ExtendedProperties[NEXTINCREMENTVALUE] = 
					this.AutoIncrementSeed;
			}
		}

		/// <summary>
		/// Resolves concurrency errors
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void ResolveConcurrency()
		{
			if (this.ExceptionObject != null)
			{
				this.ExceptionObject.ResolveConcurrency();
			}
			else
			{
				if (this.Exception is DBConcurrencyException)
				{
					// Cast the exception
					DBConcurrencyException e = (DBConcurrencyException)this.Exception;

					// Get the current DataSet
					DataSet ds = this.GetCurrentDataSet();

					// Check if there's any data in the Conflict DataSet
					if (this.ConcurrencyExceptionMsg.ExceptionType == 
						mmConcurrencyExceptionType.MultipleUpdateConflict)
					{
						// Overwrite the "Original" values in the DataSet with 
						// the data in the Conflict DataSet
						ds.Merge(this.ConflictDataSet, true);
					}
					else
					{
						// The original row was deleted. Remove it from the table
						// and add it back in again
						DataRow dr = e.Row;
						ds.Tables[e.Row.Table.TableName].Rows.Remove(dr);
						ds.Tables[e.Row.Table.TableName].Rows.Add(dr);
					}
				}
			}
		}

		/// <summary>
		/// Bubbles the DataTable up to the parent business object's DataSet to be saved
		/// </summary>
		/// <param name="dt">DataTable</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void BubbleDataTableUp(DataTable dt)
		{
			if (this.ParentBizObj != null)
			{
				this.ParentBizObj.BubbleDataTableUp(dt);
			}
			else
			{
				this.DataSet.Tables.Add(dt);
			}
		}

		/// <summary>
		/// Bubbles the DataTable down to its original business object after being saved
		/// </summary>
		/// <param name="dt">DataTable</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void BubbleDataTableDown(DataTable dt)
		{
			string BusinessObjectClass = dt.ExtendedProperties["BusinessObject"].ToString();

			if (BusinessObjectClass == mmString.JustExt(this.GetType().ToString()))
			{
				DataTable OriginalTable = this.DataSet.Tables[TableName];
				OriginalTable.Rows.Clear();

				foreach (DataRow Row in dt.Rows)
				{
					OriginalTable.ImportRow(Row);
				}

				// Call the post-save hook
				this.HookPostSave(dt);

				// Raise the Saved state change event
				this.CallStateChange(mmBusinessState.Saved, dt.TableName);
			}
			else
			{
				foreach (mmBusinessObject ChildObject in this.RefBizObj)
				{
					if (BusinessObjectClass == mmString.JustExt(ChildObject.GetType().ToString()))
					{
						ChildObject.BubbleDataTableDown(dt);
						break;
					}
				}
			}
		}

		/// <summary>
		/// Prepares the DataTable to be bubbled up to the parent business object
		/// 1. Makes sure the DataTable should be bubbled up
		/// 2. Calls PreSaveProcessing (and subsequently PreSaveHook) methods
		/// 3. Sets extended properties on the DataTable
		/// 4. Bubbles the DataTable up to the parent
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void PrepDataTableForBubble()
		{
			if (this.ParentBizObj != null && this.DataSet.HasChanges())
			{
				if (this.PreSaveProcessing(this.DataSet, this.TableName))
				{
					this.CallStateChange(mmBusinessState.Saving, this.TableName);
					DataTable Table = this.DataSet.Tables[this.TableName].Copy();

					this.SetTableExtendedProperties(Table, this.UpdateSelectStatement, this.PrimaryKey,
						this.RetrieveAutoIncrementPK);

					Table.ExtendedProperties.Add("ChildTable", true);

					this.ParentBizObj.BubbleDataTableUp(Table);
				}
			}
		}

		/// <summary>
		/// Sets the Extended Properties on the specified DataTable
		/// </summary>
		/// <param name="table">DataTable</param>
		/// <param name="updateSelectStatement">UpdateSelectStatement</param>
		/// <param name="primaryKeyName">Primary Key Name</param>
		/// <param name="retrieveAutoIncrementPK">Auto Retrieve Primary Key flag</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void SetTableExtendedProperties(DataTable table, string updateSelectStatement, string primaryKeyName, bool retrieveAutoIncrementPK)
		{
			if (!table.ExtendedProperties.Contains("BusinessObject"))
			{
				table.ExtendedProperties.Add("BusinessObject", mmString.JustExt(this.GetType().ToString()));
			}
			if (!table.ExtendedProperties.Contains("UpdateSelectStatement"))
			{
				table.ExtendedProperties.Add("UpdateSelectStatement", updateSelectStatement);
			}
			if (!table.ExtendedProperties.Contains("PrimaryKeyName"))
			{
				table.ExtendedProperties.Add("PrimaryKeyName", primaryKeyName);
			}
			if (!table.ExtendedProperties.Contains("RetrievePK"))
			{
				table.ExtendedProperties.Add("RetrievePK", retrieveAutoIncrementPK);
			}
			if (!mmString.Empty(this.RemoteDataAccessClass) &&!table.ExtendedProperties.Contains("RemoteDataAccessClass"))
			{
				table.ExtendedProperties.Add("RemoteDataAccessClass", this.RemoteDataAccessClass);
			}
		}

        /// <summary>
        /// Calls the OnStateChange method after deriving the primary key value
        /// for the specified DataRowView. The advantage of calling this method rather 
        /// than calling OnStateChange directly, is that it can check if there are
        /// any registered handlers (this.StateChange != null) before trying to
        /// get the primary key value.
        /// </summary>
        /// <param name="bizState">Business object state</param>
        /// <param name="tableName">Table name</param>
        /// <param name="drView">DataRowView</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void CallStateChange(mmBusinessState bizState, string tableName, DataRowView drView)
        {
            if (this.StateChange != null)
            {
                object PrimaryKeyValue = this.GetPrimaryKeyValue(drView);
                object[] PrimaryKeyValues = this.GetPrimaryKeyValues(drView);
                this.OnStateChange(bizState, tableName, PrimaryKeyValue, PrimaryKeyValues);
            }
        }

        /// <summary>
        /// Calls the OnStateChange method after deriving the primary key value
        /// for the specified DataRow. The advantage of calling this method rather 
        /// than calling OnStateChange directly, is that it can check if there are
        /// any registered handlers (this.StateChange != null) before trying to
        /// get the primary key value.
        /// </summary>
        /// <param name="bizState">Business object state</param>
        /// <param name="tableName">Table name</param>
        /// <param name="dr">Current DataRow</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void CallStateChange(mmBusinessState bizState, string tableName, DataRow dr)
        {
            if (this.StateChange != null)
            {
                object PrimaryKeyValue = this.GetPrimaryKeyValue(dr);
                object[] PrimaryKeyValues = this.GetPrimaryKeyValues(dr);
                this.OnStateChange(bizState, tableName, PrimaryKeyValue, PrimaryKeyValues);
            }
        }

        /// <summary>
        /// Calls the OnStateChange method after deriving the primary key value
        /// for the specified table. The advantage of calling this method rather 
        /// than calling OnStateChange directly, is that it can check if there are
        /// any registered handlers (this.StateChange != null) before trying to
        /// get the primary key value.
        /// </summary>
        /// <param name="bizState">Business object state</param>
        /// <param name="tableName">Table name</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void CallStateChange(mmBusinessState bizState, string tableName)
        {
            this.CallStateChange(bizState, tableName, this.DataRow);
        }

		/// <summary>
		/// Calls the OnStateChange method with the specified business state 
		/// for the business object's default table. This overload calls another
		/// overload that derives theh primary key value for the specified table.
		/// The advantage of calling this method rather than calling OnStateChange 
		/// directly, is that it can check if there are any registered handlers
		/// (this.StateChange != null) before trying to get the primary key value
		/// </summary>
		/// <param name="bizState">Business object state</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void CallStateChange(mmBusinessState bizState)
		{
			this.CallStateChange(bizState, this.TableName);
		}

		/// <summary>
		/// Cancels all changes in the specified DataView
		/// </summary>
		/// <param name="dv"></param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void Cancel(DataView dv)
		{
			this.Cancel(dv.Table.DataSet, dv.Table.TableName);
		}

		/// <summary>
		/// Cancels all changes in the specified DataSet and table
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="tableName">Table Name</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void Cancel(DataSet ds, string tableName)
		{
			if (ds != null && ds.Tables.Contains(tableName))
			{
				// Get the specified DataTable or ALL DataTables
				string[] DataTables = this.GetDataTables(ds, tableName);

				foreach(string table in DataTables)
				{
					if (this.HookPreCancel(ds.Tables[table]))
					{
						// Raise the Canceling state change event
						this.CallStateChange(mmBusinessState.Canceling, table);

						// Clear all broken rules and warnings in the rule object
						this.BusinessRuleObj.ClearAll();

						// Cancel changes in the specified DataTable
						ds.Tables[table].RejectChanges();

						// Clear the current DataRow if it's now detached
						if (this.DataRow != null && this.DataRow.RowState == DataRowState.Detached)
						{
							this.DataRow = null;
						}

						// If creating custom auto-increment values, reset the "next" increment number
						if (this.AutoIncrementCustom)
						{
							this.ResetAutoIncrement(ds, table);
						}

						// Call Post-Cancel Hook
						this.HookPostCancel(ds.Tables[table]);

						// Raise the Canceled state change event
						this.CallStateChange(mmBusinessState.Canceled, table);
					}
				}
			}
		}

		/// <summary>
		/// Cancels all changes in the specified DataSet's default table
		/// </summary>
		/// <param name="ds"></param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void Cancel(DataSet ds)
		{
			this.Cancel(ds, this.TableName);
		}

		/// <summary>
		/// Cancels all changes in the default DataSet's default table
		/// </summary>
		public override void Cancel()
		{
			this.Cancel(this.GetCurrentDataSet());
		}

		/// <summary>
		/// Cancels all changes in the row stored in the DataRow property
		/// </summary>
		public virtual void CancelRow()
		{
			if (this.DataRow != null)
			{
				this.DataRow.RejectChanges();
			}
		}

		/// <summary>
		/// Factory method that creates the associated business rule object
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        protected virtual mmBusinessRule CreateBusinessRuleObject()
		{
			// Note: this can be overridden in derived classes
			 return mmAppBase.Factory.CreateBusinessRule(this);
		}
	
		/// <summary>
		/// Factory method that reates the appropriate data access object
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        protected virtual mmDataAccessBase CreateDataAccessObject(string dataAccessClassName)
		{
			// Note: this can be overridden in derived classes
			dataAccessClassName = dataAccessClassName.ToLower();
			mmDataAccessBase dao;

			switch (dataAccessClassName)
			{
				case "dataaccessoracle":
					dao = mmAppBase.Factory.CreateDataAccessOracle();
					break;

				case "dataaccessoledb":
					if (mmAppBase.Factory != null)
						dao = mmAppBase.Factory.CreateDataAccessOleDb();
					else
						dao = new mmDataAccessOleDb();
					break;;
				case "dataaccesssql":
				default:
					if (mmAppBase.Factory != null)
                        dao = mmAppBase.Factory.CreateDataAccessSql();
					else
						dao = new mmDataAccessSql();
					break;
			}

			return dao;
		}

		/// <summary>
		/// Factory method that creates a DataSet
		/// </summary>
		/// <returns></returns>
		protected virtual DataSet CreateDataSet()
		{
			return mmAppBase.Factory.CreateDataSet();
		}

		/// <summary>
		/// Creates a list of the entities
		/// </summary>
		/// <typeparam name="T">Generic type</typeparam>
		/// <param name="dt">DataTable from which to hydrate the entities</param>
		/// <returns>List of entities</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual mmBindingList<T> CreateEntityList<T>(DataTable dt) where T : mmBusinessEntity, new()
		{
			return this.GetDataAccessObject().CreateEntityList<T>(dt);
		}

		/// <summary>
		/// Creates a list of the entities
		/// </summary>
		/// <typeparam name="T">Generic type</typeparam>
		/// <returns>Entity List</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual mmBindingList<T> CreateEntityList<T>() where T : mmBusinessEntity, new()
		{
			if (this.DataSet != null)
			{
				return this.CreateEntityList<T>(this.DataSet.Tables[this.TableName]);
			}
			else
			{
				return new mmBindingList<T>();
			}
		}

		/// <summary>
		/// Creates a list of entities from a DataReader
		/// </summary>
		/// <typeparam name="T">Generic Type</typeparam>
		/// <param name="dataReader">DataReader</param>
		/// <returns>Entity List</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public mmBindingList<T> CreateEntityList<T>(IDataReader dataReader)
			where T : mmBusinessEntity, new()
		{
			return this.GetDataAccessObject().CreateEntityList<T>(dataReader);
		}

		/// <summary>
		/// Factory method that creates a memento object
		/// </summary>
		/// <returns>Business memento object</returns>
        protected virtual mmBusinessMemento CreateMemento()
		{
			return new mmBusinessMemento();
		}

		/// <summary>
		/// Creates a parameter object with the specified name, value and data type
		/// from the default data access object
		/// </summary>
		/// <param name="name">Parameter name</param>
		/// <param name="value">Parameter value</param>
		/// <param name="dataType">Parameter data type</param>
		/// <param name="direction">Parameter direction</param>
		/// <returns>Parameter object</returns>
		protected virtual IDbDataParameter CreateParameter(string name, object value, DbType dataType, ParameterDirection direction)
		{
			IDbDataParameter Param = this.CreateParameter(name, value);
			Param.DbType = dataType;
			Param.Direction = direction;
			return Param;
		}

		/// <summary>
		/// Creates a parameter object with the specified name, value and data type
		/// from the default data access object
		/// </summary>
		/// <param name="name">Parameter name</param>
		/// <param name="value">Parameter value</param>
		/// <param name="dataType">Parameter data type</param>
		/// <returns>Parameter object</returns>
		protected virtual IDbDataParameter CreateParameter(string name, object value, DbType dataType)
		{
			return this.CreateParameter(name, value, dataType, ParameterDirection.Input);
		}

		/// <summary>
		/// Creates a parameter object with the specified name and value
		/// from the default data access object
		/// </summary>
		/// <param name="name">Parameter name</param>
		/// <param name="value">Parameter value</param>
		/// <returns>Parameter object</returns>
		protected virtual IDbDataParameter CreateParameter(string name, object value)
		{
			mmDataAccessBase dao = this.GetDataAccessObject();
			return dao.CreateParameter(name, value);
		}

		/// <summary>
		/// Deletes the specified DataRow belonging to its associated table
		/// </summary>
		/// <param name="dr">DataRow to be deleted</param>
		/// <returns>True if successful, otherwise false</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool Delete(DataRow dr)
		{
			bool Deleted = false;

			// Call the Pre-Delete Hook method
			if (dr != null && this.HookPreDelete(dr))
			{
				// Get the table name and DataSet of the DataRow
				string TableName = dr.Table.ToString();
				DataSet ds = dr.Table.DataSet;

				// Raise the Deleting state change event
				this.CallStateChange(mmBusinessState.Deleting, TableName, dr);

				// If specified to do so, immediately delete the row from the database
				// if it's not a newly added row
				if (dr.RowState != DataRowState.Added && this.ImmediateDelete)
				{
					// Retrieve the row being deleted into a temporary DataSet
					// (we're using GetConflictData() to do this)
					try
					{
						DataSet dsDelete = this.GetConflictData(dr);
						// Delete the row from the temporary DataSet and save it
						dsDelete.Tables[TableName].Rows[0].Delete();
						mmDataAccessBase dao = this.GetDataAccessObject();
						dao.SaveDataSet(dsDelete, TableName, null, false, null);

						// Remove the row from the original DataSet
						ds.Tables[TableName].Rows.Remove(dr);
					}
					catch (Exception ex)
					{
						if (this.GetPrimaryKeyFields(dr) == null)
						{
							throw new Exception("Cannot perform an Immediate Delete if no primary keys are specified");
						}
						else
						{
							throw;
						}
					}
				}
				else
				{
					// Just mark the row as deleted
					dr.Delete();
				}

				// Clear the reference to the deleted DataRow
				if (dr == this.DataRow)
				{
					this.DataRow = null;
					if (ds.Tables[TableName].Rows.Count > 0)
					{
						this.DataRow = ds.Tables[TableName].Rows[0];
					}
				}

				// Set the deleted flag
				Deleted = true;

				// Call the Post-Delete hook method
				this.HookPostDelete(ds.Tables[TableName]);

				// Raise the Deleted state change event
				this.CallStateChange(mmBusinessState.Deleted, TableName);
			}
			return Deleted;
		}

		/// <summary>
		/// Deletes the nth record in the specified DataSet's specified DataTable
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="tableName">Table name</param>
		/// <param name="row">Row number</param>
		/// <returns>True if successful, otherwise false</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool Delete(DataSet ds, string tableName, int row)
		{
			// Get the data row to be deleted
			DataRow dr = ds.Tables[tableName].Rows[row];

			// Delete the data row
			return this.Delete(dr);
		}

		/// <summary>
		/// Deletes the nth record in the specified DataSet's default DataTable
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="row">Row number</param>
		/// <returns>True if successful, otherwise false</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool Delete(DataSet ds, int row)
		{
			return this.Delete(ds, this.CurrentTableName, row);
		}

		/// <summary>
		/// Deletes the first record in the current DataSet's specified DataTable
		/// </summary>
		/// <param name="tableName">Table Name</param>
		/// <returns>True if successful, otherwise false</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool Delete(string tableName)
		{
			return this.Delete(this.GetCurrentDataSet(), tableName, 0);
		}

		/// <summary>
		/// Deletes the first record in the current DataSet's default DataTable
		/// </summary>
		/// <returns>True if successful, otherwise false</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public override bool Delete()
		{
			return this.Delete(this.TableName);
		}

		/// <summary>
		/// Deletes the record with the specified primary key value 
		/// in the specified table
		/// </summary>
		/// <param name="primaryKeyValue">Primary key value</param>
		/// <param name="tableName">Table name</param>
		/// <returns>True if successful, otherwise false</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool Delete(object primaryKeyValue, string tableName)
		{
			bool Deleted = false;
			
			// Get the current DataSet
			DataSet ds = this.GetCurrentDataSet();

			if (ds != null)
			{
				// Find the specified row
				DataRow FoundRow = ds.Tables[tableName].Rows.Find(primaryKeyValue);

				// If the row was found, delete it
				if (FoundRow != null)
				{
					Deleted = this.Delete(FoundRow);
				}
			}
			else
			{
				if (this.HookPreDelete(null))
				{
					// Get a data access object
					mmDataAccessBase dao = this.GetDataAccessObject();
					// Create a parameter object
					string PKField = this.PrimaryKey;
					IDbDataParameter param = dao.CreateParameter(dao.ParameterPrefixChar + PKField, primaryKeyValue);
					// Execute a DELETE command that deletes the specified record
					int Result = this.ExecNonQuery("DELETE FROM " + tableName + " WHERE " + PKField + 
						" = " + dao.ParameterPrefixChar + (dao.ParameterNameIncluded ? PKField : ""), param);

					Deleted = Result >= 0;

					// Call the Post-Delete hook method
					this.HookPostDelete(null);

					// Raise the Deleted state change event
					this.CallStateChange(mmBusinessState.Deleted, tableName);
				}
			}
			return Deleted;
		}

		/// <summary>
		/// Deletes the specified row in the current DataSet
		/// </summary>
		/// <param name="drView">DataRowView to act on</param>
		/// <returns>True if successful, otherwise false</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool Delete(DataRowView drView)
		{
			bool Deleted = false;

			// Delete the row
			if (drView != null)
			{
				Deleted = this.Delete(drView.Row);
			}
			return Deleted;
		}

		/// <summary>
		/// Deletes the record with the specified primary key values
		/// in the specified table
		/// </summary>
		/// <param name="primaryKeyValues">Array of primary key values</param>
		/// <param name="tableName">Table Name</param>
		/// <returns>True if successful, otherwise false</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool Delete(object[] primaryKeyValues, string tableName)
		{
			bool Deleted = false;

			// Get the current DataSet
			DataSet ds = this.GetCurrentDataSet();

			if (ds != null)
			{
				// Find the specified row
				DataRow FoundRow = ds.Tables[tableName].Rows.Find(primaryKeyValues);

				// If the row was found, delete it
				if (FoundRow != null)
				{
					Deleted = true;
					this.Delete(FoundRow);
				}
			}
			else
			{
				// Get a data access object
				mmDataAccessBase dao = this.GetDataAccessObject();
				// Create a parameter object
				IDbDataParameter[] DbParams = new IDbDataParameter[primaryKeyValues.Length];
				// Build the DELETE command
				string DeleteCmd = "DELETE FROM " + tableName + " WHERE ";
				int ParamCount = 0;
				foreach (string PK in this.PrimaryKeys)
				{
					if (ParamCount != 0){
						DeleteCmd += " AND ";
					}
					DeleteCmd += PK + " = " + dao.ParameterPrefixChar + (dao.ParameterNameIncluded ? PK : "");
					DbParams[ParamCount] = 
						dao.CreateParameter(dao.ParameterPrefixChar + (dao.ParameterNameIncluded ? PK : ""), primaryKeyValues[ParamCount]);
					ParamCount++;
				}
				// Execute the DELETE command 
				int Result = this.ExecNonQuery(DeleteCmd, DbParams);

				Deleted = Result >= 0;
			}

			return Deleted;
		}

		/// <summary>
		/// Deletes the record with the specified primary key value
		/// in the default table
		/// </summary>
		/// <param name="primaryKeyValue">Primary Key value</param>
		/// <returns>True if successful, otherwise false</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool Delete(object primaryKeyValue)
		{
			return this.Delete(primaryKeyValue, this.TableName);
		}

		/// <summary>
		/// Deletes the record with the specified primary key values
		/// in the default table
		/// </summary>
		/// <param name="primaryKeyValues">Array of primary key values</param>
		/// <returns>True if successful, otherwise false</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool Delete(object[] primaryKeyValues)
		{
			return this.Delete(primaryKeyValues, this.TableName);
		}

		/// <summary>
		/// Deletes all rows in the default DataSet's default table.
		/// This method is aware of rows that have been added during
		/// this session vs. rows retrieved from the back end
		/// </summary>
		/// <param name="tableName">Table</param>
		/// <returns>True if successful, otherwise false</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void DeleteAll(string tableName)
		{
			DataSet ds = this.GetCurrentDataSet();
			DataTable dt = ds.Tables[tableName];

			if (dt != null && this.HookPreDeleteAll(dt))
			{
				// Raise the Deleting state change event
				this.CallStateChange(mmBusinessState.Deleting, tableName);

				int RowCount = dt.Rows.Count;
				int DeleteRow = 0;

				for (int Row = 0; DeleteRow < RowCount; Row++)
				{
					// Check if the row is already deleted
					if (dt.Rows[DeleteRow].RowState != DataRowState.Deleted &&
						dt.Rows[DeleteRow].RowState != DataRowState.Detached) 
					{
						// Delete the row
						this.Delete(dt.Rows[DeleteRow]);

						// Get an updated row count since this may change
						// if ImmediateDelete is true, or if deleting a
						// newly added record (both of these conditions
						// remove the DataRow from the DataTable
						RowCount = dt.Rows.Count;
					}
					else
					{
						// Increment the variable so we go to the next row
						DeleteRow++;
					}
				}

				// If specified to do so, save the DataSet which deletes
				// all rows marked as Deleted from the database
				if (this.ImmediateDelete)
				{
					this.SaveDataSet(ds, tableName);
				}

				// Call the Post-Delete hook method
				this.HookPostDeleteAll(dt);

				// Raise the Deleted state change event
				this.CallStateChange(mmBusinessState.Deleted, tableName);
			}
		}

		/// <summary>
		/// Deletes all rows in the default DataSet's default table
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void DeleteAll()
		{
			this.DeleteAll(this.TableName);
		}

		/// <summary>
		/// Deletes the current DataRow stored in the DataRow property
		/// </summary>
		/// <returns>true if successful, otherwise false</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool DeleteRow()
		{
			bool result = false;
			if (this.DataRow != null)
			{
				result = this.Delete(this.DataRow);
			}
			return result;
		}

		/// <summary>
		/// Ends any pending edits on the specified Data Table
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="tableName">Table Name</param>
		protected virtual void EndEdit(DataSet ds, string tableName)
		{
			if (this.AutoEndEdit)
			{
				int RowCount = ds.Tables[tableName].Rows.Count;
				DataTable dt = ds.Tables[tableName];

				for (int row = 0; row < RowCount; row++)
				{
					if (dt.Rows[row].HasVersion(DataRowVersion.Proposed))
					{
						dt.Rows[row].EndEdit();
					}
				}
			}
		}

		/// <summary>
		/// Ends any pending edits on the specified DataView
		/// </summary>
		/// <param name="dv">DataView</param>
		protected virtual void EndEdit(DataView dv)
		{
			if (this.AutoEndEdit)
			{
				DataRowView row;

				for (int i = 0; i<dv.Count; i++)
				{
					row = dv[i];
					if (dv[i].RowVersion == DataRowVersion.Proposed)
					{
						dv[i].Row.EndEdit();
					}
				}
			}
		}

		/// <summary>
		/// Executes the specified Non Query command
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="databaseKey">Database key</param>
		/// <param name="dataParams">Parameters</param>
		/// <returns>The number of rows affected</returns>
		protected virtual int ExecNonQuery(string command, string databaseKey, 
			params IDbDataParameter[] dataParams)
		{
			// Pass the call to the data access object
			mmDataAccessBase dao = this.GetDataAccessObject(databaseKey);
			return dao.ExecNonQuery(command, dataParams);
		}

		/// <summary>
		/// Executes the specified Non Query command
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="dataParams">Parameters</param>
		/// <returns>The number of rows affected</returns>
		protected virtual int ExecNonQuery(string command, params IDbDataParameter[] dataParams)
		{
			return this.ExecNonQuery(command, this.DatabaseKey, dataParams);
		}

		/// <summary>
		/// Executes the specified Non Query command
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="databaseKey">Database key</param>
		/// <returns>The number of rows affected</returns>
		protected virtual int ExecNonQuery(string command, string databaseKey)
		{
			return this.ExecNonQuery(command, databaseKey, null);
		}

		/// <summary>
		/// Executes the specified Non Query command
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <returns>The number of rows affected</returns>
		protected virtual int ExecNonQuery(string command)
		{
			return this.ExecNonQuery(command, this.DatabaseKey);
		}
	
		/// <summary>
		/// Executes the specified command and returns a data reader
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="databaseKey">Database Key</param>
		/// <param name="connection">Connection returned as output parameter</param>
		/// <param name="dataParams">Parameters</param>
		/// <returns>Data Reader</returns>
		protected virtual IDataReader ExecReader(string command, string databaseKey, 
			out IDbConnection connection, params IDbDataParameter[] dataParams)
		{
			// Pass the call to the data access object
			mmDataAccessBase dao = this.GetDataAccessObject(databaseKey);
			return dao.ExecReader(command, out connection, dataParams);
		}

		/// <summary>
		/// Executes the specified command and returns a data reader
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="databaseKey">Database Key</param>
		/// <param name="connection">Connection returned as output parameter</param>
		/// <returns>Data Reader</returns>
		protected virtual IDataReader ExecReader(string command, string databaseKey, out IDbConnection connection)
		{
			return this.ExecReader(command, databaseKey, out connection, null);
		}

		/// <summary>
		/// Executes the specified command and returns a data reader
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="connection">Connection returned as output parameter</param>
		/// <returns>Data Reader</returns>
		protected virtual IDataReader ExecReader(string command, out IDbConnection connection)
		{
			return this.ExecReader(command, this.DatabaseKey, out connection);
		}

		/// <summary>
		/// Executes the specified stored procedure in the specified database, 
		/// passing the specified parameters and returning a command object 
		/// allowing access to any output parameters
		/// </summary>
		/// <param name="sprocName">Stored procedure name</param>
		/// <param name="databaseKey">Database key</param>
		/// <param name="dataParams">Parameters</param>
		/// <returns>Command object</returns>
		protected virtual IDbCommand ExecSproc(string sprocName, string databaseKey, 
			params IDbDataParameter[] dataParams)
		{
			// Pass the call to the data access object
			mmDataAccessBase dao = this.GetDataAccessObject(databaseKey);
			return dao.ExecSproc(sprocName, dataParams);
		}

		/// <summary>
		/// Executes the specified stored procedure in the default database, 
		/// passing the specified parameters and returning a command object 
		/// allowing access to any output parameters
		/// </summary>
		/// <param name="sprocName">Stored procedure name</param>
		/// <param name="dataParams">Parameters</param>
		/// <returns>Command object</returns>
		protected virtual IDbCommand ExecSproc(string sprocName, 
			params IDbDataParameter[] dataParams)
		{
			return this.ExecSproc(sprocName, this.DatabaseKey, dataParams);
		}

		/// <summary>
		/// Executes the specified stored procedure in the default database, 
		/// returning a data reader with the result set
		/// </summary>
		/// <param name="sprocName">Stored procedure name</param>
		/// <returns>DataReader containing result set</returns>
		protected virtual IDataReader ExecSprocReader(string sprocName)
		{
			return this.ExecSprocReader(sprocName, this.DatabaseKey);
		}

		/// <summary>
		/// Executes the specified stored procedure in the specified database,
		/// returning a data reader with the result set
		/// </summary>
		/// <param name="sprocName">Stored procedure name</param>
		/// <param name="databaseKey">Database key</param>
		/// <returns>Data reader containing result set</returns>
		protected virtual IDataReader ExecSprocReader(string sprocName, string databaseKey)
		{
			return this.ExecSprocReader(sprocName, databaseKey, (IDbDataParameter[])null);
		}

		/// <summary>
		/// Executes the specified stored procedure and parameters in the specified database,
		/// returning a data reader with the result set
		/// </summary>
		/// <param name="sprocName">Stored procedure name</param>
		/// <param name="databaseKey">Database Key</param>
		/// <param name="dataParams">Parameters</param>
		/// <returns>Data reader containing result set</returns>
		protected virtual IDataReader ExecSprocReader(string sprocName, string databaseKey,
			params IDbDataParameter[] dataParams)
		{
			mmDataAccessBase dao = this.GetDataAccessObject(databaseKey);
			return dao.ExecSprocReader(sprocName, dataParams);
		}

		/// <summary>
		/// Executes the specified stored procedure and parameters in the default database,
		/// returning a data reader with the result set
		/// </summary>
		/// <param name="sprocName">Stored procedure name</param>
		/// <param name="dataParams">Parameters</param>
		/// <returns>Data reader containing result set</returns>
		protected virtual IDataReader ExecSprocReader(string sprocName,
			params IDbDataParameter[] dataParams)
		{
			return this.ExecSprocReader(sprocName, this.DatabaseKey, dataParams);
		}

		/// <summary>
		/// Executes the specified stored procedure in the specified database, 
		/// passing the specified parameters and returning a scalar value. 
		/// Also returns the command object as an output parameter so any 
		/// output parameters returned from the stored procedure can be accessed
		/// </summary>
		/// <param name="sprocName">Stored procedure name</param>
		/// <param name="databaseKey">Database key</param>
		/// <param name="cmd">(out) Command object</param>
		/// <param name="dataParams">Parameters</param>
		/// <returns>Sproc return value</returns>
		protected virtual object ExecSprocScalar(string sprocName, 
			string databaseKey, 
			out IDbCommand cmd,
			params IDbDataParameter[] dataParams)
		{
			// Pass the call to the data access object
			mmDataAccessBase dao = this.GetDataAccessObject(databaseKey);
			return dao.ExecSprocScalar(sprocName, out cmd, dataParams);
		}

		/// <summary>
		/// Executes the specified stored procedure in the default database, 
		/// passing the specified parameters and returning a scalar value. 
		/// Also returns the command object as an output parameter so any 
		/// output parameters returned from the stored procedure can be accessed
		/// </summary>
		/// <param name="sprocName">Stored procedure name</param>
		/// <param name="cmd">(out) Command object</param>
		/// <param name="dataParams">Parameters</param>
		/// <returns>Sproc return value</returns>
		protected virtual object ExecSprocScalar(string sprocName,
			out IDbCommand cmd,
			params IDbDataParameter[] dataParams)
		{
			return this.ExecSprocScalar(sprocName, this.DatabaseKey, out cmd, dataParams);
		}

		/// <summary>
		/// Executes the specified stored procedure in the specified database, 
		/// passing the specified parameters and returning a scalar value
		/// </summary>
		/// <param name="sprocName">Stored procedure name</param>
		/// <param name="databaseKey">Database key</param>
		/// <param name="dataParams">Parameters</param>
		/// <returns>Sproc return value</returns>
		protected virtual object ExecSprocScalar(string sprocName, string databaseKey,
			params IDbDataParameter[] dataParams)
		{
			// Pass the call to the data access object
			mmDataAccessBase dao = this.GetDataAccessObject(databaseKey);
			return dao.ExecSprocScalar(sprocName, dataParams);
		}

		/// <summary>
		/// Executes the specified stored procedure in the default database, 
		/// passing the specified parameters and returning a scalar value 
		/// </summary>
		/// <param name="sprocName">Stored Procedure Name</param>
		/// <param name="dataParams">Parameters</param>
		/// <returns>Sproc return value</returns>
		protected virtual object ExecSprocScalar(string sprocName, params IDbDataParameter[] dataParams)
		{
			return this.ExecSprocScalar(sprocName, this.DatabaseKey, dataParams);
		}

		/// <summary>
		/// Executes the specified stored procedure in the default database 
		/// without parameters, returning a scalar value
		/// </summary>
		/// <param name="sprocName">Stored procedure name</param>
		/// <returns>Sproc return value</returns>
		protected virtual object ExecSprocScalar(string sprocName)
		{
			return this.ExecSprocScalar(sprocName, (IDbDataParameter[])null);
		}

		/// <summary>
		/// Executes the specified command w/ associated parameters in the 
		/// specified database and returns an object
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="databaseKey">Database key</param>
		/// <param name="dataParams">Data parameters</param>
		/// <returns>Object return value</returns>
		protected virtual object ExecScalar(string command, string databaseKey,
			params IDbDataParameter[] dataParams)
		{
			mmDataAccessBase dao = this.GetDataAccessObject(databaseKey);
			return dao.ExecScalar(command, dataParams);
		}

		/// <summary>
		/// Executes the specified command w/ associated parameters in the 
		/// specified database and returns an object
		/// </summary>
		/// <param name="command">Command to be executed</param>C:\Temp\Delete\Dallas Windows Application\Customer.cs
		/// <param name="dataParams">Data parameters</param>
		/// <returns>Object return value</returns>
		protected virtual object ExecScalar(string command, params IDbDataParameter[] dataParams)
		{
			return this.ExecScalar(command, this.DatabaseKey, dataParams);
		}

		/// <summary>
		/// Gets all data from the source database table
		/// </summary>
		/// <returns>DataTable containing all data</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual DataTable GetAllData()
		{
			DataTable DT = null;

			mmDataAccessBase DAO = this.GetDataAccessObject();

			switch (this.DefaultCommandType)
			{
				case CommandType.StoredProcedure:
					IDbCommand SelectCommand = DAO.CreateSelectCommand();

					if (SelectCommand != null)
					{
						this.GetDataSet(SelectCommand, this.TableName);
						DT = this.DataSet.Tables[this.TableName];
					}
					else if(!String.IsNullOrEmpty(this.UpdateSelectStatement))
					{
						this.GetDataSet(this.UpdateSelectStatement, this.TableName);
					}
					
					break;

				case CommandType.Text:
					this.GetDataSet("SELECT * FROM " +
						DAO.TableNameDelimitBegin + this.PhysicalDbcObjectName + DAO.TableNameDelimitEnd +
						(mmString.Empty(this.DefaultSortOrder) ? "" : " ORDER BY " + this.DefaultSortOrder));
					DT = this.DataSet.Tables[this.TableName];
					break;

				default:
					break;
			}

			return DT;
		}

		/// <summary>
		/// Executes the specified command and returns an object
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="databaseKey">Database key</param>
		/// <returns>Object return value</returns>
		protected virtual object ExecScalar(string command, string databaseKey)
		{
			mmDataAccessBase dao = this.GetDataAccessObject(databaseKey);
			return dao.ExecScalar(command, null);
		}

		/// <summary>
		/// Executes the specified command and returns an object
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <returns>Object</returns>
		protected virtual object ExecScalar(string command)
		{
			return this.ExecScalar(command, this.DatabaseKey);
		}

		/// <summary>
		/// Returns an instance of a data access object for the 
		/// specified database key
		/// </summary>
		/// <param name="databaseKey">Database key</param>
		/// <returns>Data access object</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual mmDataAccessBase GetDataAccessObject(string databaseKey)
		{
			if (mmString.Empty(databaseKey))
			{
				throw new Exception("A database key must be specified");
			}

			mmDataAccessBase dao = null;
			
			// If caching data access objects, see if a data access object 
			// already exists for this database key
			if (this.CacheDataAccessObjects)
			{
				dao = this.GetExistingDataAccessObjectByDbKey(databaseKey);
			}

			// If a data access object with the specified key could not be found,
			// see if a dao exists of the same class used to access the specified database
			if (dao == null)
			{
				string daoClass = null;

				// If a data access class is specified in this 
				// business object's property, use it
				if (!mmString.Empty(this.DataAccessClass))
				{
					daoClass = this.DataAccessClass;
				}
				else
				{
					// See if a data access class has been specified in the app config file
					// for this database key
					daoClass = mmAppBase.DatabaseMgr.GetDataAccessClassName(databaseKey);

					// If no data access class is specified for this database key, 
					// hard-code it to DataAccessSql
					if (mmString.Empty(daoClass))
					{
						daoClass = "DataAccessSql";
					}
				}

				// If caching data access objects, try to get an existing 
				// data access object of the specified class
				if (this.CacheDataAccessObjects)
				{
					dao = this.GetExistingDataAccessObjectByClass(daoClass);
					if (dao == null)
					{
						// If there is no existing dao of the needed class, create one
						dao = (mmDataAccessBase)this.DataAccessCollection.Add(this.CreateDataAccessObject(daoClass.ToLower()));
					}
				}
				else
				{
					dao = this.CreateDataAccessObject(daoClass.ToLower());
				}

				// Save the database key passed to this method in the dao's DatabaseKey 
				// property, save the database set key (if any)to the dao's DatabaseSetKey 
				// property, and store the associated connection string
				dao.DatabaseKey = databaseKey;
				dao.DatabaseSetKey = mmAppBase.DatabaseMgr.DatabaseSetKey;
				dao.ConnectionString = GetConnectionString(databaseKey);
				dao.ParameterTranslation = this.ParameterTranslation;
				dao.BusinessObject = this;

			}

			return dao;
		}

		/// <summary>
		/// Gets the connection string for the specified database key from the database manager
		/// </summary>
		/// <param name="databaseKey">Database key</param>
		/// <returns></returns>
		protected virtual string GetConnectionString(string databaseKey)
		{
			return mmAppBase.DatabaseMgr.GetConnectionString(databaseKey);
		}

		/// <summary>
		/// Returns an instance of a data access object for the
		/// business object's default database key
		/// </summary>
		/// <returns>Data access object</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual mmDataAccessBase GetDataAccessObject()
		{
			return this.GetDataAccessObject(this.DatabaseKey);
		}

		/// <summary>
		/// Returns a reference to an exising data access object that has
		/// the specified key
		/// </summary>
		/// <param name="databaseKey">Database key</param>
		/// <returns>Data Access object</returns>
		protected virtual mmDataAccessBase GetExistingDataAccessObjectByDbKey(string databaseKey)
		{
			mmDataAccessBase dao = null;

			// Search for a data access object with the specified database key
			foreach (mmDataAccessBase daoItem in this.DataAccessCollection)
			{
				if (daoItem.DatabaseKey == databaseKey)
				{
					dao = daoItem;
					break;
				}
			}

			// If a data access object was found, but it's the wrong database set key,
			// this means a new database set key has been specified. Release the data access
			// class and let the business object instantiate a new instance
			if (dao != null && mmAppBase.DatabaseMgr.DatabaseSetKey != dao.DatabaseSetKey)
			{
				this.DataAccessCollection.Remove(dao);
				dao = null;
			}

			return dao;
		}

		/// <summary>
		/// Returns a reference to an existing data access object that
		/// is of the specified class
		/// </summary>
		/// <param name="dataAccessClass">Data access class</param>
		/// <returns>Data access object</returns>
		protected virtual mmDataAccessBase GetExistingDataAccessObjectByClass(string dataAccessClass)
		{
			mmDataAccessBase dao = null;

			// See if there is an existing dao of the same class
			foreach (mmDataAccessBase daoItem in this.DataAccessCollection)
			{
				if (daoItem.ToString() == dataAccessClass)
				{
					dao = daoItem;
					break;
				}
			}
			return dao;
		}

		/// <summary>
		/// (1) Returns a new, untyped DataSet with the specified table containing the results of the 
		/// command string (based on command type) w/ parameters executed against the specified database.
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="tableName">Table to be filled</param>
		/// <param name="databaseKey">Database</param>
		/// <param name="cmdType">CommandType</param>
		/// <param name="dataParams">Command parameters</param>
		/// <returns>DataSet containing result set</returns>
		protected virtual DataSet GetDataSet(string command, string tableName, string databaseKey,
			CommandType cmdType, params IDbDataParameter[] dataParams)
		{
			// Create a DataSet
			DataSet ds = this.CreateDataSet();

			// Fill the DataSet
			this.FillDataSet(ds, command, tableName, databaseKey, cmdType, dataParams);

			// Return the DataSet
			return ds;
		}

		/// <summary>
		/// (2) Returns a new, untyped DataSet with the specified table containing the results of the 
		/// command string (based on command type) w/ parameters executed against the default database.
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="tableName">Table name</param>
		/// <param name="cmdType">CommandType</param>
		/// <param name="dataParams">Command parameters</param>
		/// <returns>DataSet containing result set</returns>
		protected virtual DataSet GetDataSet(string command, string tableName, CommandType cmdType,
			params IDbDataParameter[] dataParams)
		{
			return this.GetDataSet(command, tableName, this.DatabaseKey, cmdType, dataParams);
		}

		/// <summary>
		/// (3) Returns a new, untyped DataSet with the default table containing the results of the 
		/// command string (based on command type) w/ parameters executed against the default database.
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="cmdType">CommandType</param>
		/// <param name="dataParams">Command Parameters</param>
		/// <returns>DataSet containing result</returns>
		protected virtual DataSet GetDataSet(string command, CommandType cmdType, 
			params IDbDataParameter[] dataParams)
		{
			return this.GetDataSet(command, this.TableName, cmdType, dataParams);
		}

		/// <summary>
		/// (4) Returns a new, untyped DataSet with the specified table containing the 
		/// results of the command string w/ parameters executed against the specified database.
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="tableName">Table Name</param>
		/// <param name="databaseKey">Database key</param>
		/// <param name="dataParams">Command Parameters</param>
		/// <returns>DataSet containing result set</returns>
		protected virtual DataSet GetDataSet(string command, string tableName, string databaseKey,  
			params IDbDataParameter[] dataParams)
		{
			return this.GetDataSet(command, tableName, databaseKey, this.DefaultCommandType, dataParams);
		}

		/// <summary>
		/// (5) Returns a new, untyped DataSet with the specified table containing the 
		/// results of the command string w/ parameters executed against the default database.
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="tableName">Table Name</param>
		/// <param name="dataParams">Command parameters</param>
		/// <returns>DataSet containing result set</returns>
		protected virtual DataSet GetDataSet(string command, string tableName,
			params IDbDataParameter[] dataParams)
		{
			return this.GetDataSet(command, tableName, this.DatabaseKey, dataParams);
		}

		/// <summary>
		/// (6) Returns a new, untyped DataSet with the default table containing the results 
		/// of the command string w/ parameters executed against the default database.
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="dataParams">Command parameters</param>
		/// <returns>DataSet containing result set</returns>
		protected virtual DataSet GetDataSet(string command, params IDbDataParameter[] dataParams)
		{
			return this.GetDataSet(command, this.TableName, dataParams);
		}

		/// <summary>
		/// (7) Returns a new, untyped DataSet with the specified table containing 
		/// the results of the command string executed against the specified database.
		/// </summary>
		/// <param name="command">Command string to be executed</param>
		/// <param name="tableName">Table name</param>
		/// <param name="databaseKey">Database key</param>
		/// <returns>DataSet containing result set</returns>
		protected virtual DataSet GetDataSet(string command, string tableName, string databaseKey)
		{
			return this.GetDataSet(command, tableName, databaseKey, (IDbDataParameter[])null);
		}

		/// <summary>
		/// (8) Returns a new, untyped DataSet with the specified table containing 
		/// the results of the command string executed against the default database
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="tableName">Table Name</param>
		/// <returns>DataSet containing result set</returns>
		protected virtual DataSet GetDataSet(string command, string tableName)
		{
			return this.GetDataSet(command, tableName, this.DatabaseKey);
		}

		/// <summary>
		/// (9) Returns a new, untyped DataSet with the default table containing 
		/// the results of the command string executed against the default database
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <returns>DataSet containing result set</returns>
		protected virtual DataSet GetDataSet(string command)
		{
			return this.GetDataSet(command, this.TableName);
		}

		/// <summary>
		/// (10) Returns a new, untyped DataSet containing the specified table filled by executing the
		/// command string (based on command type) against the specified database. 
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="tableName">Table name</param>
		/// <param name="databaseKey">Database key</param>
		/// <param name="cmdType">CommandType</param>
		/// <returns>DataSet containing result</returns>
		protected virtual DataSet GetDataSet(string command, string tableName, string databaseKey, CommandType cmdType)
		{
			return this.GetDataSet(command, tableName, databaseKey, cmdType, (IDbDataParameter[])null);
		}

		/// <summary>
		/// (11) Returns a new, untyped DataSet containing the specified table filled by executing the
		/// command string (based on command type) against the default database. 
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="tableName">Table name</param>
		/// <param name="cmdType">CommandType</param>
		/// <returns>Dataset containing result</returns>
		protected virtual DataSet GetDataSet(string command, string tableName, CommandType cmdType)
		{
			return this.GetDataSet(command, tableName, this.DatabaseKey, cmdType);
		}

		/// <summary>
		/// (12) Returns a new, untyped DataSet with the default table containing the results of the 
		/// command string (based on command type) executed against the default database.
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="cmdType">Command type</param>
		/// <returns>DataSet containing result</returns>
		protected virtual DataSet GetDataSet(string command, CommandType cmdType)
		{
			return this.GetDataSet(command, this.TableName, cmdType);
		}

		/// <summary>
		/// (13) Returns a new, untyped DataSet with the specified table containing the 
		/// results of executing the Select Command object against the specified database.
		/// </summary>
		/// <param name="command">Select Command object</param>
		/// <param name="tableName">Table name</param>
		/// <param name="databaseKey">Database key</param>
		/// <returns>DataSet</returns>
		protected virtual DataSet GetDataSet(IDbCommand command, string tableName, string databaseKey)
		{
			// Create a DataSet
			DataSet ds = this.CreateDataSet();

			// Fill the DataSet
			this.FillDataSet(ds, command, tableName, databaseKey);

			// Return the DataSet
			return ds;
		}

		/// <summary>
		/// (14) Returns a new, untyped DataSet with the specified table containing the 
		/// results of executing the Select Command object against the default database.
		/// </summary>
		/// <param name="command">Select Command object</param>
		/// <param name="tableName">Table name</param>
		/// <returns></returns>
		protected virtual DataSet GetDataSet(IDbCommand command, string tableName)
		{
			return this.GetDataSet(command, tableName, this.DatabaseKey);
		}

		/// <summary>
		/// (15) Returns a new, untyped DataSet with the default table containing the 
		/// results of executing the Select Command object against the default database.
		/// </summary>
		/// <param name="command">Select Command object</param>
		/// <returns>DataSet containing result set</returns>
		protected virtual DataSet GetDataSet(IDbCommand command)
		{
			return this.GetDataSet(command, this.TableName);
		}

		/// <summary>
		/// (1) Returns a new, typed Entity List containing the results of the command string 
		/// (based on command type) w/ parameters executed against the specified database.
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="tableName">Table to be filled</param>
		/// <param name="databaseKey">Database</param>
		/// <param name="cmdType">CommandType</param>
		/// <param name="dataParams">Command parameters</param>
		/// <returns>Entity List containing the result set</returns>
		protected virtual mmBindingList<T> GetEntityList<T>(string command, string tableName, 
			string databaseKey,
			CommandType cmdType, params IDbDataParameter[] dataParams) where T : mmBusinessEntity, new()
		{
			// Create a DataSet
			DataSet ds = this.CreateDataSet();

			// Fill the DataSet
			this.FillDataSet(ds, command, tableName, databaseKey, cmdType, dataParams);

			return this.CreateEntityList<T>(ds.Tables[tableName]);
		}

		/// <summary>
		/// (2) Returns a new, typed Entity List containing the results of the command string 
		/// (based on command type) w/ parameters executed against the default database.
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="tableName">Table name</param>
		/// <param name="cmdType">CommandType</param>
		/// <param name="dataParams">Command parameters</param>
		/// <returns>Entity List containing the result set</returns>
		protected virtual mmBindingList<T> GetEntityList<T>(string command, string tableName, CommandType cmdType,
			params IDbDataParameter[] dataParams) where T : mmBusinessEntity, new()
		{
			return this.GetEntityList<T>(command, tableName, this.DatabaseKey, cmdType, dataParams);
		}

		/// <summary>
		/// (3) Returns a new, typed Entity List containing the results of the command string 
		/// (based on command type) w/ parameters executed against the default database.
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="cmdType">CommandType</param>
		/// <param name="dataParams">Command Parameters</param>
		/// <returns>Entity List containing the result set</returns>
		protected virtual mmBindingList<T> GetEntityList<T>(string command, CommandType cmdType,
			params IDbDataParameter[] dataParams) where T : mmBusinessEntity, new()
		{
			return this.GetEntityList<T>(command, this.TableName, cmdType, dataParams);
		}

		/// <summary>
		/// (4) Returns a new, typed Entity List with the specified table containing the 
		/// results of the command string w/ parameters executed against the specified database.
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="tableName">Table Name</param>
		/// <param name="databaseKey">Database key</param>
		/// <param name="dataParams">Command Parameters</param>
		/// <returns>Entity List  containing result set</returns>
		protected virtual mmBindingList<T> GetEntityList<T>(string command, string tableName, string databaseKey,
			params IDbDataParameter[] dataParams) where T : mmBusinessEntity, new()
		{
			return this.GetEntityList<T>(command, tableName, databaseKey, this.DefaultCommandType, dataParams);
		}

		/// <summary>
		/// (5) Returns a new, untyped DataSet with the specified table containing the 
		/// results of the command string w/ parameters executed against the default database.
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="tableName">Table Name</param>
		/// <param name="dataParams">Command parameters</param>
		/// <returns>Entity List  containing result set</returns>
		protected virtual mmBindingList<T> GetEntityList<T>(string command, string tableName,
			params IDbDataParameter[] dataParams) where T : mmBusinessEntity, new()
		{
			return this.GetEntityList<T>(command, tableName, this.DatabaseKey, dataParams);
		}

		/// <summary>
		/// (6) Returns a new, untyped DataSet with the default table containing the results 
		/// of the command string w/ parameters executed against the default database.
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="dataParams">Command parameters</param>
		/// <returns>Entity List  containing result set</returns>
		protected virtual mmBindingList<T> GetEntityList<T>(string command,
			params IDbDataParameter[] dataParams) where T : mmBusinessEntity, new()
		{
			return this.GetEntityList<T>(command, this.TableName, dataParams);
		}

		/// <summary>
		/// (7) Returns a new, untyped DataSet with the specified table containing 
		/// the results of the command string executed against the specified database.
		/// </summary>
		/// <param name="command">Command string to be executed</param>
		/// <param name="tableName">Table name</param>
		/// <param name="databaseKey">Database key</param>
		/// <returns>Entity List  containing result set</returns>
		protected virtual mmBindingList<T> GetEntityList<T>(string command, string tableName, string databaseKey)
			where T : mmBusinessEntity, new()
		{
			return this.GetEntityList<T>(command, tableName, databaseKey, (IDbDataParameter[])null);
		}

		/// <summary>
		/// (8) Returns a new, untyped DataSet with the specified table containing 
		/// the results of the command string executed against the default database
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="tableName">Table Name</param>
		/// <returns>Entity List  containing result set</returns>
		protected virtual mmBindingList<T> GetEntityList<T>(string command, string tableName)
			where T : mmBusinessEntity, new()
		{
			return this.GetEntityList<T>(command, tableName, this.DatabaseKey);
		}

		/// <summary>
		/// (9) Returns a new, untyped DataSet with the default table containing 
		/// the results of the command string executed against the default database
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <returns>Entity List  containing result set</returns>
		protected virtual mmBindingList<T> GetEntityList<T>(string command)
			where T : mmBusinessEntity, new()
		{
			return this.GetEntityList<T>(command, this.TableName);
		}

		/// <summary>
		/// (10) Returns a new, untyped DataSet containing the specified table filled by executing the
		/// command string (based on command type) against the specified database. 
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="tableName">Table name</param>
		/// <param name="databaseKey">Database key</param>
		/// <param name="cmdType">CommandType</param>
		/// <returns>Entity List  containing result</returns>
		protected virtual mmBindingList<T> GetEntityList<T>(string command, string tableName, string databaseKey, CommandType cmdType)
			where T : mmBusinessEntity, new()
		{
			return this.GetEntityList<T>(command, tableName, databaseKey, cmdType, (IDbDataParameter[])null);
		}

		/// <summary>
		/// (11) Returns a new, untyped DataSet containing the specified table filled by executing the
		/// command string (based on command type) against the default database. 
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="tableName">Table name</param>
		/// <param name="cmdType">CommandType</param>
		/// <returns>Entity List  containing result</returns>
		protected virtual mmBindingList<T> GetEntityList<T>(string command, string tableName, CommandType cmdType)
			where T : mmBusinessEntity, new()
		{
			return this.GetEntityList<T>(command, tableName, this.DatabaseKey, cmdType);
		}

		/// <summary>
		/// (12) Returns a new, untyped DataSet with the default table containing the results of the 
		/// command string (based on command type) executed against the default database.
		/// </summary>
		/// <param name="command">Command to be executed</param>
		/// <param name="cmdType">Command type</param>
		/// <returns>Entity List  containing result</returns>
		protected virtual mmBindingList<T> GetEntityList<T>(string command, CommandType cmdType)
			where T : mmBusinessEntity, new()
		{
			return this.GetEntityList<T>(command, this.TableName, cmdType);
		}

		/// <summary>
		/// (13)Returns a new, untyped DataSet with the specified table containing the 
		/// results of executing the Select Command object against the specified database.
		/// </summary>
		/// <param name="command">Select Command object</param>
		/// <param name="tableName">Table name</param>
		/// <param name="databaseKey">Database key</param>
		/// <returns>Entity List containing result</returns>
		protected virtual mmBindingList<T> GetEntityList<T>(IDbCommand command, string tableName, string databaseKey)
			where T : mmBusinessEntity, new()
		{
			// Create a DataSet
			DataSet ds = this.CreateDataSet();

			// Fill the DataSet
			this.FillDataSet(ds, command, tableName, databaseKey);

			// Return the Entity List
			return this.CreateEntityList<T>(ds.Tables[tableName]);
		}

		/// <summary>
		/// (14) Returns a new, untyped DataSet with the specified table containing the 
		/// results of executing the Select Command object against the default database.
		/// </summary>
		/// <param name="command">Select Command object</param>
		/// <param name="tableName">Table name</param>
		/// <returns></returns>
		protected virtual mmBindingList<T> GetEntityList<T>(IDbCommand command, string tableName)
			where T : mmBusinessEntity, new()
		{
			return this.GetEntityList<T>(command, tableName, this.DatabaseKey);
		}

		/// <summary>
		/// (15) Returns a new, untyped DataSet with the default table containing the 
		/// results of executing the Select Command object against the default database.
		/// </summary>
		/// <param name="command">Select Command object</param>
		/// <returns>DataSet containing result set</returns>
		protected virtual mmBindingList<T> GetEntityList<T>(IDbCommand command)
			where T : mmBusinessEntity, new()
		{
			return this.GetEntityList<T>(command, this.TableName);
		}

		/// <summary>
		/// Creates an array of DataTables. If the data access object's
		/// StateChangeAllTables flag is false (the default), the array
		/// only contains the specified DataTable. If the flag is true,
		/// it contains all DataTables in the specified DataSet
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="tableName">DataTable Name</param>
		/// <param name="databaseKey">Database key</param>
		/// <returns>Array of DataTable names</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        protected string[] GetDataTables(DataSet ds, string tableName, string databaseKey)
		{
			string[] DataTables;

			mmDataAccessBase dao = this.GetDataAccessObject(databaseKey);
			if (dao.StateChangeAllTables && ds.Tables.Count > 0)
			{
				DataTables = new string[ds.Tables.Count];
				for(int i=0; i < ds.Tables.Count; i++)
				{
					DataTables[i] = ds.Tables[i].TableName;
				}
			}
			else
			{
				DataTables = new string[] {tableName};
			}
			return DataTables;
		}

		/// <summary>
		/// Creates an array of DataTables. If the data access object's
		/// StateChangeAllTables flag if false (the default), the array
		/// only contains the specified DataTable. If the flag is false,
		/// it contains all DataTables in the specified DataSet
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="tableName">DataTable name</param>
		/// <returns>Array of DataTables</returns>
		protected string[] GetDataTables(DataSet ds, string tableName)
		{
			return this.GetDataTables(ds, tableName, this.DatabaseKey);
		}
		
		/// <summary>
		/// Returns an empty DataTable in the specified DataSet and database
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="tableName">Table Name</param>
		/// <param name="databaseKey">Database Key</param>
		/// <returns>Empty DataSet</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual DataSet GetEmptyDataSet(DataSet ds, string tableName, string databaseKey)
		{
			// If a null DataSet was passed, create one now
			if (ds == null)
			{
				ds = this.CreateDataSet();
				this.SetCurrentDataSet(ds, tableName);
			}
			// Get the specified DataTable or ALL DataTables
			string[] DataTables = this.GetDataTables(this.GetCurrentDataSet(), tableName, databaseKey);
			string Schema = "";
			string PhysicalObjectName;

			// Get a data access object
			mmDataAccessBase dao = this.GetDataAccessObject(databaseKey);

			foreach (string Table in DataTables)
			{
				if (this.HookPreGetData(this.GetCurrentDataSet(), Table))
				{
					// Raise the Retrieving State Change event
					this.CallStateChange(mmBusinessState.Retrieving, Table);

					// If this is the business object's primary data table, pass the
					// PhysicalDbcObjectName value, otherwise, pass the current DataTable name
					PhysicalObjectName = (Table == this.TableName) 
						? this.PhysicalDbcObjectName
						: Table;

					// If the schema name is included in the PhysicalObjectName, break it out
					if (PhysicalObjectName.Contains("."))
					{
						Schema = mmDataAccessBase.JustSchema(PhysicalObjectName);
						PhysicalObjectName = mmDataAccessBase.JustLongObjectName(PhysicalObjectName);
					}

					switch (this.DefaultCommandType)
					{
						case CommandType.StoredProcedure:

							IDbCommand SelectCommand = dao.CreateSelectCommand();

							if (SelectCommand != null)
							{
								ds = dao.GetEmptyDataSetBySproc(ds, Table, Schema, SelectCommand.CommandText);
							}
							else if (!String.IsNullOrEmpty(this.UpdateSelectStatement))
							{
								ds = dao.GetEmptyDataSetBySproc(ds, Table, Schema, this.UpdateSelectStatement);
							}

							break;
						case CommandType.Text:
							// Get an empty DataTable
							ds = dao.GetEmptyDataSet(ds, Table, PhysicalObjectName, this.UpdateSelectStatement);
							break;
						default:
							break;
					}

					if (Table.ToLower() == tableName.ToLower())
					{
						// Set the current DataSet
						this.SetCurrentDataSet(ds, tableName, true, false);

						this.DataRow = null;
					}

					// Set the autoincrement value
					if (this.AutoIncrementCustom)
					{
						this.SetAutoIncrement(ds, Table);
					}

					// Call Post GetData Hook
					this.HookPostGetData();

					// Raise the Retrieved State Change event
					this.CallStateChange(mmBusinessState.Retrieved, Table);
				}
			}

			// Return the DataSet
			return this.GetCurrentDataSet();
		}

		/// <summary>
		/// Returns an empty DataTable in the specified DataSet
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="tableName">Table Name</param>
		/// <returns>Empty DataSet</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual DataSet GetEmptyDataSet(DataSet ds, string tableName)
		{
			return this.GetEmptyDataSet(ds, tableName, this.DatabaseKey);
		}

		/// <summary>
		/// Returns an empty DataSet and DataTable for the specified table name and database
		/// </summary>
		/// <param name="tableName">Table Name</param>
		/// <param name="databaseKey">Database Key</param>
		/// <returns>Empty DataSet</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual DataSet GetEmptyDataSet(string tableName, string databaseKey)
		{
			// Create a new DataSet
			DataSet ds = this.CreateDataSet();
			return this.GetEmptyDataSet(ds, tableName, databaseKey);
		}

		/// <summary>
		/// Returns an empty DataSet and DataTable for the specified table name
		/// and default database
		/// </summary>
		/// <param name="tableName">Table Name</param>
		/// <returns>Empty DataSet</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual DataSet GetEmptyDataSet(string tableName)
		{
			return this.GetEmptyDataSet(tableName, this.DatabaseKey);
		}

		/// <summary>
		/// Returns an empty DataSet for the default database and table name
		/// </summary>
		/// <returns>Empty DataSet</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual DataSet GetEmptyDataSet()
		{
			return this.GetEmptyDataSet(this.TableName);
		}

		/// <summary>
		/// Returns a description string of the currently data
		/// </summary>
		/// <returns>Description string</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual string GetDescription(DataRowView drView)
		{
			string description = "";
			if (drView != null)
			{

				if (!mmString.Empty(this.DescriptionField))
				{
					description = drView[this.DescriptionField].ToString().Trim();
				}
				else if (this.DescriptionFields != null && this.DescriptionFields.Length > 0)
				{
					description = "";
					foreach (string s in this.DescriptionFields)
					{
						description += drView[s].ToString().Trim() + " ";
					}
				}
			}
			return description;
		}

		/// <summary>
		/// Returns a description string of the current row
		/// </summary>
		/// <returns>Description string</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public override string GetDescription()
		{
			string description = "";

			if (this.DataRow != null)
			{
				if (!mmString.Empty(this.DescriptionField))
				{
					description = this.DataRow[this.DescriptionField].ToString().Trim();
				}
				else if (this.DescriptionFields != null && this.DescriptionFields.Length > 0)
				{
					description = "";
					foreach (string s in this.DescriptionFields)
					{
						description += DataRow[s].ToString().Trim() + " ";
					}
				}
			}
			return description;
		}

		/// <summary>
		/// (1) Fills the DataSet's specified table with the results of the command string 
		/// (based on command type) w/ parameters executed against the specified database.
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="command">Command to be executed</param>
		/// <param name="tableName">Table to be filled</param>
		/// <param name="databaseKey">Database</param>
		/// <param name="cmdType">CommandType</param>
		/// <param name="dataParams">Command parameters</param>
		protected virtual void FillDataSet(DataSet ds, string command, string tableName, 
			string databaseKey,	CommandType cmdType, params IDbDataParameter[] dataParams)
		{

			this.DataRow = null;
			string[] DataTables;

			// If the specified DataSet is null, create a new one
//			ds = this.GetCurrentDataSet();
			if (ds == null)
				ds = this.CreateDataSet();
			
			// Get the data access object
			mmDataAccessBase dao = this.GetDataAccessObject(databaseKey);

			// Call the pre-Get Data hook
			if (this.HookPreGetData(this.GetCurrentDataSet(), this.CurrentTableName))
			{
				// Get the specified DataTable or ALL DataTables
				DataTables = this.GetDataTables(ds, tableName, databaseKey);

				foreach (string table in DataTables)
				{
					// Raise the Retrieving state change event
					this.CallStateChange(mmBusinessState.Retrieving, table);
				}

				// Get the DataSet from the data access object
				try
				{
					dao.FillDataSet(ds, command, tableName, cmdType, dataParams, this.ClearOnFillDataSet);
				}
				catch (ArgumentException e)
				{
					if (this.TableName == "")
					{
						throw new ArgumentException("You must specify a value for the TableName property " +
							"of the " + mmString.JustExt(this.ToString()) + " business object.");
					}
					else
					{
						throw;
					}
				}

				// Set the autoincrement value
				if (this.AutoIncrementCustom)
				{
					this.SetAutoIncrement(ds, tableName);
				}

				// Set the current data set (also calls HookPostGetData)
				this.SetCurrentDataSet(ds, tableName, true, false);

				// Set the current DataRow
				if (tableName == this.TableName)
				{
					this.StoreDataRow(ds);
				}

				// Set the current row to zero
				this.RowNum = 0;
			}

			// Get the specified DataTable or ALL DataTables
			DataTables = this.GetDataTables(ds, tableName, databaseKey);

			foreach (string table in DataTables)
			{
				// Call the Post-Get Data Hook
				this.HookPostGetData();

				// Raise the Retrieved state change event
				this.CallStateChange(mmBusinessState.Retrieved, table);
			}
		}
		
		/// <summary>
		/// (2)  Fills the DataSet's specified table with the results of the command string 
		/// (based on command type) w/ parameters executed against the default database.
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="command">Command to be executed</param>
		/// <param name="tableName">Table name</param>
		/// <param name="cmdType">CommandType</param>
		/// <param name="dataParams">Command parameters</param>
		protected virtual void FillDataSet(DataSet ds, string command, string tableName, CommandType cmdType,
			params IDbDataParameter[] dataParams)
		{
			this.FillDataSet(ds, command, tableName, this.DatabaseKey, cmdType, dataParams);
		}

		/// <summary>
		/// (3) Fills the DataSet's default table with the results of the command string 
		/// (based on command type) w/ parameters executed against the default database.
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="command">Command to be executed</param>
		/// <param name="cmdType">CommandType</param>
		/// <param name="dataParams">Command Parameters</param>
		protected virtual void FillDataSet(DataSet ds, string command, CommandType cmdType, 
			params IDbDataParameter[] dataParams)
		{
			this.FillDataSet(ds, command, this.TableName, cmdType, dataParams);
		}

		/// <summary>
		/// (4) Fills the DataSet's specified table with the results of the 
		/// command string w/ parameters executed against the specified database.
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="command">Command to be executed</param>
		/// <param name="tableName">Table Name</param>
		/// <param name="databaseKey">Database key</param>
		/// <param name="dataParams">Command Parameters</param>
		protected virtual void FillDataSet(DataSet ds, string command, string tableName, 
			string databaseKey,  params IDbDataParameter[] dataParams)
		{
			this.FillDataSet(ds, command, tableName, databaseKey, this.DefaultCommandType, dataParams);
		}

		/// <summary>
		/// (5) Fills the DataSet's specified table with the results of the 
		/// command string w/ parameters executed against the default database
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="command">Command to be executed</param>
		/// <param name="tableName">Table Name</param>
		/// <param name="dataParams">Command parameters</param>
		protected virtual void FillDataSet(DataSet ds, string command, string tableName,
			params IDbDataParameter[] dataParams)
		{
			this.FillDataSet(ds, command, tableName, this.DatabaseKey, dataParams);
		}

		/// <summary>
		/// (6) Fills the DataSet's default table with the results of the 
		/// command string w/ parameters executed against the default database.		
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="command">Command to be executed</param>
		/// <param name="dataParams">Command parameters</param>
		protected virtual void FillDataSet(DataSet ds, string command,
			params IDbDataParameter[] dataParams)
		{
			this.FillDataSet(ds, command, this.TableName, dataParams);
		}

		/// <summary>
		/// (7)  Fills the DataSet's specified table with the results of the 
		/// command string executed against the specified database.
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="command">Command string to be executed</param>
		/// <param name="tableName">Table name</param>
		/// <param name="databaseKey">Database key</param>
		protected virtual void FillDataSet(DataSet ds, string command, string tableName, string databaseKey)
		{
			this.FillDataSet(ds, command, tableName, databaseKey, (IDbDataParameter[])null);
		}

		/// <summary>
		/// (8)  Fills the DataSet's specified table with the results of the 
		/// command string executed against the default database.
		/// </summary>
		/// <param name="ds">Typed DataSet</param>
		/// <param name="command">Command to be executed</param>
		/// <param name="tableName">Table Name</param>
		protected virtual void FillDataSet(DataSet ds, string command, string tableName)
		{
			this.FillDataSet(ds, command, tableName, this.DatabaseKey);
		}

		/// <summary>
		/// (9) Fills the DataSet's default table with the results of the 
		/// command string executed against the default database.
		/// </summary>
		/// <param name="ds">Typed DataSet</param>
		/// <param name="command">Command to be executed</param>
		protected virtual void FillDataSet(DataSet ds, string command)
		{
			this.FillDataSet(ds, command, this.TableName);
		}

		/// <summary>
		/// (10) Fills the DataSet's specified table with the results of the 
		/// command string (based on command type) executed against the specified database. 
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="command">Command to be executed</param>
		/// <param name="tableName">Table name</param>
		/// <param name="databaseKey">Database key</param>
		/// <param name="cmdType">CommandType</param>
		protected virtual void FillDataSet(DataSet ds, string command, string tableName, string databaseKey, CommandType cmdType)
		{
			this.FillDataSet(ds, command, tableName, databaseKey, cmdType, (IDbDataParameter[])null);
		}

		/// <summary>
		/// (11) Fills the DataSet's specified table with the results of the 
		/// command string (based on command type) executed against the default database.
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="command">Command to be executed</param>
		/// <param name="tableName">Table name</param>
		/// <param name="cmdType">CommandType</param>
		protected virtual void FillDataSet(DataSet ds, string command, string tableName, CommandType cmdType)
		{
			this.FillDataSet(ds, command, tableName, this.DatabaseKey, cmdType);
		}

		/// <summary>
		/// (12) Fills the DataSet's default table with the results of executing 
		/// the Select Command object against the specified database.
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="command">Command to be executed</param>
		/// <param name="cmdType">Command type</param>
		protected virtual void FillDataSet(DataSet ds, string command, CommandType cmdType)
		{
			this.FillDataSet(ds, command, this.TableName, cmdType);
		}

		/// <summary>
		/// (13) Fills the default table in the DataSet by executing the
		/// Select Command object against the specified database
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="command">Select Command object</param>
		/// <param name="tableName">Table name</param>
		/// <param name="databaseKey">Database key</param>
		protected virtual void FillDataSet(DataSet ds, IDbCommand command, string tableName, string databaseKey)
		{
			// Get the data access object
			mmDataAccessBase dao = this.GetDataAccessObject(databaseKey);

			// Get the specified DataTable or ALL DataTables
			string[] DataTables = this.GetDataTables(ds, tableName, databaseKey);

			foreach(string table in DataTables)
			{
				bool IsPrimaryTable = (table.ToLower() == tableName.ToLower());

				if (this.HookPreGetData(this.GetCurrentDataSet(), this.CurrentTableName))
				{
					// Raise the Retrieving state change event
					this.CallStateChange(mmBusinessState.Retrieving, table);

					if (IsPrimaryTable)
					{
						// Get the DataSet from the data access object
						try
						{
							dao.FillDataSet(ds, command, tableName, this.ClearOnFillDataSet);
						}
						catch (ArgumentException e)
						{
							if (this.TableName == "")
							{
								throw new ArgumentException("You must specify a value for the TableName property " +
									"of the " + mmString.JustExt(this.ToString()) + " business object.");
							}
							else
							{
								throw;
							}
						}

						// Set the autoincrement value
						if (this.AutoIncrementCustom)
						{
							this.SetAutoIncrement(ds, tableName);
						}

						// Set the current data set
						this.SetCurrentDataSet(ds, tableName);

						// Set the current DataRow
						if (tableName == this.TableName)
						{
							this.StoreDataRow(ds);
						}

						// Set the current row to zero
						this.RowNum = 0;
					}

					// Call the Post-Get Data Hook
					this.HookPostGetData();

					// Raise the Retrieved state change event
					this.CallStateChange(mmBusinessState.Retrieved, table);
				}
			}
		}

		/// <summary>
		/// (14) Fills the DataSet's specified table with the results of executing 
		/// the Select Command object against the default database.
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="command">Select Command object</param>
		/// <param name="tableName">Table name</param>
		protected virtual void FillDataSet(DataSet ds, IDbCommand command, string tableName)
		{
			this.FillDataSet(ds, command, tableName, this.DatabaseKey);
		}

		/// <summary>
		/// (15) Fills the DataSet's default table with the results of executing 
		/// the Select Command object against the default database.
		/// </summary>
		/// <param name="ds">DataSet to be filled</param>
		/// <param name="command">Select Command object</param>
		protected virtual void FillDataSet(DataSet ds, IDbCommand command)
		{
			this.FillDataSet(ds, command, this.TableName);
		}
		
		/// <summary>
		/// 1) Returns the primary key value for the specified row in the current DataSet
		/// and specified table name and row number
		/// </summary>
		/// <param name="tableName">Table Name</param>
		/// <param name="rowNum">Row number (-1 = last row)</param>
		/// <returns>primary key value</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual object GetPrimaryKeyValue(string tableName, int rowNum)
		{
			object PrimaryKeyValue = null;

			if (this.PrimaryKey != null && this.PrimaryKey != "")
			{
				DataSet ds = this.GetCurrentDataSet();
				if (ds != null)
				{
					if (ds.Tables[tableName] != null)
					{
						// Get the current row count
						int RowCount = ds.Tables[tableName].Rows.Count;

						// Make sure the row count is > 0 and the specified row number
						// is within the range of the row count
						if (RowCount > 0 && RowCount >= rowNum)
						{
							// If rowNum = -1, set the row number to the last row
							if (rowNum == -1)
							{
								rowNum = RowCount - 1;
							}

							// Get the primary key field name
							DataRow dr = ds.Tables[tableName].Rows[rowNum];
							if (dr.RowState != DataRowState.Deleted && 
								dr.RowState != DataRowState.Detached)
							{
								string[] PKFields = this.GetPrimaryKeyFields(ds, tableName);
								if (PKFields != null)
								{
									PrimaryKeyValue = (object)dr[PKFields[0]];
								}
							}
						}
					}
				}
			}
			return PrimaryKeyValue;
		}

		/// <summary>
		/// 2) Returns the primary key value for the first row in the current DataSet
		/// and specified table name
		/// </summary>
		/// <param name="tableName">Table name</param>
		/// <returns>Primary key value</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual object GetPrimaryKeyValue(string tableName)
		{
			return this.GetPrimaryKeyValue(tableName, 0);
		}

		/// <summary>
		/// 3) Returns the primary key value for the first row in the current DataSet
		/// and specified table name
		/// </summary>
		/// <returns>primary key value</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public override object GetPrimaryKeyValue()
		{
			return this.GetPrimaryKeyValue(this.CurrentTableName);
		}

		/// <summary>
		/// 4) Returns the primary key value of the specified DataRowView
		/// </summary>
		/// <param name="drView">DataRowView</param>
		/// <returns>Primary key value</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual object GetPrimaryKeyValue(DataRowView drView)
		{
			object PrimaryKeyValue = null;
			if (drView != null &&
				(this.PrimaryKey != null && this.PrimaryKey != ""))
			{
				if (drView.Row.RowState != DataRowState.Deleted &&
					drView.Row.RowState != DataRowState.Detached)
				{
					string[] PKFields = this.GetPrimaryKeyFields(drView);

					if (PKFields != null)
					{
						PrimaryKeyValue = (object)drView[PKFields[0]];
					}
				}
			}
			return PrimaryKeyValue;
		}

		/// <summary>
		/// 5) Returns the primary key value of the specified DataRow
		/// </summary>
		/// <param name="dr">DataRow</param>
		/// <returns>Primary key value</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual object GetPrimaryKeyValue(DataRow dr)
		{
			object PrimaryKeyValue = null;
			if (dr != null &&
				(this.PrimaryKey != null && this.PrimaryKey != ""))
			{
				if (dr.RowState != DataRowState.Deleted &&
					dr.RowState != DataRowState.Detached)
				{
					string[] PKFields = this.GetPrimaryKeyFields(dr);
					if (PKFields != null)
					{
						PrimaryKeyValue = (object)dr[PKFields[0]];
					}
				}
			}
			return PrimaryKeyValue;
		}

		/// <summary>
		/// (1) Returns the primary key fields for the specified DataTable
		/// </summary>
		/// <param name="dt">DataTable</param>
		/// <returns>Primary key fields (null if not found)</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual string[] GetPrimaryKeyFields(DataTable dt)
		{
			string[] PKFields = null;

			if (!mmString.Empty(this.PrimaryKey))
			{
				if (dt.Columns.Contains(this.PrimaryKey))
				{
					PKFields = new string[] {this.PrimaryKey};
				}
			}
			else if (this.PrimaryKeys != null && 
				this.PrimaryKeys.Length > 0 && 
				dt.TableName == this.TableName)
			{
				PKFields = this.PrimaryKeys;
			}
			if (PKFields == null && dt.PrimaryKey.Length > 0)
			{
				PKFields = new string[dt.PrimaryKey.Length];
				for (int i=0; i<dt.PrimaryKey.Length; i++)
				{
					PKFields[i] = dt.PrimaryKey[i].ColumnName;
				}
			}
			return PKFields;
		}

		/// <summary>
		/// Returns the primary key fields for the specified DataRow
		/// </summary>
		/// <param name="dr">DataRow</param>
		/// <returns>Primary key fields (null if not found)</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual string[] GetPrimaryKeyFields(DataRow dr)
		{
			return this.GetPrimaryKeyFields(dr.Table);
		}

		/// <summary>
		/// Returns the primary key fields for the specified DataRowView
		/// </summary>
		/// <param name="drView">DataRow</param>
		/// <returns>Primary key fields (null if not found)</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual string[] GetPrimaryKeyFields(DataRowView drView)
		{
			return this.GetPrimaryKeyFields(drView.DataView.Table);
		}

		/// <summary>
		/// Returns the primary key fields for the specified DataSet and table
		/// </summary>
		/// <param name="ds">DataSet </param>
		/// <param name="tableName">Table Name</param>
		/// <returns>Primary key fields (null if not found)</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual string[] GetPrimaryKeyFields(DataSet ds, string tableName)
		{
			return this.GetPrimaryKeyFields(ds.Tables[tableName]);
		}

		/// <summary>
		/// 1) Returns the primary key value for the first row in the current DataSet
		/// and specified table name and row number
		/// </summary>
		/// <param name="tableName">Table Name</param>
		/// <param name="rowNum">Row number (-1 = last row)</param>
		/// <returns>primary key value</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual object[] GetPrimaryKeyValues(string tableName, int rowNum)
		{
			object[] PrimaryKeyValues = null;

			// Get the current DataSet
			DataSet ds = this.GetCurrentDataSet();
			if (ds != null && ds.Tables[tableName] != null)
			{
				// Get the primary key fields
				string[] PKFields = this.GetPrimaryKeyFields(ds, tableName);

				if (PKFields != null)
				{
					// Get the current row count
					int RowCount = ds.Tables[tableName].Rows.Count;

					// Make sure the row count is > 0 and the specified row number
					// is within the range of the row count
					if (RowCount > 0 && RowCount >= rowNum)
					{
						// Set the length of the primary key value array to the number of PK fields
						PrimaryKeyValues = new Object[PKFields.Length];

						// If rowNum = -1, set the row number to the last row
						if (rowNum == -1)
						{
							rowNum = RowCount - 1;
						}

						// Get the primary key field name
						DataRow dr = ds.Tables[tableName].Rows[rowNum];
						if (dr.RowState != DataRowState.Deleted &&
							dr.RowState != DataRowState.Detached)
						{
							int KeyNum = 0;
							foreach (string key in PKFields)
							{
								if (dr.Table.Columns.Contains(key))
								{
									PrimaryKeyValues[KeyNum] = 
										(object)dr[key];
									KeyNum++;
								}
								else
								{
									// Primary key not found, null the value collection and exit
									PrimaryKeyValues = null;
									break;
								}
							}
						}
					}
				}
			}
			
			return PrimaryKeyValues;
		}

		/// <summary>
		/// 2) Returns the primary key value for the first row in the current DataSet
		/// and specified table name
		/// </summary>
		/// <param name="tableName">Table name</param>
		/// <returns>Primary key value</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual object[] GetPrimaryKeyValues(string tableName)
		{
			return this.GetPrimaryKeyValues(tableName, 0);
		}

		/// <summary>
		/// 3) Returns the primary key value for the first row in the current DataSet
		/// and specified table name
		/// </summary>
		/// <returns>primary key value</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public override object[] GetPrimaryKeyValues()
		{
			return this.GetPrimaryKeyValues(this.CurrentTableName);
		}

		/// <summary>
		/// 4) Returns the primary key value of the specified DataRowView
		/// </summary>
		/// <param name="drView">DataRowView</param>
		/// <returns>Primary key value</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual object[] GetPrimaryKeyValues(DataRowView drView)
		{
			object[] PrimaryKeyValues = null;
			if (drView != null)
			{
				if (drView.Row.RowState != DataRowState.Deleted &&
					drView.Row.RowState != DataRowState.Detached)
				{
					// Get the primary key fields
					string[] PKFields = this.GetPrimaryKeyFields(drView);

					if (PKFields != null)
					{
						// Set the length of the primary key value array to the number of PK fields
						PrimaryKeyValues = new object[PKFields.Length];
						int KeyNum = 0;
						foreach (string key in PKFields)
						{
							if (drView.DataView.Table.Columns.Contains(key))
							{
								PrimaryKeyValues[KeyNum] = 
									(object)drView[key];
								KeyNum++;
							}
							else
							{
								// Primary key not found, null the value collection and exit
								PrimaryKeyValues = null;
								break;
							}
						}
					}
				}
			}
			return PrimaryKeyValues;
		}

		/// <summary>
		/// 5) Returns the primary key value of the specified DataRow
		/// </summary>
		/// <param name="dr">DataRow</param>
		/// <returns>Primary key value</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual object[] GetPrimaryKeyValues(DataRow dr)
		{
			object[] PrimaryKeyValues = null;
			if (dr != null)
			{
				if (dr.RowState != DataRowState.Deleted &&
					dr.RowState != DataRowState.Detached)
				{
					// Get the primary key fields
					string[] PKFields = this.GetPrimaryKeyFields(dr);

					if (PKFields != null)
					{
						// Set the length of the primary key value array to the number of PK fields
						PrimaryKeyValues = new object[PKFields.Length];
						int KeyNum = 0;
						foreach (string key in PKFields)
						{
							if (dr.Table.Columns.Contains(key))
							{
								PrimaryKeyValues[KeyNum] = 
									(object)dr[key];
								KeyNum++;
							}
							else
							{
								// Primary key not found, null the value collection and exit
								PrimaryKeyValues = null;
								break;
							}
						}
					}
				}
			}
			return PrimaryKeyValues;
		}
		
		/// <summary>
		/// Returns the number of rows (excluding deleted rows)
		/// in the specified table of the current DataSet
		/// </summary>
		/// <param name="tableName">Name of table to act on</param>
		/// <returns>Row count</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
		public virtual int GetRowCount(string tableName)
		{
			int Count = 0;

			DataSet ds = this.GetCurrentDataSet();
			if (ds != null)
			{
				DataView dv = new DataView(ds.Tables[tableName]);
				// Filter out everything except the Deleted rows
				dv.RowStateFilter = DataViewRowState.CurrentRows;
				Count = dv.Count;
			}
			return Count;
		}

		/// <summary>
		/// Returns the number of rows (excluding deleted rows)
		/// in the specified DataView
		/// </summary>
		/// <param name="dv">DataView</param>
		/// <returns>Row Count</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual int GetRowCount(DataView dv)
		{
			int Count = 0;

			if (dv != null)
			{
				// Save the original row state
				DataViewRowState SaveState = dv.RowStateFilter;
				// Set the state to CurrentRows
				dv.RowStateFilter = DataViewRowState.CurrentRows;
				// Get the count
				Count = dv.Count;
				// Restore the original row state
				dv.RowStateFilter = SaveState;
			}
			return Count;
		}

		/// <summary>
		/// Returns the number of rows (exluding deleted rows)
		/// in the default table of the current DataSet
		/// </summary>
		/// <returns>Row count</returns>
		public virtual int GetRowCount()
		{
			return this.GetRowCount(this.TableName);
		}

		/// <summary>
		/// Handles exceptions encountered by the business object
		/// </summary>
		/// <param name="e">Exception</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public override void HandleException(Exception e)
		{
			this.ExceptionHandled = false;

			// Store the exception at the business object level
			this.Exception = e;

			// Set to null since this IS the exception business object
			this.ExceptionObject = null;

			// Build a concurrency exception message
			DBConcurrencyException dbEx = e as DBConcurrencyException;

			if (dbEx != null)
			{
				this.ConcurrencyExceptionMsg = 
					this.BuildConcurrencyExceptionMsg(dbEx);
				// Indicate exception was handled
				this.ExceptionHandled = true;
			}
			else
			{
				this.ConcurrencyExceptionMsg = null;
				if (this.AutoUseTransactions)
				{
					this.TransactionRollback();
				}
			}
		}

		/// <summary>
		/// Returns a boolean value indicating if the business object's
		/// current DataSet has changes (including pending changes)
		/// </summary>
		/// <returns>Logical true if changed, otherwise false</returns>
		public override bool IsChanged()
		{
			bool HasChanges = false;

			DataSet ds = this.GetCurrentDataSet();

			if (ds != null)
			{
				foreach (DataTable dt in ds.Tables)
				{
					// Get the number of rows in the DataTable
					int RowCount = dt.Rows.Count;

					// Check if any rows are unchanged or have proposed changes
					for (int row = 0; row < RowCount; row++)
					{
						if (dt.Rows[row].RowState != DataRowState.Unchanged || 
							dt.Rows[row].HasVersion(DataRowVersion.Proposed))
						{
							HasChanges = true;
							break;
						}
					}
				}
			}

			// Check if any child business objects have changes
			if (!HasChanges)
			{
				foreach(mmBusinessObject BizObj in this.RefBizObj)
				{
					HasChanges = BizObj.IsChanged();
					if (HasChanges)
					{
						break;
					}
				}
			}

			return HasChanges;
		}

		/// <summary>
		/// Gets the current data row in the database that caused a concurrency issue
		/// </summary>
		/// <param name="tableName">Table Name</param>
		/// <param name="physicalDbcObjectName">Physical database object name</param>
		/// <param name="pks">Primary Keys</param>
		/// <param name="pkFields">Primary Key Fields</param>
		/// <returns>Concurrency DataSet containing conflict row</returns>
		protected virtual DataSet GetConflictData(string tableName, string physicalDbcObjectName, object[] pks, string[] pkFields)
		{
			// Get a data access object
			mmDataAccessBase dao = this.GetDataAccessObject();
			DataSet ds = this.CreateDataSet();

			// Try to create a Concurrency Select Command
			IDbCommand ConcurrencySelectCommand = dao.CreateSelectByPkCommand();

			if (ConcurrencySelectCommand != null)
			{
				string ParameterName;
				for (int i = 0; i < pkFields.Length; i++)
				{
					ParameterName = dao.ParameterPrefixChar + pkFields[i];
					if (ConcurrencySelectCommand.Parameters.Contains(ParameterName))
					{
						((IDbDataParameter)ConcurrencySelectCommand.Parameters[ParameterName]).Value = pks[i];
					}
				}

				dao.FillDataSet(ds, ConcurrencySelectCommand, tableName, false);
			}
			else
			{

				// Create a parameter object array for the primary key(s)
				IDbDataParameter[] param = new IDbDataParameter[pks.Length];

				// If the concurrency select statement is empty, use the one
				// we created dynamically
				if (this.ConcurrencySelectStatement == "")
				{
					// Create the Select statement
					string SelectStatement = "Select * From " +
						dao.TableNameDelimitBegin + physicalDbcObjectName + dao.TableNameDelimitEnd +
						" WHERE ";

					// Create the primary key parameters
					for (int i = 0; i < pks.Length; i++)
					{
						param[i] = dao.CreateParameter(dao.ParameterPrefixChar + (dao.ParameterNameIncluded ? pkFields[i] : ""), pks[i]);
						if (i > 0)
						{
							SelectStatement += " AND ";
						}
						SelectStatement += pkFields[i] + " = " + dao.ParameterPrefixChar + (dao.ParameterNameIncluded ? pkFields[i] : "");
					}
					this.ConcurrencySelectStatement = SelectStatement;
				}
				else
				{
					// A Select statement has already been specified. Create the 
					// primary key parameters
					for (int i = 0; i < pks.Length; i++)
					{
						param[i] = dao.CreateParameter(dao.ParameterPrefixChar + (dao.ParameterNameIncluded ? pkFields[i] : ""), pks[i]);
					}
				}

				// Retrieve a DataSet based on the specified information
				dao.FillDataSet(ds,
					this.ConcurrencySelectStatement,
					tableName,
					CommandType.Text,
					param,
					false);
			}

			return ds;
		}

		/// <summary>
		/// Gets the data row in the database that caused a concurrency issue based
		/// on the PK of the specified DataRow
		/// </summary>
		/// <param name="row">DataRow</param>
		/// <returns>Concurrency DataSet containing conflict row</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual DataSet GetConflictData(DataRow row)
		{
			DataSet ds = null;

			// Get the primary key(s) values
			object[] pks = this.GetPrimaryKeyValues(row);

			string PhysicalDbcObjectName = (row.Table.TableName == this.TableName)
				? this.PhysicalDbcObjectName : row.Table.TableName;

			// Get a row that matches the key values
			ds = this.GetConflictData(row.Table.TableName, PhysicalDbcObjectName,
				pks, this.GetPrimaryKeyFields(row));

			return ds;
		}

		/// <summary>
		/// Loads an individual row by numeric primary key into the DataRow property
		/// This method handles long, byte, sbyte, int, uint, short, and ushort values
		/// </summary>
		/// <param name="pk">Numeric primary key</param>
		/// <returns>Logical true if successful, otherwise false</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool LoadRow(object pk)
		{
			mmDataAccessBase dao = this.GetDataAccessObject();
			IDbDataParameter param1 = dao.CreateParameter(dao.ParameterPrefixChar + (dao.ParameterNameIncluded ? "PK" : ""), pk);
			DataSet ds = this.GetDataSet("Select * From " + 
				dao.TableNameDelimitBegin + this.TableName + dao.TableNameDelimitEnd +
				" Where " + 
				this.PrimaryKey + " = " + dao.ParameterPrefixChar + (dao.ParameterNameIncluded ? "PK" : ""), this.TableName, param1 );
			return this.StoreDataRow(ds);
		}

		/// <summary>
		/// Reads the specified XML file into the passed DataSet
		/// </summary>
		/// <param name="xmlFile">XML file</param>
		/// <param name="ds">DataSet into which the XML file is read</param>
		public virtual void ReadXmlFileToDataSet(string xmlFile, DataSet ds)
		{
			this.DataRow = null;

			// If the specified DataSet is nul, create a new one
			if (ds == null)
			{
				ds = this.CreateDataSet();
			}

			if (this.HookPreGetData(this.GetCurrentDataSet(), this.CurrentTableName))
			{
				// Raise the Retrieving state change event
				this.CallStateChange(mmBusinessState.Retrieving, this.TableName);

				// read the specified XML document into the DataSet
				ds.ReadXml(xmlFile);

				string TableName = ds.Tables[0].TableName;

				// Set this as the "current" DataSet
				this.SetCurrentDataSet(ds, TableName);

				// Set the current DataRow
				if (TableName == this.TableName)
				{
					this.StoreDataRow(ds);
				}

				// Set the current row to zero
				this.RowNum = 0;

				// Call Post GetData Hook
				this.HookPostGetData();

				// Raise the Retrieved state change event
				this.CallStateChange(mmBusinessState.Retrieved, TableName);
			}
		}

		/// <summary>
		/// Reads the specified XML file into a new DataSet and returns
		/// the DataSet
		/// </summary>
		/// <param name="xmlFile">Path and name of XML file to be read</param>
		/// <returns>DataSet containing the records in the XML file</returns>
		public virtual DataSet ReadXmlFileToDataSet(string xmlFile)
		{
			// Get a data access object
			mmDataAccessBase dao = this.GetDataAccessObject(this.DatabaseKey);

			// Create a new DataSet
			DataSet ds = this.CreateDataSet();

			// Read the specified XML file into the DataSet
			this.ReadXmlFileToDataSet(xmlFile, ds);

			// Return a reference to the DataSet
			return ds;
		}

		/// <summary>
		/// Registers the specified object as a child of this business object
		/// </summary>
		/// <param name="childObject">Reference to child business object</param>
		/// <param name="tableName">Table name</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void RegisterChildBizObj(mmBusinessObject childObject, string tableName)
		{
			// Store the specified table name back to the child business object
			childObject.ParentBizObjTable = tableName;
			// Add the child object to the child collection
			this.RefBizObj.Add(childObject);
			// Register this object as the parent
			childObject.RegisterParentBizObj(this);
			// Register the child business object with the StateChange and
			// Transaction StateChange handlers
			this.StateChange += 
				new mmBusinessStateChangeDelegate(childObject.StateChangeHandler);
			this.TransactionStateChange += 
				new mmTransactionStateChangeDelegate(childObject.TransactionStateChangeHandler);
		}

		/// <summary>
		/// Registers the specified object as a child of this business object.
		/// Specifies a particular parent table for which the child is notified
		/// of state change events
		/// </summary>
		/// <param name="childObject">Child object</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void RegisterChildBizObj(mmBusinessObject childObject)
		{
			this.RegisterChildBizObj(childObject, this.TableName);
		}

		/// <summary>
		/// Unregisters the specified child business object
		/// </summary>
		/// <param name="childObject">Reference to child business object</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void UnregisterChildBizObj(mmBusinessObject childObject)
		{
			// Remove the child object from the child collection
			this.RefBizObj.Remove(childObject);
			// Unregister this object as the parent business object
			childObject.UnregisterParentBizObj();
			// Unregister the child business object with the StateChange and
			// Transaction StateChange handlers
			this.StateChange -= 
				new mmBusinessStateChangeDelegate(childObject.StateChangeHandler);

			mmBusinessObject mmBizObj = (mmBusinessObject)childObject;
			this.TransactionStateChange -= 
				new mmTransactionStateChangeDelegate(mmBizObj.TransactionStateChangeHandler);
		}

		/// <summary>
		/// Unregisters the currently specified parent business object
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void UnregisterParentBizObj()
		{
			this.ParentBizObj = null;
		}

		/// <summary>
		/// Registers the specified business object as the parent business object
		/// </summary>
		/// <param name="parentObject">Reference to parent business object</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void RegisterParentBizObj(mmBusinessObject parentObject)
		{
			ParentBizObj = parentObject;
		}

		/// <summary>
		/// Returns a reference to the business rule object
		/// </summary>
		/// <returns>Reference to the business rule object</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual mmBusinessRule GetBusinessRuleObject()
		{
			return BusinessRuleObj;
		}

		/// <summary>
		/// Returns a memento object containing the business object's internal state
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual mmBusinessMemento MementoGet()
		{
			mmBusinessMemento memento = this.CreateMemento();

			memento.AddBrokenRulesToParent = this.AddBrokenRulesToParent;
			memento.AutoCancelOnCancelParent = this.AutoCancelOnParentCancel;
			memento.AutoCheckRules = this.AutoCheckRules;
			memento.AutoDeleteOnParentDeleted = this.AutoDeleteOnParentDeleted;
			memento.AutoEmptyOnParentAdded = this.AutoEmptyOnParentAdded;
			memento.AutoEndEdit = this.AutoEndEdit;
			memento.AutoIncrementCustom = this.AutoIncrementCustom;
			memento.AutoIncrementSeed = this.AutoIncrementSeed;
			memento.AutoIncrementStep = this.AutoIncrementStep;
			memento.AutoNewOnParentAdded = this.AutoNewOnParentAdded;
			memento.AutoRaiseStateChangeEvents = this.AutoRaiseStateChangeEvents;
			memento.AutoSaveOnParentSaved = this.AutoSaveOnParentSaved;
			memento.AutoUseTransactions = this.AutoUseTransactions;
			memento.CacheDataAccessObjects = this.CacheDataAccessObjects;
			memento.ClearOnFillDataSet = this.ClearOnFillDataSet;
			memento.ConcurrencySelectStatement = this.ConcurrencySelectStatement;
			memento.CurrentTableName = this.CurrentTableName;
			memento.DataAccessClass = this.DataAccessClass;
			memento.DatabaseKey = this.DatabaseKey;
			memento.DefaultCommandType = this.DefaultCommandType;
			memento.DefaultValues = this.DefaultValues;
			memento.DescriptionField = this.DescriptionField;
			memento.DescriptionFields = this.DescriptionFields;
			memento.ForeignParentKeyField = this.ForeignParentKeyField;
			memento.ImmediateDelete = this.ImmediateDelete;
			memento.ParameterTranslation = this.ParameterTranslation;
			memento.ParentBizObjTable = this.ParentBizObjTable;
			memento.ParentKeyValue = this.ParentKeyValue;
			memento.ParentKeyValues = this.ParentKeyValues;
			memento.ParentState = this.ParentState;
			memento.PhysicalDbcObjectName = this.PhysicalDbcObjectName;
			memento.PrimaryKey = this.PrimaryKey;
			memento.PrimaryKeys = this.PrimaryKeys;
			memento.RetrieveAutoIncrementPK = this.RetrieveAutoIncrementPK;
			memento.SetRequiredFieldsFromDataSet = this.SetRequiredFieldsFromDataSet;
			memento.State = this.State;
			memento.TableName = this.TableName;
			memento.UpdateSelectStatement = this.UpdateSelectStatement;
			memento.UseErrorProvider = this.UseErrorProvider;

			return memento;
		}

		/// <summary>
		/// Restores the business object's internal state from the specified business memento object
		/// </summary>
		/// <param name="memento">Business memento object</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void MementoSet(mmBusinessMemento memento)
		{
			this.AddBrokenRulesToParent = memento.AddBrokenRulesToParent;
			this.AutoCancelOnParentCancel = memento.AutoCancelOnCancelParent;
			this.AutoCheckRules = memento.AutoCheckRules;
			this.AutoDeleteOnParentDeleted = memento.AutoDeleteOnParentDeleted;
			this.AutoEmptyOnParentAdded = memento.AutoEmptyOnParentAdded;
			this.AutoEndEdit = memento.AutoEndEdit;
			this.AutoIncrementCustom = memento.AutoIncrementCustom;
			this.AutoIncrementSeed = memento.AutoIncrementSeed;
			this.AutoIncrementStep = memento.AutoIncrementStep;
			this.AutoNewOnParentAdded = memento.AutoNewOnParentAdded;
			this.AutoRaiseStateChangeEvents = memento.AutoRaiseStateChangeEvents;
			this.AutoSaveOnParentSaved = memento.AutoSaveOnParentSaved;
			this.AutoUseTransactions = memento.AutoUseTransactions;
			this.CacheDataAccessObjects = memento.CacheDataAccessObjects;
			this.ClearOnFillDataSet = memento.ClearOnFillDataSet;
			this.ConcurrencySelectStatement = memento.ConcurrencySelectStatement;
			this.CurrentTableName = memento.CurrentTableName;
			this.DataAccessClass = memento.DataAccessClass;
			this.DatabaseKey = memento.DatabaseKey;
			this.DefaultCommandType = memento.DefaultCommandType;
			this.DefaultValues = memento.DefaultValues;
			this.DescriptionField = memento.DescriptionField;
			this.DescriptionFields = memento.DescriptionFields;
			this.ForeignParentKeyField = memento.ForeignParentKeyField;
			this.ImmediateDelete = memento.ImmediateDelete;
			this.ParameterTranslation = memento.ParameterTranslation;
			this.ParentBizObjTable = memento.ParentBizObjTable;
			this.ParentKeyValue = memento.ParentKeyValue;
			this.ParentKeyValues = memento.ParentKeyValues;
			this.ParentState = memento.ParentState;
			this.PhysicalDbcObjectName = memento.PhysicalDbcObjectName;
			this.PrimaryKey = memento.PrimaryKey;
			this.PrimaryKeys = memento.PrimaryKeys;
			this.RetrieveAutoIncrementPK = memento.RetrieveAutoIncrementPK;
			this.SetRequiredFieldsFromDataSet = memento.SetRequiredFieldsFromDataSet;
			this.State = memento.State;
			this.TableName = memento.TableName;
			this.UpdateSelectStatement = memento.UpdateSelectStatement;
			this.UseErrorProvider = memento.UseErrorProvider;
		}

		/// <summary>
		/// Moves the specified row from one business object table to 
		/// this business object's specified table
		/// </summary>
		/// <param name="bizFrom">Business object moving from</param>
		/// <param name="tableFrom">Table moving from</param>
		/// <param name="tableTo">Table moving to</param>
		/// <param name="PK">Primary key of item to be moved</param>
		/// <returns>True if any items left to move, otherwise false</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool MoveRow(mmBusinessObject bizFrom, string tableFrom,
			string tableTo, object PK)
		{
			bool ItemsLeft = true;
			if (bizFrom != null)
			{
				DataSet dsFrom = bizFrom.GetCurrentDataSet();
				DataSet dsTo = this.GetCurrentDataSet();

				if (dsFrom != null && dsTo != null)
				{
					// Get a reference to the row being moved
					DataRow dr = dsFrom.Tables[tableFrom].Rows.Find(PK);

					if (dr != null)
					{
						// Add it to the specified DataSet
						dsTo.Tables[tableTo].ImportRow(dr);

						// Remove it from the Available DataSet
						dsFrom.Tables[tableFrom].Rows.Remove(dr);

						// Set the Items Left flag
						ItemsLeft = dsFrom.Tables[tableFrom].Rows.Count > 0;
					}
				}
			}
			return ItemsLeft;
		}

		/// <summary>
		/// Moves all rows from one business object table to this business object's
		/// specified table
		/// </summary>
		/// <param name="bizFrom">Business object moving from</param>
		/// <param name="tableFrom">Table moving from</param>
		/// <param name="tableTo">Table moving to</param>
		/// <returns>True if successful, otherwise false</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool MoveAllRows(mmBusinessObject bizFrom, string tableFrom,
			string tableTo)
		{
			bool Success = false;
			if (bizFrom != null)
			{
				DataSet dsFrom = bizFrom.GetCurrentDataSet();
				DataSet dsTo = this.GetCurrentDataSet();

				if (dsFrom != null && dsTo != null)
				{
					DataRow dr;
					for (int i=dsFrom.Tables[tableFrom].Rows.Count-1; i > -1; i--)
					{
						dr = dsFrom.Tables[tableFrom].Rows[i];
						dsTo.Tables[tableTo].ImportRow(dr);
						dsFrom.Tables[tableFrom].Rows.Remove(dr);
					}

					Success = true;
				}
			}
			return Success;
		}

		/// <summary>
		/// Moves the specified DataRow from the specified business object's
		/// default table to this business object's default data table
		/// </summary>
		/// <param name="bizFrom">Business object moving from</param>
		/// <param name="PK">PK of row to be moved</param>
		/// <returns>Logical true if successful, otherwise false</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool MoveRow(mmBusinessObject bizFrom, object PK)
		{
			return this.MoveRow(bizFrom, bizFrom.TableName, this.TableName, PK);
		}

		/// <summary>
		/// Raises the Navigating state change event
		/// </summary>
		/// <param name="drView"></param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void NavigatingData(DataRowView drView)
		{
			if (drView != null)
			{
				// Raise the StateChange event
				this.CallStateChange(mmBusinessState.Navigating, drView.Row.Table.ToString(), drView);
			}
		}

		/// <summary>
		/// Raises the Navigated state change event
		/// </summary>
		/// <param name="drView"></param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void NavigatedData(DataRowView drView)
		{
			if (drView != null)
			{
				this.DataRow = drView.Row;
				// Raise the StateChange event
				this.CallStateChange(mmBusinessState.Navigated, drView.Row.Table.ToString(), drView);
			}
		}

		/// <summary>
		/// Adds a new row to the specified DataView and stores the defaultValues 
		/// object in the protected DefaultValues field
		/// </summary>
		/// <param name="dv">DataView</param>
		/// <param name="defaultValues">Default values parameter object</param>
		/// <returns>New DataRow (null if unsuccessful)</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual DataRow NewRow(DataView dv, object defaultValues)
		{
			return this.NewRow(dv.Table.DataSet, dv.Table.TableName, defaultValues);
		}

		/// <summary>
		/// Adds a new row to the specified DataView 
		/// </summary>
		/// <param name="dv">DataView</param>
		/// <returns>New DataRow (null if unsuccessful)</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual DataRow NewRow(DataView dv)
		{
			return this.NewRow(dv.Table.DataSet, dv.Table.TableName, this.DefaultValues);
		}

		/// <summary>
		/// Adds a new row to the specified table of the specified DataSet and 
		/// stores the defaultValues object in the protected DefaultValues field
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="tableName">Table Name</param>
		/// <param name="defaultValues">Default values parameter object</param>
		/// <returns>New DataRow (null if unsuccessful)</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual DataRow NewRow(DataSet ds, string tableName, object defaultValues)
		{
			DataRow dr = null;
			bool result = true;
			this.DataRow = null;

			// Store default values object for reference by other methods
			this.DefaultValues = defaultValues;

			// If a current data set doesn't exist, create a new, empty DataSet
			if (ds == null)
			{
				// We're calling the data access object method directly (rather than
				// calling the business object's GetEmptyDataSet) because it allows
				// us to avoid raising the Retrieving and Retrieved state change events
				// raised by mmBusinessObject.GetEmptyDataSet
				mmDataAccessBase dao = this.GetDataAccessObject(this.DatabaseKey);

				ds = this.CreateDataSet();
				ds = (DataSet)dao.GetEmptyDataSet(ds, tableName, this.PhysicalDbcObjectName, 
					this.UpdateSelectStatement);
				this.SetCurrentDataSet(ds, tableName);
			}

			// Call HookPreAddNewRow. If returns false, exit this method
			result = this.HookPreAddNewRow(ds.Tables[tableName]);

			if (result)
			{
				// Raise the Adding state change event
				this.CallStateChange(mmBusinessState.Adding, tableName);

				// Find all columns that do not allow nulls and are not autoincrement
				// and set AllowDBNull = true. 
				foreach (DataColumn column in ds.Tables[tableName].Columns)
				{
					if (!column.AllowDBNull && !column.AutoIncrement)
					{
						column.AllowDBNull = true;
					}
				}

				string AIColumn = "";

				// Temporarily turn off auto-increment
				if (this.AutoIncrementCustom)
				{
					if (ds.Tables[tableName].ExtendedProperties.Contains(AUTOINCREMENTCOLUMN))
					{
						AIColumn = ds.Tables[tableName].ExtendedProperties[AUTOINCREMENTCOLUMN].ToString();
						ds.Tables[tableName].Columns[AIColumn].AutoIncrement = false;
					}
				}

				// Create an empty DataRow
				dr = ds.Tables[tableName].NewRow();

				// If performing custom autoincrement logic, set the value of the autoincrement column
				// and turn autoincrement back on (this setting is needed when saving data)
				if (this.AutoIncrementCustom && !mmString.Empty(AIColumn))
				{
					// Get the new increment value, and column name
					object IncrementValue = ds.Tables[tableName].ExtendedProperties[NEXTINCREMENTVALUE];

					// Put in this code to get around the not-so-great deserialization when storing 
					// session state as StateServer 
					string IncValueString = IncrementValue as String;
					if (IncValueString != null)
					{
						IncrementValue = int.Parse(IncValueString);
					} 

					// Store the new increment value in the column
					dr[AIColumn] = IncrementValue;

					// Set the new NEXTINCREMENTVALUE
					ds.Tables[tableName].ExtendedProperties[NEXTINCREMENTVALUE] =
						(int)IncrementValue + this.AutoIncrementStep;

					// Turn autoincrement back on
					ds.Tables[tableName].Columns[AIColumn].AutoIncrement = true;
				}

				// Pass the new data row to the Set Default Values hook
				this.HookSetDefaultValues(dr);

				// Pass the new data row to the hook method
				this.HookPostAddNewRow(dr);

				// Add the new DataRow to the DataSet
				ds.Tables[tableName].Rows.Add(dr);

				// Store the new DataRow in the DataRow property
				if (tableName == this.TableName)
				{
					this.DataRow = dr;
				}

				// Raise the Added state change event
				this.CallStateChange(mmBusinessState.Added, tableName, dr);
			}

			return dr;
		}

		/// <summary>
		/// Adds a new row to the specified table of the specified DataSet
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="tableName">Table name</param>
		/// <returns>New DataRow (null if unsuccessful)</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual DataRow NewRow(DataSet ds, string tableName)
		{
			return this.NewRow(ds, tableName, this.DefaultValues);
		}

		/// <summary>
		/// Adds a new row to the specified table of the current DataSet and stores
		/// the default values object on the protected DefaultValues field 
		/// </summary>
		/// <param name="tableName">Table name</param>
		/// <param name="defaultValues">Default values parameter object</param>
		/// <returns>New DataRow (null if unsuccessful)</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual DataRow NewRow(string tableName, object defaultValues)
		{
			return this.NewRow(this.GetCurrentDataSet(), tableName, defaultValues);
		}

		/// <summary>
		/// Adds a new row to the specified table of the current DataSet
		/// </summary>
		/// <param name="tableName">Table Name</param>
		/// <returns>New DataRow (null if unsuccessful)</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual DataRow NewRow(string tableName)
		{
			return this.NewRow(this.GetCurrentDataSet(), tableName);
		}

		/// <summary>
		/// Adds a new row to the specified table and stores the default
		/// values object on the protected DefaultValues field 
		/// </summary>
		/// <param name="defaultValues">Default values parameter object</param>
		/// <returns>New DataRow (null if unsuccessful)</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual DataRow NewRow(object defaultValues)
		{
			return this.NewRow(this.TableName, defaultValues);
		}

		/// <summary>
		/// Adds a new row to the default table of the current DataSet
		/// </summary>
		/// <returns>New DataRow (null if unsuccessful)</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual DataRow NewRow()
		{
			return this.NewRow(this.TableName);
		}

		/// <summary>
		/// If a parent object exists, pass it the AddBrokenRule message
		/// </summary>
		/// <param name="brokenRule">Broken rule string</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void OnBrokenRuleAdd(string brokenRule)
		{
			if (ParentBizObj != null && this.AddBrokenRulesToParent)
			{
				mmBusinessRule BizRuleObj = ParentBizObj.GetBusinessRuleObject();
				BizRuleObj.AddBrokenRule(brokenRule);
			}
		}

		/// <summary>
		/// If a parent object exists, pass it the ClearRule message
		/// </summary>
		/// <param name="brokenRule">Broken rule string</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void OnBrokenRuleClear(string brokenRule)
		{
			if (ParentBizObj != null && this.AddBrokenRulesToParent)
			{
				mmBusinessRule BizRuleObj = ParentBizObj.GetBusinessRuleObject();
				BizRuleObj.ClearRule(brokenRule);
			}
		}

		/// <summary>
		/// Raise the state change event
		/// If a parent business object exists, pass it the Error Provider Broken Rule arg
		/// </summary>
		/// <param name="arg">Error Provider Broken Rule Arg</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void OnErrorProviderBrokenRuleAdd(mmErrorProviderArgs arg)
		{
			// Raise the state change event
			this.OnStateChange(mmBusinessState.BrokenRulesWarnings, null, arg, null);

			if (ParentBizObj != null && this.AddBrokenRulesToParent)
			{
				mmBusinessRule BizRuleObj = ParentBizObj.GetBusinessRuleObject();
				BizRuleObj.AddErrorProviderBrokenRule(arg);
			}
		}

		/// <summary>
		/// Raise the state change event
		/// If a parent business object exists, pass it the Error Provider Warning arg
		/// </summary>
		/// <param name="arg"></param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void OnErrorProviderWarningAdd(mmErrorProviderArgs arg)
		{
			// Raise the state change event
			this.OnStateChange(mmBusinessState.BrokenRulesWarnings, null, arg, null);

			if (ParentBizObj != null && this.AddBrokenRulesToParent)
			{
				mmBusinessRule BizRuleObj = ParentBizObj.GetBusinessRuleObject();
				BizRuleObj.AddErrorProviderWarning(arg);
			}
		}

		/// <summary>
		/// If a parent object exists, pass it the AddWarning message
		/// </summary>
		/// <param name="warning">Warning string</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void OnWarningAdd(string warning)
		{
			if (ParentBizObj != null)
			{
				mmBusinessRule BizRuleObj = ParentBizObj.GetBusinessRuleObject();
				BizRuleObj.AddWarning(warning);
			}
		}
		
		/// <summary>
		/// If a parent object exists, pass it the ClearWarning message
		/// </summary>
		/// <param name="warning">Warning string</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void OnWarningClear(string warning)
		{
			if (ParentBizObj != null)
			{
				mmBusinessRule BizRuleObj = ParentBizObj.GetBusinessRuleObject();
				BizRuleObj.ClearWarning(warning);
			}
		}

		/// <summary>
		/// Populates the specified table and key field in the current DataSet
		/// with the the specified value
		/// </summary>
		/// <param name="keyField">Key field</param>
		/// <param name="keyValue">Key value</param>
		/// <param name="tableName"></param>
		protected virtual void PopulateKeyField(string keyField, object keyValue, 
			string tableName)
		{
			DataTable dt = this.GetCurrentDataSet().Tables[tableName];
			foreach (DataRow row in dt.Rows)
			{
				if (row.RowState != DataRowState.Deleted)
				{
					if (row[keyField] == System.DBNull.Value || !keyValue.Equals(row[keyField]))
					{
						row[keyField] = keyValue;
					}
				}
			}
		}

		/// <summary>
		/// Populates the default table and specified key field in the current DataSet
		/// with the specified value
		/// </summary>
		/// <param name="keyField">Key field</param>
		/// <param name="keyValue">Key value</param>
		protected virtual void PopulateKeyField(string keyField, object keyValue)
		{
			this.PopulateKeyField(keyField, keyValue, this.TableName);
		}

		/// <summary>
		/// Populates the foreign key parent field (if defined) with the
		/// parent's current primary key value
		/// </summary>
		protected virtual void PopulateForeignParentKeyField()
		{
			if (this.ForeignParentKeyField != null && this.ParentKeyValue != null)
			{
				this.PopulateKeyField(this.ForeignParentKeyField, this.ParentKeyValue);
			}
		}

		/// <summary>
		/// Checks the business object's rules
		/// </summary>
		/// <param name="businessObject">Business object</param>
		/// <param name="ds">DataSet</param>
		/// <param name="tableName">DataTable name</param>
		/// <returns>mmSaveDataResult enumerated value</returns>
		protected virtual mmSaveDataResult CheckRules(mmBusinessObject businessObject, DataSet ds, string tableName)
		{
			mmSaveDataResult Result = mmSaveDataResult.RulesPassed;

			if (businessObject.AutoCheckRules)
			{
				if (businessObject.BusinessRuleObj != null)
				{
					// Store the current row number and row on the business rule object
					businessObject.BusinessRuleObj.CurrentRow = businessObject.RowNum;
					businessObject.BusinessRuleObj.DataRow = businessObject.DataRow;

					// Check the business rules
					Result = businessObject.BusinessRuleObj.CheckRules(ds, tableName, 
						businessObject.UseErrorProvider);
				}

				// Check any child object business rules
				mmSaveDataResult ChildResult;

				foreach (mmBusinessObject ChildBizObj in businessObject.RefBizObj)
				{
					if (ChildBizObj.AutoSaveOnParentSaved && ChildBizObj.GetCurrentDataSet() != null)
					{
						// Call Save PreProcess method on the child object. This ensures any
						// EndEdit or setting of parent foreign keys is done before checking rules
						if (ChildBizObj.PreSaveProcessing(ChildBizObj.GetCurrentDataSet(), ChildBizObj.TableName))
						{
							// Make a recursive call to check the child object's business rules
							ChildResult = this.CheckRules(ChildBizObj, ChildBizObj.GetCurrentDataSet(),
								ChildBizObj.TableName);

							// Set RulesChecked flag
							ChildBizObj.RulesCheckedByParent = true;

							// Store the ChildResult in the overall Result variable if the severity is
							// greater than the current setting
							if (ChildResult == mmSaveDataResult.RulesBroken)
							{
								// Clear the RulesChecked flag since the rules failed
								ChildBizObj.RulesCheckedByParent = false;
								Result = ChildResult;
							}
							else if (ChildResult == mmSaveDataResult.RuleWarnings && Result == mmSaveDataResult.RulesPassed)
							{
								Result = ChildResult;
							}
						}
						else
						{
							Result = mmSaveDataResult.SaveCanceled;
							break; // Bail out if the child object's PreSaveProcessing returns false
						}
					}
				}
			}
			return Result;
		}

		/// <summary>
		/// Performs PreSave processing such as EndEdit, populating foreign parent key fields,
		/// raising the PreSaving StateChange event, and calling the HookPreSave()  method
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="tableName">DataTable name</param>
		/// <returns>True if save should continue, otherwise false</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool PreSaveProcessing(DataSet ds, string tableName)
		{
			bool Result = true;

			if (!this.RulesCheckedByParent)
			{
				// End any pending edits
				this.EndEdit(ds, tableName);

				// Clear any rules--they can get set when errors occur 
				// while binding back from listener controls
				if (this.BusinessRuleObj != null)
				{
					this.BusinessRuleObj.ClearAll();
				}

				// Raise the PreSaving event
				this.CallStateChange(mmBusinessState.PreSaving, tableName);

				// Call the PreSave Hook
				Result = this.HookPreSave(ds.Tables[tableName]);

				// If any rules were broken when binding back, return false
				if (this.BusinessRuleObj != null && 
					(this.BusinessRuleObj.ErrorProviderBrokenRuleCount + 
					this.BusinessRuleObj.BrokenRuleCount > 0))
				{
					Result = false;
				}
			}
			return Result;
		}

		/// <summary>
		/// (1) Saves the DataSet's specified table to the specified database
		/// using the specified data adapter
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="tableName">Table name</param>
		/// <param name="databaseKey">Database key</param>
		/// <param name="dbAdapter">Data adapter</param>
		/// <returns>mmSaveDataResult enum value</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual mmSaveDataResult SaveDataSet(DataSet ds, string tableName, string databaseKey, 
			IDbDataAdapter dbAdapter)
		{
			mmSaveDataResult Result = mmSaveDataResult.RulesPassed;
			bool TransactionStarted = false;

			// If the DataSet being saved is not the current DataSet, make it so!
			if (ds != this.GetCurrentDataSet())
			{
				this.SetCurrentDataSet(ds, tableName, false, false);
			}

			// If there is no associated data, bail out!
			if (ds != null)
			{
				DataTable dt = ds.Tables[tableName];

				if (dt == null || ds.Tables[tableName].Rows.Count == 0)
				{
					return mmSaveDataResult.SaveCanceled;
				}
			}
			else
			{
				return mmSaveDataResult.SaveCanceled;
			}

			// If a parent foreign key is specified, save the last
			// foreign key value into the specified field
			this.PopulateForeignParentKeyField();

			// Call the PreSave hook and bail out if false is returned
			if (this.PreSaveProcessing(ds, tableName))
			{
				if (!this.RulesCheckedByParent)
				{
					Result = this.CheckRules(this, ds, tableName);
				}
				else
				{
					// Reset the "rules checked" flag
					this.RulesCheckedByParent = false;
				}

				// Save data only if no business rules were broken
				if (Result != mmSaveDataResult.RulesBroken && Result != mmSaveDataResult.SaveCanceled)
				{
					// Raise the Saving state change event
					this.CallStateChange(mmBusinessState.Saving, tableName);

					// Get a data access object
					mmDataAccessBase dao = this.GetDataAccessObject(databaseKey);

					// If specified to do so, begin a transaction
					if (this.AutoUseTransactions)
					{
						// If a transaction is already in progress, don't start a new one!
						if (!dao.IsTransactionInProgress())
						{
							this.TransactionBegin();
							TransactionStarted = true;
						}
					}

					// Don't bother saving unless the DataSet has changes.
					// If there are child objects, continue with save
					if (ds.HasChanges())
					{
						this.RowsUpdatedOnSave = 0;
						string PK = null;

						// Get the auto increment field if specified to retrieve it
						if (this.RetrieveAutoIncrementPK)
						{
							if (this.PrimaryKey != null)
							{
								PK = this.PrimaryKey;
							}
							else if(this.PrimaryKeys != null)
							{
								PK = this.PrimaryKeys[0];
							}
						}
		
						// Only use the RetrieveAutoIncrementPK value if saving
						// the business object's primary table
						bool RetrieveAutoIncrement = tableName.ToLower() == this.TableName.ToLower()
							? this.RetrieveAutoIncrementPK
							: false;

						// Set the UpdateSelectStatement
						dao.UpdateSelectStatement = 
							tableName.ToLower() == this.TableName.ToLower()
							? this.UpdateSelectStatement
							: "";

						// Save the DataSet, and if specified to do so, retrieve any auto-increment PK value
						try
						{

							this.RowsUpdatedOnSave = dao.SaveDataSet(ds, 
								tableName, 
								PK, 
								RetrieveAutoIncrement,
								dbAdapter);
						}
						catch (Exception e)
						{
							// Handle the exception
							this.HandleException(e);

							// Set the method return value
							Result = mmSaveDataResult.Exception;

							// If exception not handled, rethrow it
							if (!this.ExceptionHandled)
							{
								if (TransactionStarted)
								{
									this.TransactionRollback();
									throw;
								}

							}
						}

						// If creating custom auto-increment values, reset the "next" increment number
						if (this.AutoIncrementCustom && this.RetrieveAutoIncrementPK)
						{
							this.ResetAutoIncrement(ds, tableName);
						}
					}

					// Continue processing only if no errors occurred
					if (Result != mmSaveDataResult.Exception)
					{
						// Call the post-save hook
						this.HookPostSave(ds.Tables[tableName]);

						// Raise the Saved state change event
						this.CallStateChange(mmBusinessState.Saved, tableName);

						mmSaveDataResult ChildResult = mmSaveDataResult.RulesPassed;

						// Check if there are any child business objects with
						// AutoSaveOnParentSaved = true. If so, call their SaveDataSet method
						foreach (mmBusinessObject ChildBizObj in this.RefBizObj)
						{
							if (ChildBizObj.AutoSaveOnParentSaved)
							{
								ChildResult = ChildBizObj.SaveDataSet();

								// Bail out if the child business object has an exception
								if (ChildResult == mmSaveDataResult.Exception)
								{
									// Save the child result in this object's result
									Result = ChildResult;

									// Save the child's exception in this object's Exception property
									// and save a reference to the child object
									this.Exception = ChildBizObj.Exception;
									this.ExceptionObject = ChildBizObj;
									this.ConcurrencyExceptionMsg = 
										ChildBizObj.ConcurrencyExceptionMsg;
									break;
								}
							}
						}
					}
				}
			}
			else
			{
				if (this.BusinessRuleObj.ErrorProviderBrokenRuleCount + 
					this.BusinessRuleObj.BrokenRuleCount > 0)
				{
					Result = mmSaveDataResult.RulesBroken;
				}
				else
				{
					Result = mmSaveDataResult.SaveCanceled;
				}
			}

			// If this object started the transaction, commit or roll back
			if (TransactionStarted)
			{
				// Roll back the transaction if any rules were broken
				// or exceptions were encountered
				if (Result == mmSaveDataResult.RulesBroken ||
					Result == mmSaveDataResult.Exception)
				{
					this.TransactionRollback();
				}
					// Otherwise, commit the transaction
				else
				{
					this.TransactionCommit();
				}
			}

			return Result;
		}

		/// <summary>
		/// (2) Saves the DataSet's specified table to the default database
		/// using the specified data adapter
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="tableName">Table Name</param>
		/// <param name="dbAdapter">Data adapter</param>
		/// <returns>mmSaveDataResult enum value</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual mmSaveDataResult SaveDataSet(DataSet ds, string tableName,
			IDbDataAdapter dbAdapter)
		{
			return this.SaveDataSet(ds, tableName, this.DatabaseKey, 
				dbAdapter);
		}

		/// <summary>
		/// (3) Saves the DataSet's default table to the default database
		/// using the specified data adapter
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="dbAdapter">Data adapter</param>
        /// <returns>mmSaveDataResult enum value</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual mmSaveDataResult SaveDataSet(DataSet ds, IDbDataAdapter dbAdapter)
		{
			return this.SaveDataSet(ds, this.TableName, dbAdapter);
		}

		/// <summary>
		/// (4) Saves the current DataSet's default table to the default database 
		/// using the specified data adapter
		/// </summary>
		/// <param name="dbAdapter">Data adapter</param>
		/// <returns>mmSaveDataResult enum value</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual mmSaveDataResult SaveDataSet(IDbDataAdapter dbAdapter)
		{
			return this.SaveDataSet(this.GetCurrentDataSet(), dbAdapter);
		}

		/// <summary>
		/// (5) Saves the DataSet's specified table to the specified database
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="tableName">Table name</param>
		/// <param name="databaseKey">Database key</param>
		/// <returns>mmSaveDataResult enum value</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual mmSaveDataResult SaveDataSet(DataSet ds, string tableName, string databaseKey)
		{
			return this.SaveDataSet(ds, tableName, databaseKey, (IDbDataAdapter)null);
		}

		/// <summary>
		/// (6) Saves the DataSet's specified table to the default database
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="tableName">Table name</param>
		/// <returns>mmSaveDataResult enum value</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual mmSaveDataResult SaveDataSet(DataSet ds, string tableName)
		{
			return this.SaveDataSet(ds, tableName, this.DatabaseKey);
		}

		/// <summary>
		/// (7) Saves the DataSet's default table to the default database
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <returns>mmSaveDataResult enum value</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual mmSaveDataResult SaveDataSet(DataSet ds)
		{
			return this.SaveDataSet(ds, this.TableName);
		}

		/// <summary>
		/// (9) Saves the current DataSet's specified table to the default database
		/// </summary>
		/// <param name="tableName">Table Name</param>
		/// <returns>mmSaveDataResult enum value</returns>
		/// <param name="currentRow">Current row</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual mmSaveDataResult SaveDataSet(string tableName, int currentRow)
		{
			// Save the specified row number
			this.RowNum = currentRow;
			// Get the corresponding data row
			DataSet ds = this.GetCurrentDataSet();
			this.DataRow = ds.Tables[tableName].Rows[currentRow];
			// Save the data
			mmSaveDataResult result = this.SaveDataSet(ds, tableName);
			// Reset the row number to zero
			this.RowNum = 0;
			// Return the result
			return result;
		}

		/// <summary>
		/// (9) Saves the current DataSet's specified table to the default database
		/// </summary>
		/// <param name="tableName">Table Name</param>
		/// <returns>mmSaveDataResult enum value</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual mmSaveDataResult SaveDataSet(string tableName)
		{
			return this.SaveDataSet(this.GetCurrentDataSet(), tableName);
		}

		/// <summary>
		/// (10) Saves the current DataSet's default table to the default database
		/// </summary>
		/// <returns>mmSaveDataResult enum value</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual mmSaveDataResult SaveDataSet()
		{
			return this.SaveDataSet(this.GetCurrentDataSet());
		}

		/// <summary>
		/// (1) Saves the DataView to the specified database
		/// </summary>
		/// <param name="dv">DataView</param>
		/// <param name="databaseKey">Database key</param>
		/// <returns>mmSaveDataResult value</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual mmSaveDataResult SaveDataView(DataView dv, string databaseKey)
		{
			// End any edits on the DataView
			this.EndEdit(dv);

			// Set the DataView field of the business rule object. Used for
			// displaying error provider-style broken rules
			this.BusinessRuleObj.DataView = dv;

			// Save the data
			mmSaveDataResult result = this.SaveDataSet(dv.Table.DataSet, dv.Table.TableName, databaseKey);
			
			// Reset the DataView property
			this.BusinessRuleObj.DataView = null;

			return result;
		}

		/// <summary>
		/// (2) Saves the DataView to the default database
		/// </summary>
		/// <param name="dv">DataView</param>
		/// <returns>mmSaveDataResult value</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual mmSaveDataResult SaveDataView(DataView dv)
		{
			return this.SaveDataView(dv, this.DatabaseKey);
		}

		/// <summary>
		/// (3) Saves the DataView to the default database, after first setting
		/// the current row number
		/// </summary>
		/// <param name="dv">DataView</param>
		/// <param name="currentRow"></param>
		/// <returns>mmSaveDataResult</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual mmSaveDataResult SaveDataView(DataView dv, int currentRow)
		{
			// Save the specified row number
			this.RowNum = currentRow;
			// Get the corresponding data row, and end any edits
			this.DataRow = dv[currentRow].Row;
			// Save the data
			mmSaveDataResult Result = this.SaveDataView(dv);
			// Reset the row number to zero
			this.RowNum = 0;
			// Return the result
			return Result;
		}

		/// <summary>
		/// Saves the row stored in the  DataRow property (and any other rows
		/// with pending changes in the current DataSet's default table)
		/// </summary>
		/// <returns>mmSaveDataResult enumeration value</returns>
		public virtual mmSaveDataResult SaveRow()
		{
			mmSaveDataResult result;
			if (this.DataRow != null)
			{
				result = this.SaveDataSet(this.TableName);
			}
			else
			{
				result = mmSaveDataResult.SaveCanceled;
			}
			return result;
		}

		/// <summary>
		/// Set the auto-increment values for the specified DataSet table
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="tableName">Table Name</param>
		protected virtual void SetAutoIncrement(DataSet ds, string tableName)
		{
			if (tableName == this.TableName)
			{
				if (this.PrimaryKey != null)
				{
					DataColumn column = ds.Tables[tableName].Columns[this.PrimaryKey];
					if (column != null)
					{
						this.SetAutoIncrement(column);
					}
				}
			}
			else
			{
				// Search for an auto-increment column and set its seed
				// and step values if found
				foreach (DataColumn column in ds.Tables[tableName].Columns)
				{
					if (column.AutoIncrement)
					{
						this.SetAutoIncrement(column);
						break;
					}
				}
			}
		}

		/// <summary>
		/// Sets the autoincrement seed to zero and step to the specified values
		/// </summary>
		/// <param name="column">Column</param>
		protected virtual void SetAutoIncrement(DataColumn column)
		{
			// Remove any previous custom autoincrement information
			if (column.Table.ExtendedProperties.Contains(AUTOINCREMENTCOLUMN))
			{
				column.Table.ExtendedProperties.Remove(AUTOINCREMENTCOLUMN);
				column.Table.ExtendedProperties.Remove(NEXTINCREMENTVALUE);
			}

			// Unfortunately, if the table already contains rows, we have to perform our own
			// autoincrement logic. This is because ADO.NET is overly helpful...when it
			// generates the autoincrement value, it determines the highest value of the
			// autoincrement column currently in the table, and (because the step is -1),
			// substracts one from it!
			column.Table.ExtendedProperties.Add(AUTOINCREMENTCOLUMN, column.ColumnName);
			column.Table.ExtendedProperties.Add(NEXTINCREMENTVALUE, this.AutoIncrementSeed);
		}

		/// <summary>
		/// Stores the first DataRow in the default table to the 
		/// DataRow property of the business object
		/// </summary>
		/// <param name="ds">DataSet containing DataRow to be stored</param>
		/// <returns>True if successful, otherwise false</returns>
		protected bool StoreDataRow(DataSet ds)
		{
			bool result = false;
			if (ds.Tables[this.TableName].Rows.Count != 0)
			{
				this.DataRow = ds.Tables[this.TableName].Rows[0];
				result = true;
			}
			else
			{
				this.DataRow = null;
			}
			return result;
		}

		/// <summary>
		/// Stores the first DataRow of the specified view to the 
		/// DataRow property of the business object
		/// </summary>
		/// <param name="dv">DataView</param>
		/// <returns>True if successful, otherwise false</returns>
		protected bool StoreDataRow(DataView dv)
		{
			bool result = false;
			if (dv == null || dv.Count == 0)
			{
				this.DataRow = null;
			}
			else
			{
				this.DataRow = dv[0].Row;
				result = true;
			}
			return result;
		}

		/// <summary>
		/// StateChange event
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual event mmBusinessStateChangeDelegate StateChange;

		/// <summary>
		/// Raises the StateChange event
		/// </summary>
		/// <param name="bizState">mmBusinessState enum value</param>
		/// <param name="tableName">Table Name</param>
		/// <param name="primaryKeyValue">Primary key value</param>
		/// <param name="primaryKeyValues">Primary key values</param>
		protected virtual void OnStateChange(mmBusinessState bizState, string tableName, 
			object primaryKeyValue, object[] primaryKeyValues)
		{
			this.State = bizState;

			if (this.AutoRaiseStateChangeEvents)
			{
				// Copy the multicast delegate to a local variable for thread safety
				mmBusinessStateChangeDelegate ev = this.StateChange;

				// Raise the StateChange event
				if (ev != null)
				{
					ev(this, new mmBusinessStateChangeEventArgs(bizState, tableName,
						primaryKeyValue, primaryKeyValues));
				}

			}
		}

		/// <summary>
		/// Business State Change event handler. This handler allows a 
		/// business object to handle events raised by other business objects
		/// </summary>
		/// <param name="bizObj">Business object event source</param>
		/// <param name="e">mmBusinessStateChangeEventArgs</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void StateChangeHandler(mmBaseBusinessObject bizObj, mmBusinessStateChangeEventArgs e)
		{
			mmBusinessObject BusinessObject = bizObj as mmBusinessObject;
			if (BusinessObject != null)
			{
				// Check if a specific parent table has been specified
				if (this.ParentBizObjTable == "" ||
					mmString.Empty(e.TableName) ||
					(this.ParentBizObjTable.ToLower() == e.TableName.ToLower()))
				{
					switch (e.State)
					{
						case mmBusinessState.Adding:
						{
							this.HookParentAdding(BusinessObject, e);
							goto default;
						}
						case mmBusinessState.Added:
						{
							// Automatically call GetEmptyDataSet if specified to do so
							if (this.AutoEmptyOnParentAdded)
							{
								this.GetEmptyDataSet();
							}
								// Automatically call the NewRow method if specified to do so
							else if (this.AutoNewOnParentAdded)
							{
								this.GetEmptyDataSet();
								this.NewRow();
							}
							this.HookParentAdded(BusinessObject, e);
							goto default;
						}
						case mmBusinessState.Canceling:
						{
							this.HookParentCanceling(BusinessObject, e);
							goto default;
						}
						case mmBusinessState.Canceled:
						{
							// Automatically call the Cancel method if specified to do so
							if (this.AutoCancelOnParentCancel)
							{
								this.Cancel();
							}
							this.HookParentCanceled(BusinessObject, e);
							goto default;
						}
						case mmBusinessState.Deleting:
						{
							this.HookParentDeleting(BusinessObject, e);
							// Automatically call the Delete method if specified to do so
							if (this.AutoDeleteOnParentDeleted)
							{
								this.DeleteAll();
							}
							goto default;
						}				
						case mmBusinessState.Deleted:
						{
							this.HookParentDeleted(BusinessObject, e);
							goto default;
						}
						case mmBusinessState.Navigating :
						{
							this.HookParentNavigating(BusinessObject, e);
							goto default;
						}
						case mmBusinessState.Navigated :
						{
							this.HookParentNavigated(BusinessObject, e);
							goto default;
						}
						case mmBusinessState.Retrieving :
						{
							this.HookParentRetrieving(BusinessObject, e);
							goto default;
						}
						case mmBusinessState.Retrieved :
						{
							this.HookParentRetrieved(BusinessObject, e);
							goto default;
						}
						case mmBusinessState.PreSaving:
						{
							this.HookParentPreSaving(BusinessObject, e);
							goto default;
						}
						case mmBusinessState.Saving :
						{
							this.HookParentSaving(BusinessObject, e);
							goto default;
						}
						case mmBusinessState.Saved :
						{
							this.HookParentSaved(BusinessObject, e);
							goto default;
						}
						case mmBusinessState.Bind:
						case mmBusinessState.BrokenRulesWarnings:
							break;
                        case mmBusinessState.UpdatingPKValue:
                            {
                                this.HookParentUpdatingPKValue(BusinessObject, e);
                                break;
                            }
                        case mmBusinessState.UpdatedPKValue:
                            {
                                this.HookParentUpdatedPKValue(BusinessObject, e);
                                break;
                            }
						default:
							// Save the Parent business object's primary key values and state
							this.ParentKeyValue = e.PrimaryKeyValue;
							this.ParentKeyValues = e.PrimaryKeyValues;
							this.ParentState = e.State;
							break;
					}
				}
			}
		}

		/// <summary>
		/// Transaction state change event
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public event mmTransactionStateChangeDelegate TransactionStateChange;

		/// <summary>
		/// Raises the TransactionStateChange event
		/// </summary>
		/// <param name="trxState">mmTransactionState enum value</param>
		/// <param name="databaseKey">Database key</param>
		/// <param name="conn">Connection</param>
		/// <param name="trx">Transaction</param>
		protected virtual void OnTransactionStateChange(mmTransactionState trxState, 
			string databaseKey, IDbConnection conn,	IDbTransaction trx)
		{
			// Copy the multicast delegate to a local variable for thread safety
			mmTransactionStateChangeDelegate ev = this.TransactionStateChange;

			// Raise the TransactionStateChange event
			if (ev != null)
			{
				ev(this, 
					new mmTransactionStateChangeEventArgs(trxState, databaseKey, conn, trx));
			}
		}

		/// <summary>
		/// Business Tranaction State Change event handler. This handler alows a
		/// business object to handle transactional eents raised by other business objects
		/// </summary>
		/// <param name="bizObj">Business object event source</param>
		/// <param name="e">mmTransactionStateChangeEventArgs</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void TransactionStateChangeHandler(mmBusinessObject bizObj,
			mmTransactionStateChangeEventArgs e)
		{
			switch (e.State)
			{
				case mmTransactionState.Begin:
				{
					this.HookParentTransactionBegin(bizObj, e);
					break;
				}
				case mmTransactionState.Commit:
				{
					this.HookParentTransactionCommit(bizObj, e);
					break;
				}
				case mmTransactionState.Rollback:
				{
					this.HookParentTransactionRollback(bizObj, e);
					break;
				}
			}
		}
		
		/// <summary>
		/// Begins a new transaction on the specified database
		/// </summary>
		/// <param name="databaseKey">Database key</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public IDbTransaction TransactionBegin(string databaseKey)
		{
			IDbConnection conn;
			IDbTransaction trx;
			bool connOpen;

			// Tell the data access object to begin a transaction
			mmDataAccessBase dao = this.GetDataAccessObject(databaseKey);
			dao.TransactionBegin(out conn, out trx, out connOpen);

			// Raise the TransactionStateChange event
			this.OnTransactionStateChange(mmTransactionState.Begin, databaseKey, 
				conn, trx);

			return trx;
		}

		/// <summary>
		/// Begins a transaction on the default database
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public IDbTransaction TransactionBegin()
		{
			return this.TransactionBegin(this.DatabaseKey);
		}

		/// <summary>
		/// Commits the current transaction on the specified database
		/// </summary>
		/// <param name="databaseKey"></param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public void TransactionCommit(string databaseKey)
		{
			mmDataAccessBase dao = this.GetDataAccessObject(databaseKey);
			dao.TransactionCommit();

			// Raise the TransactionStateChange event
			this.OnTransactionStateChange(mmTransactionState.Commit, databaseKey, null, null);
		}

		/// <summary>
		/// Commits the current transaction on the default database
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public void TransactionCommit()
		{
			this.TransactionCommit(this.DatabaseKey);
		}

		/// <summary>
		/// Rolls back the current transaction on the specified database
		/// </summary>
		/// <param name="databaseKey"></param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public void TransactionRollback(string databaseKey)
		{
			mmDataAccessBase dao = this.GetDataAccessObject(databaseKey);
			dao.TransactionRollback();

			// Raise the TransactionStateChange event
			this.OnTransactionStateChange(mmTransactionState.Rollback, databaseKey, null, null);
		}

		/// <summary>
		/// Rolls back the current transaction on the default database
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public void TransactionRollback()
		{
			this.TransactionRollback(this.DatabaseKey);
		}

		/// <summary>
		/// Updates the database from the specified DataSet as follows:
		/// 1. The specified DataTable is copied to a temporary "Current Value" table
		/// 2. The specified DataTable's original command is re-executed and the result
		///    is stored in the business object's default table as "Original" values
		/// 3. The Original Value table is scanned, and any records not found in the
		///    Current Value table are deleted from the Original Value table
		/// 4. The Current Value table is scanned, and any records not found in the
		///    Original Value table are imported into the Original Value table. 
		///    If the row does exist, any changes values are copied from the Current
		///    Table to the Original Value table
		/// </summary>
		/// <param name="ds">DataSet</param>
		/// <param name="tableName">TableName</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void UpdateFromDataSet(DataSet ds, string tableName)
		{
			// Use the UpdateSelectStatement if available
			if (!mmString.Empty(this.UpdateSelectStatement))
			{
				mmDataAccessBase dao = this.GetDataAccessObject();

				ds.Tables[tableName].ExtendedProperties.Add("UpdateSelectStatement",
					dao.CreateCommand(this.UpdateSelectStatement));
			}

			// Make sure the DataSet and business object are set up properly
			if (!ds.Tables[tableName].ExtendedProperties.Contains("SelectCommand"))
			{
				throw new Exception("Cannot update from a DataSet that contains no Select Command");
			}
			if (mmString.Empty(this.PrimaryKey) 
				&& this.PrimaryKeys != null 
				&& this.PrimaryKeys.Length == 0)
			{
				throw new Exception("Cannot update from a DataSet that has no specified primary keys");
			}

			// Copy the current values to a temporary Update Table
			DataTable CurrentValueTable = ds.Tables[TableName].Copy();
			
			// Re-execute the original command
			IDbCommand Command = (IDbCommand)ds.Tables[tableName].ExtendedProperties["SelectCommand"];
			this.FillDataSet(ds, Command, tableName);
			
			// Scan through the "original" values DataTable searching for
			// each row in the Update Table. If the row doesn't exit, delete it
			// from the original value DataSet
			foreach(DataRow row in ds.Tables[tableName].Rows)
			{
				DataRow FoundRow = null;
				if (!mmString.Empty(this.PrimaryKey))
				{
					FoundRow = CurrentValueTable.Rows.Find(this.GetPrimaryKeyValue(row));
					if (FoundRow == null)
					{
						// The row doesn't exist. Delete if from the original value DataSet
						this.Delete(this.GetPrimaryKeyValue(row));
					}
				}
				else
				{
					FoundRow = CurrentValueTable.Rows.Find(this.GetPrimaryKeyValues(row));
					if (FoundRow == null)
					{
						// The row doesn't exist. Delete if from the original value DataSet
						this.Delete(this.GetPrimaryKeyValues(row));
					}
				}
			}

			// Scan through the current value DataSet. Search for each
			// row in the "original" DataSet. If it doesn't exist, 
			// import the row. If it does exist, skip to the next row
			foreach(DataRow row in CurrentValueTable.Rows)
			{
				DataRow FoundRow = null;
				if (!mmString.Empty(this.PrimaryKey))
				{
					FoundRow = ds.Tables[tableName].Rows.Find(this.GetPrimaryKeyValue(row));
					if (FoundRow == null)
					{
						// The row doesn't exist. Import it
						ds.Tables[tableName].ImportRow(row);
					}
				}
				else
				{
					FoundRow = ds.Tables[tableName].Rows.Find(this.GetPrimaryKeyValues(row));
					if (FoundRow == null)
					{
						// The row doesn't exist. Import it
						ds.Tables[tableName].ImportRow(row);
					}
				}
				// The row does exit. Copy any changed values to the Current Table
				if (FoundRow != null)
				{
					for(int i=0; i<row.Table.Columns.Count; i++)
					{
						if (FoundRow[i] != row[i])
						{
							FoundRow[i] = row[i];
						}
					}
				}
			}
			// Save the updated DataSet
			this.SaveDataSet(ds, tableName);
		}

		/// <summary>
		/// Updates the Database from the specified DataSet and default table name
		/// </summary>
		/// <param name="ds">DataSet</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void UpdateFromDataSet(DataSet ds)
		{
			this.UpdateFromDataSet(ds, ds.Tables[0].TableName);
		}

		/// <summary>
		/// Updates the Database from the current DataSet and default table name
		/// </summary>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
		public virtual void UpdateFromDataSet()
		{
			this.UpdateFromDataSet(this.GetCurrentDataSet(), this.TableName);
		}

		/// <summary>
		/// Parent Adding hook method
		/// </summary>
		/// <param name="bizObj">Parent business object reference</param>
		/// <param name="e">mmBusinessStateChangeEventArgs</param>
		protected virtual void HookParentAdding(mmBusinessObject bizObj, mmBusinessStateChangeEventArgs e)
		{
		}

		/// <summary>
		/// Parent Added hook method
		/// </summary>
		/// <param name="bizObj">Parent business object reference</param>
		/// <param name="e">mmBusinessStateChangeEventArgs</param>
		protected virtual void HookParentAdded(mmBusinessObject bizObj, mmBusinessStateChangeEventArgs e)
		{
		}

		/// <summary>
		/// Parent Canceling hook method
		/// </summary>
		/// <param name="bizObj">Parent business object reference</param>
		/// <param name="e">mmBusinessStateChangeEventArgs</param>
		protected virtual void HookParentCanceling(mmBusinessObject bizObj, mmBusinessStateChangeEventArgs e)
		{
		}

		/// <summary>
		/// Parent Canceled hook method
		/// </summary>
		/// <param name="bizObj">Parent business object reference</param>
		/// <param name="e">mmBusinessStateChangeEventArgs</param>
		protected virtual void HookParentCanceled(mmBusinessObject bizObj, mmBusinessStateChangeEventArgs e)
		{
		}

		/// <summary>
		/// Parent Deleting hook method
		/// </summary>
		/// <param name="bizObj">Parent business object reference</param>
		/// <param name="e">mmBusinessStateChangeEventArgs</param>
		protected virtual void HookParentDeleting(mmBusinessObject bizObj, mmBusinessStateChangeEventArgs e)
		{
		}

		/// <summary>
		/// Parent Deleted hook method
		/// </summary>
		/// <param name="bizObj">Parent business object reference</param>
		/// <param name="e">mmBusinessStateChangeEventArgs</param>
		protected virtual void HookParentDeleted(mmBusinessObject bizObj, mmBusinessStateChangeEventArgs e)
		{
		}

		/// <summary>
		/// Parent Navigating hook method
		/// </summary>
		/// <param name="bizObj">Parent business object reference</param>
		/// <param name="e">mmBusinessStateChangeEventArgs</param>
		protected virtual void HookParentNavigating(mmBusinessObject bizObj, mmBusinessStateChangeEventArgs e)
		{
		}

		/// <summary>
		/// Parent Navigated hook method
		/// </summary>
		/// <param name="bizObj">Parent business object reference</param>
		/// <param name="e">mmBusinessStateChangeEventArgs</param>
		protected virtual void HookParentNavigated(mmBusinessObject bizObj, mmBusinessStateChangeEventArgs e)
		{
		}

		/// <summary>
		/// Parent retrieving hook method
		/// </summary>
		/// <param name="bizObj">Parent business object reference</param>
		/// <param name="e">mmBusinessStateChangeEventArgs</param>
		protected virtual void HookParentRetrieving(mmBusinessObject bizObj, mmBusinessStateChangeEventArgs e)
		{
		}

		/// <summary>
		/// Parent retrieved hook method
		/// </summary>
		/// <param name="bizObj">Parent business object reference</param>
		/// <param name="e">mmBusinessStateChangeEventArgs</param>
		protected virtual void HookParentRetrieved(mmBusinessObject bizObj, mmBusinessStateChangeEventArgs e)
		{
		}

		/// <summary>
		/// Parent PreSaving hook method
		/// </summary>
		/// <param name="bizObj">Parent business object reference</param>
		/// <param name="e">mmBusinessStateChangeEventArgs</param>
		protected virtual void HookParentPreSaving(mmBusinessObject bizObj, mmBusinessStateChangeEventArgs e)
		{
		}

		/// <summary>
		/// Parent Saving hook method
		/// </summary>
		/// <param name="bizObj">Parent business object reference</param>
		/// <param name="e">mmBusinessStateChangeEventArgs</param>
		protected virtual void HookParentSaving(mmBusinessObject bizObj, mmBusinessStateChangeEventArgs e)
		{
		}

		/// <summary>
		/// Parent Saved hook method
		/// </summary>
		/// <param name="bizObj">Parent business object reference</param>
		/// <param name="e">mmBusinessStateChangeEventArgs</param>
		protected virtual void HookParentSaved(mmBusinessObject bizObj, mmBusinessStateChangeEventArgs e)
		{
		}

        /// <summary>
        /// Parent UpdatingPKValue hook
        /// </summary>
        /// <param name="bizObj">Parent business object</param>
        /// <param name="e">mmBusinessStateChangEventArgs</param>
        protected virtual void HookParentUpdatingPKValue(mmBusinessObject bizObj, mmBusinessStateChangeEventArgs e)
        {
        }

        /// <summary>
        /// Parent UpdatedPKValue hook
        /// </summary>
        /// <param name="bizObj">Parent business object</param>
        /// <param name="e">mmBusinessStateChangEventArgs</param>
        protected virtual void HookParentUpdatedPKValue(mmBusinessObject bizObj, mmBusinessStateChangeEventArgs e)
        {
        }

		/// <summary>
		/// Parent Transaction Begin hook method
		/// </summary>
		/// <param name="bizObj">Parent business object reference</param>
		/// <param name="e">mmTransactionStateChangeEventArgs</param>
		protected virtual void HookParentTransactionBegin(mmBusinessObject bizObj, mmTransactionStateChangeEventArgs e)
		{
			mmDataAccessBase dao = this.GetDataAccessObject(e.DatabaseKey);
			dao.TransactionBegin(e.Connection, e.Transaction);

			// Raise the TransactionStateChange event
			this.OnTransactionStateChange(mmTransactionState.Begin, e.DatabaseKey, 
				e.Connection, e.Transaction);
		}

		/// <summary>
		/// Parent Transaction Commit hook method
		/// </summary>
		/// <param name="bizObj">Parent business object reference</param>
		/// <param name="e">mmTransactionStateChangeEventArgs</param>
		protected virtual void HookParentTransactionCommit(mmBusinessObject bizObj, mmTransactionStateChangeEventArgs e)
		{
			mmDataAccessBase dao = this.GetDataAccessObject(e.DatabaseKey);
			dao.TransactionClear();

			// Raise the TransactionStateChange event
			this.OnTransactionStateChange(mmTransactionState.Commit, e.DatabaseKey,
				null, null);
		}

		/// <summary>
		/// Parent Transaction Rollback hook method
		/// </summary>
		/// <param name="bizObj">Parent business object reference</param>
		/// <param name="e">mmTransactionStateChangeEventArgs</param>
		protected virtual void HookParentTransactionRollback(mmBusinessObject bizObj, mmTransactionStateChangeEventArgs e)
		{
			mmDataAccessBase dao = this.GetDataAccessObject(e.DatabaseKey);
			dao.TransactionClear();

			// Raise the TransactionStateChange event
			this.OnTransactionStateChange(mmTransactionState.Rollback, e.DatabaseKey, null, null);
		}

		/// <summary>
		/// Hook method in which developers can place code to be executed before
		/// a new record is created. If this method returns false, the new is aborted
		/// </summary>
		/// <param name="dt">DataTable to which new record is to be added</param>
		/// <returns>Boolean value indicating if New should continue</returns>
		protected virtual bool HookPreAddNewRow(DataTable dt)
		{
			return true;
		}

		/// <summary>
		/// Hook method in which developers can place code to be executed before
		/// a new record is created. If this method returns false, the new is aborted
		/// </summary>
		/// <param name="dv">DataView to which new record is to be added</param>
		/// <returns>Boolean value indicating if New should continue</returns>
		protected virtual bool HookPreAddNewRow(DataView dv)
		{
			return true;
		}
		
		/// <summary>
		/// Hook method in which developers can place code to be executed before
		/// changes are canceled. If this method returns false, the Cancel is aborted
		/// </summary>
		/// <param name="dt"></param>
		/// <returns></returns>
		protected virtual bool HookPreCancel(DataTable dt)
		{
			return true;
		}

		/// <summary>
		/// Hook method in which developers can place code to be exected before
		/// a record is deleted. If this method returns false, the Delete is aborted
		/// </summary>
		/// <param name="dr">DataRow to be deleted</param>
		/// <returns>Boolean value indicating if Delete should continue</returns>
		protected virtual bool HookPreDelete(DataRow dr)
		{
			return true;
		}

		/// <summary>
		/// Hook method in which developers can place code to be executed before
		/// a record is deleted. If this method returns false, the DeleteAll is aborted
		/// </summary>
		/// <param name="dt">DataTable containing rows to be deleted</param>
		/// <returns>True if successful, otherwise false</returns>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual bool HookPreDeleteAll(DataTable dt)
		{
			return true;
		}

		/// <summary>
		/// Hook method in which developers can place code to be executed before data
		/// is retrieved. If this method returns false, the retrieval is aborted
		/// </summary>
		/// <param name="ds">DataSet of table be filled</param>
		/// <param name="tableName">Name of table within DataSet to be filled</param>
		/// <returns>Boolean value indicating if retrieval should continue</returns>
		protected virtual bool HookPreGetData(DataSet ds, string tableName)
		{
			return true;
		}

		/// <summary>
		/// Hook method in which developers can place code to be executed before
		/// a data table is saved. If this method returns false, the save is aborted.
		/// </summary>
		/// <param name="dt">DataTable to be saved</param>
		/// <returns>Boolean value indicating if Save should continue</returns>
		protected virtual bool HookPreSave(DataTable dt)
		{
			return true;
		}
		
		/// <summary>
		/// Hook method in which developers can place code to be executed
		/// after a new data row has been created in the New() method
		/// </summary>
		/// <param name="dataRow">Newly created data row</param>
		protected virtual void HookPostAddNewRow(DataRow dataRow)
		{
		}

		/// <summary>
		/// Hook method in which developers can place code to be executed after 
		/// changes are canceled
		/// </summary>
		/// <param name="dt">DataTable in which changes were canceled</param>
		protected virtual void HookPostCancel(DataTable dt)
		{
		}

		/// <summary>
		/// Hook method in which developers can place code to be executed after a
		/// row is deleted.
		/// </summary>
		/// <param name="dt">Data table in which data was deleted</param>
		protected virtual void HookPostDelete(DataTable dt)
		{
		}

		/// <summary>
		/// Hook method in which developers can place code to be executed after 
		/// all rows in a table are deleted
		/// </summary>
		/// <param name="dt">DataTable in which rows are deleted</param>
        [System.ComponentModel.EditorBrowsable(System.ComponentModel.EditorBrowsableState.Never)]
        public virtual void HookPostDeleteAll(DataTable dt)
		{
		}

		/// <summary>
		/// Hook method in which developers can place code to be executed after
		/// data is retrieved
		/// </summary>
		protected virtual void HookPostGetData()
		{
		}

		/// <summary>
		/// Hook method in which developers can place code to be executed after
		/// a data table is saved.
		/// </summary>
		/// <param name="dt">DataTable just saved</param>
		protected virtual void HookPostSave(DataTable dt)
		{
		}

		/// <summary>
		/// Hook method in which developers can place code to set default values
		/// in the specified DataRow. This method is automatically called from the
		/// NewRow() method before the call to HookPostAddNewRow().
		/// </summary>
		/// <param name="dataRow">New DataRow</param>
		protected virtual void HookSetDefaultValues(DataRow dataRow)
		{
		}

	}

}
