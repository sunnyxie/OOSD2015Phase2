// Copyright, 2002 Oak Leaf Enterprises Solution Design, Inc.
// No part of this software or its associated documentation 
// may be stored in a retrieval system, copied, transmitted, 
// distributed, transcribed or reproduced in any other way or 
// disclosed to any third parties without the written permission 
// of Oak Leaf Enterprises Solution Design, Inc.

using System;
using System.Data;

namespace OakLeaf.MM.Main.Business
{
	/// <summary>
	/// ImmBusinessRuleHost interface. Specifies an interface for classes
	/// that serve as hosts to mmBusinessRule objects
	/// </summary>
	public interface ImmBusinessRuleHost
	{
		/// <summary>
		/// Provides a hook into which code can be placed to be executed
		/// when a broken rule is added to the associated rules object
		/// </summary>
		/// <param name="brokenRule">Broken rule string</param>
		void OnBrokenRuleAdd(string brokenRule);
		/// <summary>
		/// Provides a hook into which code can be placed to be executed when
		/// a broken rule is cleared from the associated rules object
		/// </summary>
		/// <param name="brokenRule">Broken rule string</param>
		void OnBrokenRuleClear(string brokenRule);
		/// <summary>
		/// Provides a hook into which code can be placed to be executed when
		/// a warning is added to the associated rules object
		/// </summary>
		/// <param name="warning">Warning string</param>
		void OnWarningAdd(string warning);
		/// <summary>
		/// Provides a hook into which code can be placed to be executed when
		/// a warning is cleared from the associated rules object
		/// </summary>
		/// <param name="warning">Warning string</param>
		void OnWarningClear(string warning);
		/// <summary>
		/// Provides a hook into which code can be placed to be executed when
		/// an ErrorProvider broken rule is added
		/// </summary>
		/// <param name="arg">Error Provider argument</param>
		void OnErrorProviderBrokenRuleAdd(mmErrorProviderArgs arg);
		/// <summary>
		/// Provides a hook into which code can be placed to be executed when
		/// an ErrorProvider warning is added
		/// </summary>
		/// <param name="arg">Error Provider argument</param>
		void OnErrorProviderWarningAdd(mmErrorProviderArgs arg);
	}
}
